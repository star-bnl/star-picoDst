/* This was generated for version 'SL10k' */
#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;
#ifdef __CINT__
#pragma link C++ class AgAttribute+;
#pragma link C++ class AgBlock+;
#pragma link C++ class AgCreate+;
#pragma link C++ class AgDetp+;
#pragma link C++ class AgMaterial+;
#pragma link C++ class AgMedium+;
#pragma link C++ class AgModule+;
#pragma link C++ class AgPosition+;
#pragma link C++ class AgShape+;
#pragma link C++ class AgStructure+;
#pragma link C++ class AgVolume+;
#pragma link C++ class StarAgmlStacker+;
#pragma link C++ class StarTGeoStacker+;
#pragma link C++ class Array_t<Int_t>;
#pragma link C++ class Array_t<Float_t>;
#pragma link C++ class Array_t<Double_t>;
#pragma link C++ class Array_t<int>;
#pragma link C++ class Array_t<float>;
#pragma link C++ class Array_t<double>;
#pragma link C++ struct HitSet_t+;
#pragma link C++ struct Gccuts_t+;
#pragma link C++ struct Gcphys_t+;
#pragma link C++ struct Gcbirk_t+;
#pragma link C++ struct Gcphlt_t+;
#endif
