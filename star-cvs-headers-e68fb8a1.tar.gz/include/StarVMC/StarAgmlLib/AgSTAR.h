#ifndef __AgSTAR_h__
#define __AgSTAR_h__

#include "TObject.h"
#include "TString.h"

Int_t agexist( TString name, Bool_t casesens=false );

#endif
