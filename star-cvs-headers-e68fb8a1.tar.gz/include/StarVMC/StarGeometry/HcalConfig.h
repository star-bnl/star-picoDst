#ifndef __HCAL_CONFIG__ 
#define __HCAL_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/HcalGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/HcalGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/HcalGeoF.h" 
namespace HCAL { //
struct HCALof {
  static const char *name()    { return "HCALof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "HcalGeo"; }
  static       bool  list();
  typedef HCALGEO::HcalGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace HCAL { //
struct HCALon {
  static const char *name()    { return "HCALon"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "HcalGeo"; }
  static       bool  list();
  typedef HCALGEO::HcalGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace HCAL { //
struct HCALv0 {
  static const char *name()    { return "HCALv0"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "HcalGeo"; }
  static       bool  list();
  typedef HCALGEO::HcalGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace HCAL { //
struct HCALv1 {
  static const char *name()    { return "HCALv1"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "HcalGeo1"; }
  static       bool  list();
  typedef HCALGEO1::HcalGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace HCAL { //
struct HCALvF {
  static const char *name()    { return "HCALvF"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "HcalGeoF"; }
  static       bool  list();
  typedef HCALGEOF::HcalGeoF Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
