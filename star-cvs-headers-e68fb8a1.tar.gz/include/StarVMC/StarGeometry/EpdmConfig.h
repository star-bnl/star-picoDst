#ifndef __EPDM_CONFIG__ 
#define __EPDM_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/EpdmGeo0.h" 
namespace EPDM { //
struct EPDMof {
  static const char *name()    { return "EPDMof"; }
  static const char *comment() { return "No EPDM"; }
  static const char *module()  { return "EpdmGeo0"; }
  static       bool  list();
  typedef EPDMGEO0::EpdmGeo0 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace EPDM { //
struct EPDMon {
  static const char *name()    { return "EPDMon"; }
  static const char *comment() { return "Default configuration for the Beam Beam counter"; }
  static const char *module()  { return "EpdmGeo0"; }
  static       bool  list();
  typedef EPDMGEO0::EpdmGeo0 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace EPDM { //
struct EPDMv1 {
  static const char *name()    { return "EPDMv1"; }
  static const char *comment() { return "Default configuration for the Beam Beam counter"; }
  static const char *module()  { return "EpdmGeo0"; }
  static       bool  list();
  typedef EPDMGEO0::EpdmGeo0 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
