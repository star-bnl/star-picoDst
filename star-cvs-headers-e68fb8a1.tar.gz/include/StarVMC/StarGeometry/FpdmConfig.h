#ifndef __FPDM_CONFIG__ 
#define __FPDM_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/FpdmGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/FpdmGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/FpdmGeo3.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/FpdmGeo4.h" 
namespace FPDM { //
struct FPDMof {
  static const char *name()    { return "FPDMof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "FpdmGeo1"; }
  static       bool  list();
  typedef FPDMGEO1::FpdmGeo1 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDM00 {
  static const char *name()    { return "FPDM00"; }
  static const char *comment() { return "Forward pion detector"; }
  static const char *module()  { return "FpdmGeo1"; }
  static       bool  list();
  typedef FPDMGEO1::FpdmGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDM01 {
  static const char *name()    { return "FPDM01"; }
  static const char *comment() { return "Forward pion detector"; }
  static const char *module()  { return "FpdmGeo1"; }
  static       bool  list();
  typedef FPDMGEO1::FpdmGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDM02 {
  static const char *name()    { return "FPDM02"; }
  static const char *comment() { return "Forward pion detector"; }
  static const char *module()  { return "FpdmGeo2"; }
  static       bool  list();
  typedef FPDMGEO2::FpdmGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDM03 {
  static const char *name()    { return "FPDM03"; }
  static const char *comment() { return "FPD/FMS"; }
  static const char *module()  { return "FpdmGeo3"; }
  static       bool  list();
  typedef FPDMGEO3::FpdmGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDM03at {
  static const char *name()    { return "FPDM03at"; }
  static const char *comment() { return "FPD/FMS attenuation on"; }
  static const char *module()  { return "FpdmGeo3"; }
  static       bool  list();
  typedef FPDMGEO3::FpdmGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDM04 {
  static const char *name()    { return "FPDM04"; }
  static const char *comment() { return "FPD/FMS/FPS"; }
  static const char *module()  { return "FpdmGeo4"; }
  static       bool  list();
  typedef FPDMGEO4::FpdmGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDM04at {
  static const char *name()    { return "FPDM04at"; }
  static const char *comment() { return "FMS attenuation on"; }
  static const char *module()  { return "FpdmGeo4"; }
  static       bool  list();
  typedef FPDMGEO4::FpdmGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDMv4 {
  static const char *name()    { return "FPDMv4"; }
  static const char *comment() { return "FPD/FMS/FPS"; }
  static const char *module()  { return "FpdmGeo4"; }
  static       bool  list();
  typedef FPDMGEO4::FpdmGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDMv4at {
  static const char *name()    { return "FPDMv4at"; }
  static const char *comment() { return "FMS attenuation on"; }
  static const char *module()  { return "FpdmGeo4"; }
  static       bool  list();
  typedef FPDMGEO4::FpdmGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FPDM { //
struct FPDM13 {
  static const char *name()    { return "FPDM13"; }
  static const char *comment() { return "FPD/FMS in open position"; }
  static const char *module()  { return "FpdmGeo3"; }
  static       bool  list();
  typedef FPDMGEO3::FpdmGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
