#ifndef __EpdmGeo0__ 
#define __EpdmGeo0__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace EPDMGEO0 // $NMSPC 
{ 
   struct mcdt_t {
float version;
int onoff;
float x;
float y;
float z[2];
float thick;
float srad;
float lrad;
int _index;
};
 
   struct _mcdt_docum_ {
string version;
string onoff;
string x;
string y;
string z;
string thick;
string srad;
string lrad;
string _index;
};
 
    struct _mcdt_types_ {
  typedef float version;
  typedef int onoff;
  typedef float x;
  typedef float y;
  typedef float z[2];
  typedef float thick;
  typedef float srad;
  typedef float lrad;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mcdt_info {
typedef mcdt_t Type;
static const char *name(){ return "mcdt_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct mcdt_t, version ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct onoff {
  static const char *name() { return  "onoff"; }
  static int Offset(){ return offsetof( struct mcdt_t, onoff ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct mcdt_t, x ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct mcdt_t, y ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct mcdt_t, z ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[2];
};
struct thick {
  static const char *name() { return  "thick"; }
  static int Offset(){ return offsetof( struct mcdt_t, thick ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct srad {
  static const char *name() { return  "srad"; }
  static int Offset(){ return offsetof( struct mcdt_t, srad ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct lrad {
  static const char *name() { return  "lrad"; }
  static int Offset(){ return offsetof( struct mcdt_t, lrad ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mcdt_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct cdta_t {
float version;
int onoff;
float x[31];
float y[31];
float z;
float rot[31];
float dz[31];
float h[31];
float bl[31];
float tl[31];
float alp[31];
int _index;
};
 
   struct _cdta_docum_ {
string version;
string onoff;
string x;
string y;
string z;
string rot;
string dz;
string h;
string bl;
string tl;
string alp;
string _index;
};
 
    struct _cdta_types_ {
  typedef float version;
  typedef int onoff;
  typedef float x[31];
  typedef float y[31];
  typedef float z;
  typedef float rot[31];
  typedef float dz[31];
  typedef float h[31];
  typedef float bl[31];
  typedef float tl[31];
  typedef float alp[31];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct cdta_info {
typedef cdta_t Type;
static const char *name(){ return "cdta_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct cdta_t, version ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct onoff {
  static const char *name() { return  "onoff"; }
  static int Offset(){ return offsetof( struct cdta_t, onoff ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct cdta_t, x ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct cdta_t, y ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct cdta_t, z ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rot {
  static const char *name() { return  "rot"; }
  static int Offset(){ return offsetof( struct cdta_t, rot ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct cdta_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct h {
  static const char *name() { return  "h"; }
  static int Offset(){ return offsetof( struct cdta_t, h ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct bl {
  static const char *name() { return  "bl"; }
  static int Offset(){ return offsetof( struct cdta_t, bl ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct tl {
  static const char *name() { return  "tl"; }
  static int Offset(){ return offsetof( struct cdta_t, tl ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct alp {
  static const char *name() { return  "alp"; }
  static int Offset(){ return offsetof( struct cdta_t, alp ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct cdta_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)cdta_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct cdtb_t {
float version;
int onoff;
float x[31];
float y[31];
float z;
float rot[31];
float dz[31];
float h[31];
float bl[31];
float tl[31];
float alp[31];
int _index;
};
 
   struct _cdtb_docum_ {
string version;
string onoff;
string x;
string y;
string z;
string rot;
string dz;
string h;
string bl;
string tl;
string alp;
string _index;
};
 
    struct _cdtb_types_ {
  typedef float version;
  typedef int onoff;
  typedef float x[31];
  typedef float y[31];
  typedef float z;
  typedef float rot[31];
  typedef float dz[31];
  typedef float h[31];
  typedef float bl[31];
  typedef float tl[31];
  typedef float alp[31];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct cdtb_info {
typedef cdtb_t Type;
static const char *name(){ return "cdtb_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct cdtb_t, version ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct onoff {
  static const char *name() { return  "onoff"; }
  static int Offset(){ return offsetof( struct cdtb_t, onoff ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct cdtb_t, x ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct cdtb_t, y ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct cdtb_t, z ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rot {
  static const char *name() { return  "rot"; }
  static int Offset(){ return offsetof( struct cdtb_t, rot ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct cdtb_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct h {
  static const char *name() { return  "h"; }
  static int Offset(){ return offsetof( struct cdtb_t, h ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct bl {
  static const char *name() { return  "bl"; }
  static int Offset(){ return offsetof( struct cdtb_t, bl ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct tl {
  static const char *name() { return  "tl"; }
  static int Offset(){ return offsetof( struct cdtb_t, tl ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct alp {
  static const char *name() { return  "alp"; }
  static int Offset(){ return offsetof( struct cdtb_t, alp ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[31];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct cdtb_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)cdtb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct cdtc_t {
float version;
int onoff;
float x;
float y;
float z;
float rot;
float dz;
float h;
float bl;
float tl;
float alp;
int _index;
};
 
   struct _cdtc_docum_ {
string version;
string onoff;
string x;
string y;
string z;
string rot;
string dz;
string h;
string bl;
string tl;
string alp;
string _index;
};
 
    struct _cdtc_types_ {
  typedef float version;
  typedef int onoff;
  typedef float x;
  typedef float y;
  typedef float z;
  typedef float rot;
  typedef float dz;
  typedef float h;
  typedef float bl;
  typedef float tl;
  typedef float alp;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct cdtc_info {
typedef cdtc_t Type;
static const char *name(){ return "cdtc_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct cdtc_t, version ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct onoff {
  static const char *name() { return  "onoff"; }
  static int Offset(){ return offsetof( struct cdtc_t, onoff ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct cdtc_t, x ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct cdtc_t, y ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct cdtc_t, z ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rot {
  static const char *name() { return  "rot"; }
  static int Offset(){ return offsetof( struct cdtc_t, rot ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct cdtc_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct h {
  static const char *name() { return  "h"; }
  static int Offset(){ return offsetof( struct cdtc_t, h ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bl {
  static const char *name() { return  "bl"; }
  static int Offset(){ return offsetof( struct cdtc_t, bl ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tl {
  static const char *name() { return  "tl"; }
  static int Offset(){ return offsetof( struct cdtc_t, tl ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct alp {
  static const char *name() { return  "alp"; }
  static int Offset(){ return offsetof( struct cdtc_t, alp ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct cdtc_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)cdtc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct cdtd_t {
float version;
int onoff;
float x;
float y;
float z;
float rot;
float dz;
float h;
float bl;
float tl;
float alp;
int _index;
};
 
   struct _cdtd_docum_ {
string version;
string onoff;
string x;
string y;
string z;
string rot;
string dz;
string h;
string bl;
string tl;
string alp;
string _index;
};
 
    struct _cdtd_types_ {
  typedef float version;
  typedef int onoff;
  typedef float x;
  typedef float y;
  typedef float z;
  typedef float rot;
  typedef float dz;
  typedef float h;
  typedef float bl;
  typedef float tl;
  typedef float alp;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct cdtd_info {
typedef cdtd_t Type;
static const char *name(){ return "cdtd_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct cdtd_t, version ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct onoff {
  static const char *name() { return  "onoff"; }
  static int Offset(){ return offsetof( struct cdtd_t, onoff ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct cdtd_t, x ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct cdtd_t, y ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct cdtd_t, z ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rot {
  static const char *name() { return  "rot"; }
  static int Offset(){ return offsetof( struct cdtd_t, rot ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct cdtd_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct h {
  static const char *name() { return  "h"; }
  static int Offset(){ return offsetof( struct cdtd_t, h ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bl {
  static const char *name() { return  "bl"; }
  static int Offset(){ return offsetof( struct cdtd_t, bl ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tl {
  static const char *name() { return  "tl"; }
  static int Offset(){ return offsetof( struct cdtd_t, tl ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct alp {
  static const char *name() { return  "alp"; }
  static int Offset(){ return offsetof( struct cdtd_t, alp ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct cdtd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)cdtd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- EPDM -- 
   ///@defgroup EPDM_doc 
   ///@class EPDM 
   ///@brief Mother volume [TGeoVolume] 
   class EPDM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EPDM() : AgBlock("EPDM","Mother volume [TGeoVolume]"){ 
      }; 
      ~EPDM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EPSS -- 
   ///@defgroup EPSS_doc 
   ///@class EPSS 
   ///@brief Mother volume [TGeoVolume] 
   class EPSS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EPSS() : AgBlock("EPSS","Mother volume [TGeoVolume]"){ 
      }; 
      ~EPSS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EPDT -- 
   ///@defgroup EPDT_doc 
   ///@class EPDT 
   ///@brief EPD a general trapzoid [TGeoVolume] 
   class EPDT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EPDT() : AgBlock("EPDT","EPD a general trapzoid [TGeoVolume]"){ 
      }; 
      ~EPDT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class EpdmGeo0 
   /// \brief Event Plane Detector (Full geometry) 
   class EpdmGeo0 : public AgModule 
   { 
      public: 
      EpdmGeo0(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~EpdmGeo0(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace EpdmGeo0 
#endif // __EpdmGeo0__ 
