#ifndef __PIXL_CONFIG__ 
#define __PIXL_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PixlGeo3.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PixlGeo4.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PixlGeo5.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PixlGeo6.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PixlGeo6b.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PsupGeo.h" 
namespace PIXL { //
struct PIXLof {
  static const char *name()    { return "PIXLof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "PixlGeo3"; }
  static       bool  list();
  typedef PIXLGEO3::PixlGeo3 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIXL { //
struct PIXLon {
  static const char *name()    { return "PIXLon"; }
  static const char *comment() { return "Version 3 pixel detector"; }
  static const char *module()  { return "PixlGeo3"; }
  static       bool  list();
  typedef PIXLGEO3::PixlGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIXL { //
struct PIXL00 {
  static const char *name()    { return "PIXL00"; }
  static const char *comment() { return "Version 3 pixel detector"; }
  static const char *module()  { return "PixlGeo3"; }
  static       bool  list();
  typedef PIXLGEO3::PixlGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIXL { //
struct PIXL01 {
  static const char *name()    { return "PIXL01"; }
  static const char *comment() { return "Version 3 pixel detector"; }
  static const char *module()  { return "PixlGeo3"; }
  static       bool  list();
  typedef PIXLGEO3::PixlGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIXL { //
struct PIXL02 {
  static const char *name()    { return "PIXL02"; }
  static const char *comment() { return "Version 4 pixel detector"; }
  static const char *module()  { return "PixlGeo4"; }
  static       bool  list();
  typedef PIXLGEO4::PixlGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIXL { //
struct PIXL05 {
  static const char *name()    { return "PIXL05"; }
  static const char *comment() { return "Version 5 pixel detector"; }
  static const char *module()  { return "PixlGeo5"; }
  static       bool  list();
  typedef PIXLGEO5::PixlGeo5 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIXL { //
struct PIXL06 {
  static const char *name()    { return "PIXL06"; }
  static const char *comment() { return "Version 6 pixel detector"; }
  static const char *module()  { return "PixlGeo6b"; }
  static       bool  list();
  typedef PIXLGEO6B::PixlGeo6b Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIXL { //
struct PIXL62 {
  static const char *name()    { return "PIXL62"; }
  static const char *comment() { return "Version 6 pixel detector"; }
  static const char *module()  { return "PixlGeo6b"; }
  static       bool  list();
  typedef PIXLGEO6B::PixlGeo6b Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIXL { //
struct PIXL06b {
  static const char *name()    { return "PIXL06b"; }
  static const char *comment() { return "Version 6 pixel detector"; }
  static const char *module()  { return "PixlGeo6b"; }
  static       bool  list();
  typedef PIXLGEO6B::PixlGeo6b Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIXL { //
struct PIXL62b {
  static const char *name()    { return "PIXL62b"; }
  static const char *comment() { return "Version 6 pixel detector"; }
  static const char *module()  { return "PixlGeo6b"; }
  static       bool  list();
  typedef PIXLGEO6B::PixlGeo6b Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
