#ifndef __SCON_CONFIG__ 
#define __SCON_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SconGeo.h" 
namespace SCON { //
struct SCONof {
  static const char *name()    { return "SCONof"; }
  static const char *comment() { return "FGT off"; }
  static const char *module()  { return "SconGeo"; }
  static       bool  list();
  typedef SCONGEO::SconGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SCON { //
struct SCONon {
  static const char *name()    { return "SCONon"; }
  static const char *comment() { return "Default configuration for the SVT support cone"; }
  static const char *module()  { return "SconGeo"; }
  static       bool  list();
  typedef SCONGEO::SconGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SCON { //
struct SCON02 {
  static const char *name()    { return "SCON02"; }
  static const char *comment() { return "SVT support cone dummy.  SVT geo creates cone"; }
  static const char *module()  { return "SconGeo"; }
  static       bool  list();
  typedef SCONGEO::SconGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SCON { //
struct SCON12 {
  static const char *name()    { return "SCON12"; }
  static const char *comment() { return "Default configuration for the SVT support cone"; }
  static const char *module()  { return "SconGeo"; }
  static       bool  list();
  typedef SCONGEO::SconGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SCON { //
struct SCON13 {
  static const char *name()    { return "SCON13"; }
  static const char *comment() { return "Default configuration for the SVT support cone"; }
  static const char *module()  { return "SconGeo"; }
  static       bool  list();
  typedef SCONGEO::SconGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SCON { //
struct SCON14 {
  static const char *name()    { return "SCON14"; }
  static const char *comment() { return "Default configuration for the SVT support cone"; }
  static const char *module()  { return "SconGeo"; }
  static       bool  list();
  typedef SCONGEO::SconGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
