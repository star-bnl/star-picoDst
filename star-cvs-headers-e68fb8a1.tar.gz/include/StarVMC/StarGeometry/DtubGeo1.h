#ifndef __DtubGeo1__ 
#define __DtubGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace DTUBGEO1 // $NMSPC 
{ 
   struct scsd_t {
int version;
int numberofcables;
float xpos[5];
float ypos[5];
int _index;
};
 
   struct _scsd_docum_ {
string version;
string numberofcables;
string xpos;
string ypos;
string _index;
};
 
    struct _scsd_types_ {
  typedef int version;
  typedef int numberofcables;
  typedef float xpos[5];
  typedef float ypos[5];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct scsd_info {
typedef scsd_t Type;
static const char *name(){ return "scsd_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct scsd_t, version ); }
  static void* address(){ 
         long long iadd = (long long)scsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct numberofcables {
  static const char *name() { return  "numberofcables"; }
  static int Offset(){ return offsetof( struct scsd_t, numberofcables ); }
  static void* address(){ 
         long long iadd = (long long)scsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct xpos {
  static const char *name() { return  "xpos"; }
  static int Offset(){ return offsetof( struct scsd_t, xpos ); }
  static void* address(){ 
         long long iadd = (long long)scsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[5];
};
struct ypos {
  static const char *name() { return  "ypos"; }
  static int Offset(){ return offsetof( struct scsd_t, ypos ); }
  static void* address(){ 
         long long iadd = (long long)scsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[5];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct scsd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)scsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct lcsd_t {
int version;
int numberofcables;
float xpos[15];
float ypos[15];
int _index;
};
 
   struct _lcsd_docum_ {
string version;
string numberofcables;
string xpos;
string ypos;
string _index;
};
 
    struct _lcsd_types_ {
  typedef int version;
  typedef int numberofcables;
  typedef float xpos[15];
  typedef float ypos[15];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct lcsd_info {
typedef lcsd_t Type;
static const char *name(){ return "lcsd_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct lcsd_t, version ); }
  static void* address(){ 
         long long iadd = (long long)lcsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct numberofcables {
  static const char *name() { return  "numberofcables"; }
  static int Offset(){ return offsetof( struct lcsd_t, numberofcables ); }
  static void* address(){ 
         long long iadd = (long long)lcsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct xpos {
  static const char *name() { return  "xpos"; }
  static int Offset(){ return offsetof( struct lcsd_t, xpos ); }
  static void* address(){ 
         long long iadd = (long long)lcsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[15];
};
struct ypos {
  static const char *name() { return  "ypos"; }
  static int Offset(){ return offsetof( struct lcsd_t, ypos ); }
  static void* address(){ 
         long long iadd = (long long)lcsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[15];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct lcsd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)lcsd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct radd_t {
int version;
int numberofsections;
int numberofcables;
float anglemin[20];
float anglemax[20];
float zpos[20];
float radius;
int _index;
};
 
   struct _radd_docum_ {
string version;
string numberofsections;
string numberofcables;
string anglemin;
string anglemax;
string zpos;
string radius;
string _index;
};
 
    struct _radd_types_ {
  typedef int version;
  typedef int numberofsections;
  typedef int numberofcables;
  typedef float anglemin[20];
  typedef float anglemax[20];
  typedef float zpos[20];
  typedef float radius;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct radd_info {
typedef radd_t Type;
static const char *name(){ return "radd_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct radd_t, version ); }
  static void* address(){ 
         long long iadd = (long long)radd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct numberofsections {
  static const char *name() { return  "numberofsections"; }
  static int Offset(){ return offsetof( struct radd_t, numberofsections ); }
  static void* address(){ 
         long long iadd = (long long)radd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct numberofcables {
  static const char *name() { return  "numberofcables"; }
  static int Offset(){ return offsetof( struct radd_t, numberofcables ); }
  static void* address(){ 
         long long iadd = (long long)radd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct anglemin {
  static const char *name() { return  "anglemin"; }
  static int Offset(){ return offsetof( struct radd_t, anglemin ); }
  static void* address(){ 
         long long iadd = (long long)radd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[20];
};
struct anglemax {
  static const char *name() { return  "anglemax"; }
  static int Offset(){ return offsetof( struct radd_t, anglemax ); }
  static void* address(){ 
         long long iadd = (long long)radd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[20];
};
struct zpos {
  static const char *name() { return  "zpos"; }
  static int Offset(){ return offsetof( struct radd_t, zpos ); }
  static void* address(){ 
         long long iadd = (long long)radd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[20];
};
struct radius {
  static const char *name() { return  "radius"; }
  static int Offset(){ return offsetof( struct radd_t, radius ); }
  static void* address(){ 
         long long iadd = (long long)radd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct radd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)radd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- DTUH -- 
   ///@defgroup DTUH_doc 
   ///@class DTUH 
   ///@brief half DTube [TGeoVolume] 
   class DTUH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DTUH() : AgBlock("DTUH","half DTube [TGeoVolume]"){ 
      }; 
      ~DTUH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TUBA -- 
   ///@defgroup TUBA_doc 
   ///@class TUBA 
   ///@brief A TUBE with innner and outer radius [TGeoVolume] 
   class TUBA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TUBA() : AgBlock("TUBA","A TUBE with innner and outer radius [TGeoVolume]"){ 
      }; 
      ~TUBA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- APTO -- 
   ///@defgroup APTO_doc 
   ///@class APTO 
   ///@brief A Plane TOp [TGeoVolume] 
   class APTO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      APTO() : AgBlock("APTO","A Plane TOp [TGeoVolume]"){ 
      }; 
      ~APTO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- UCTO -- 
   ///@defgroup UCTO_doc 
   ///@class UCTO 
   ///@brief a Up Corner TOp  [TGeoVolume] 
   class UCTO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      UCTO() : AgBlock("UCTO","a Up Corner TOp  [TGeoVolume]"){ 
      }; 
      ~UCTO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- OUCY -- 
   ///@defgroup OUCY_doc 
   ///@class OUCY 
   ///@brief a OUtside CYLinder  [TGeoVolume] 
   class OUCY : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      OUCY() : AgBlock("OUCY","a OUtside CYLinder  [TGeoVolume]"){ 
      }; 
      ~OUCY(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- DCBO -- 
   ///@defgroup DCBO_doc 
   ///@class DCBO 
   ///@brief a Down Corner BOttomUp [TGeoVolume] 
   class DCBO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DCBO() : AgBlock("DCBO","a Down Corner BOttomUp [TGeoVolume]"){ 
      }; 
      ~DCBO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- APBM -- 
   ///@defgroup APBM_doc 
   ///@class APBM 
   ///@brief A Plane BOttom  [TGeoVolume] 
   class APBM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      APBM() : AgBlock("APBM","A Plane BOttom  [TGeoVolume]"){ 
      }; 
      ~APBM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- UCBO -- 
   ///@defgroup UCBO_doc 
   ///@class UCBO 
   ///@brief a Up Corner BOttom  [TGeoVolume] 
   class UCBO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      UCBO() : AgBlock("UCBO","a Up Corner BOttom  [TGeoVolume]"){ 
      }; 
      ~UCBO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- DCTO -- 
   ///@defgroup DCTO_doc 
   ///@class DCTO 
   ///@brief  Down Corner TOp  [TGeoVolume] 
   class DCTO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DCTO() : AgBlock("DCTO"," Down Corner TOp  [TGeoVolume]"){ 
      }; 
      ~DCTO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- INCY -- 
   ///@defgroup INCY_doc 
   ///@class INCY 
   ///@brief an INternal CYlinder  [TGeoVolume] 
   class INCY : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      INCY() : AgBlock("INCY","an INternal CYlinder  [TGeoVolume]"){ 
      }; 
      ~INCY(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CYTR -- 
   ///@defgroup CYTR_doc 
   ///@class CYTR 
   ///@brief a CYlinder TRansition [TGeoVolume] 
   class CYTR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CYTR() : AgBlock("CYTR","a CYlinder TRansition [TGeoVolume]"){ 
      }; 
      ~CYTR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- APTE -- 
   ///@defgroup APTE_doc 
   ///@class APTE 
   ///@brief A Plane Top End [TGeoVolume] 
   class APTE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      APTE() : AgBlock("APTE","A Plane Top End [TGeoVolume]"){ 
      }; 
      ~APTE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- UCTE -- 
   ///@defgroup UCTE_doc 
   ///@class UCTE 
   ///@brief a Up Corner End  [TGeoVolume] 
   class UCTE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      UCTE() : AgBlock("UCTE","a Up Corner End  [TGeoVolume]"){ 
      }; 
      ~UCTE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- APBE -- 
   ///@defgroup APBE_doc 
   ///@class APBE 
   ///@brief A Plane Bottom End [TGeoVolume] 
   class APBE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      APBE() : AgBlock("APBE","A Plane Bottom End [TGeoVolume]"){ 
      }; 
      ~APBE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- DCBE -- 
   ///@defgroup DCBE_doc 
   ///@class DCBE 
   ///@brief a Down Corner Bottom End [TGeoVolume] 
   class DCBE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DCBE() : AgBlock("DCBE","a Down Corner Bottom End [TGeoVolume]"){ 
      }; 
      ~DCBE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- OUCE -- 
   ///@defgroup OUCE_doc 
   ///@class OUCE 
   ///@brief a OUtside CyLinder End  [TGeoVolume] 
   class OUCE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      OUCE() : AgBlock("OUCE","a OUtside CyLinder End  [TGeoVolume]"){ 
      }; 
      ~OUCE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- OUCI -- 
   ///@defgroup OUCI_doc 
   ///@class OUCI 
   ///@brief a OUtside CyLinder Intermediate   [TGeoVolume] 
   class OUCI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      OUCI() : AgBlock("OUCI","a OUtside CyLinder Intermediate   [TGeoVolume]"){ 
      }; 
      ~OUCI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ATTI -- 
   ///@defgroup ATTI_doc 
   ///@class ATTI 
   ///@brief A Trap Top Intermdiate [TGeoVolume] 
   class ATTI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ATTI() : AgBlock("ATTI","A Trap Top Intermdiate [TGeoVolume]"){ 
      }; 
      ~ATTI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ATBI -- 
   ///@defgroup ATBI_doc 
   ///@class ATBI 
   ///@brief A Trap Bottom Intermediate [TGeoVolume] 
   class ATBI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ATBI() : AgBlock("ATBI","A Trap Bottom Intermediate [TGeoVolume]"){ 
      }; 
      ~ATBI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- UCTI -- 
   ///@defgroup UCTI_doc 
   ///@class UCTI 
   ///@brief a Up Corner Intermediate  [TGeoVolume] 
   class UCTI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      UCTI() : AgBlock("UCTI","a Up Corner Intermediate  [TGeoVolume]"){ 
      }; 
      ~UCTI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- DCBI -- 
   ///@defgroup DCBI_doc 
   ///@class DCBI 
   ///@brief a Down Corner Bottom Intermediate [TGeoVolume] 
   class DCBI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DCBI() : AgBlock("DCBI","a Down Corner Bottom Intermediate [TGeoVolume]"){ 
      }; 
      ~DCBI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- DCTH -- 
   ///@defgroup DCTH_doc 
   ///@class DCTH 
   ///@brief  Down Corner Transition Height  [TGeoVolume] 
   class DCTH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DCTH() : AgBlock("DCTH"," Down Corner Transition Height  [TGeoVolume]"){ 
      }; 
      ~DCTH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TCTH -- 
   ///@defgroup TCTH_doc 
   ///@class TCTH 
   ///@brief  Top Corner Transition Height  [TGeoVolume] 
   class TCTH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TCTH() : AgBlock("TCTH"," Top Corner Transition Height  [TGeoVolume]"){ 
      }; 
      ~TCTH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSTI -- 
   ///@defgroup CSTI_doc 
   ///@class CSTI 
   ///@brief Cone Segment Top Intermediate [TGeoVolume] 
   class CSTI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSTI() : AgBlock("CSTI","Cone Segment Top Intermediate [TGeoVolume]"){ 
      }; 
      ~CSTI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSBI -- 
   ///@defgroup CSBI_doc 
   ///@class CSBI 
   ///@brief Cone Segment Top Intermediate [TGeoVolume] 
   class CSBI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSBI() : AgBlock("CSBI","Cone Segment Top Intermediate [TGeoVolume]"){ 
      }; 
      ~CSBI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- APET -- 
   ///@defgroup APET_doc 
   ///@class APET 
   ///@brief A Plane End top [TGeoVolume] 
   class APET : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      APET() : AgBlock("APET","A Plane End top [TGeoVolume]"){ 
      }; 
      ~APET(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- APEB -- 
   ///@defgroup APEB_doc 
   ///@class APEB 
   ///@brief A Plane End bottom [TGeoVolume] 
   class APEB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      APEB() : AgBlock("APEB","A Plane End bottom [TGeoVolume]"){ 
      }; 
      ~APEB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- OCYE -- 
   ///@defgroup OCYE_doc 
   ///@class OCYE 
   ///@brief a Outside CYLinder End  [TGeoVolume] 
   class OCYE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      OCYE() : AgBlock("OCYE","a Outside CYLinder End  [TGeoVolume]"){ 
      }; 
      ~OCYE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- OCEA -- 
   ///@defgroup OCEA_doc 
   ///@class OCEA 
   ///@brief a Outside CyLinder End part A  [TGeoVolume] 
   class OCEA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      OCEA() : AgBlock("OCEA","a Outside CyLinder End part A  [TGeoVolume]"){ 
      }; 
      ~OCEA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- OCEB -- 
   ///@defgroup OCEB_doc 
   ///@class OCEB 
   ///@brief a Outside CyLinder End part B  [TGeoVolume] 
   class OCEB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      OCEB() : AgBlock("OCEB","a Outside CyLinder End part B  [TGeoVolume]"){ 
      }; 
      ~OCEB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- OCEC -- 
   ///@defgroup OCEC_doc 
   ///@class OCEC 
   ///@brief a Outside CyLinder End part C  [TGeoVolume] 
   class OCEC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      OCEC() : AgBlock("OCEC","a Outside CyLinder End part C  [TGeoVolume]"){ 
      }; 
      ~OCEC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- OCED -- 
   ///@defgroup OCED_doc 
   ///@class OCED 
   ///@brief a Outside CyLinder End part C  [TGeoVolume] 
   class OCED : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      OCED() : AgBlock("OCED","a Outside CyLinder End part C  [TGeoVolume]"){ 
      }; 
      ~OCED(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- UPTE -- 
   ///@defgroup UPTE_doc 
   ///@class UPTE 
   ///@brief a UP corner Top End  [TGeoVolume] 
   class UPTE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      UPTE() : AgBlock("UPTE","a UP corner Top End  [TGeoVolume]"){ 
      }; 
      ~UPTE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BOTE -- 
   ///@defgroup BOTE_doc 
   ///@class BOTE 
   ///@brief a BOttom corner Top End  [TGeoVolume] 
   class BOTE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BOTE() : AgBlock("BOTE","a BOttom corner Top End  [TGeoVolume]"){ 
      }; 
      ~BOTE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SCAD -- 
   ///@defgroup SCAD_doc 
   ///@class SCAD 
   ///@brief Short CAble section D [TGeoVolume] 
   class SCAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SCAD() : AgBlock("SCAD","Short CAble section D [TGeoVolume]"){ 
      }; 
      ~SCAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LCAD -- 
   ///@defgroup LCAD_doc 
   ///@class LCAD 
   ///@brief Long CAble section D [TGeoVolume] 
   class LCAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LCAD() : AgBlock("LCAD","Long CAble section D [TGeoVolume]"){ 
      }; 
      ~LCAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAA -- 
   ///@defgroup LSAA_doc 
   ///@class LSAA 
   ///@brief Long cable Section A A [TGeoVolume] 
   class LSAA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAA() : AgBlock("LSAA","Long cable Section A A [TGeoVolume]"){ 
      }; 
      ~LSAA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAB -- 
   ///@defgroup LSAB_doc 
   ///@class LSAB 
   ///@brief Long cable Section A B [TGeoVolume] 
   class LSAB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAB() : AgBlock("LSAB","Long cable Section A B [TGeoVolume]"){ 
      }; 
      ~LSAB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAC -- 
   ///@defgroup LSAC_doc 
   ///@class LSAC 
   ///@brief Long cable Section A C [TGeoVolume] 
   class LSAC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAC() : AgBlock("LSAC","Long cable Section A C [TGeoVolume]"){ 
      }; 
      ~LSAC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAD -- 
   ///@defgroup LSAD_doc 
   ///@class LSAD 
   ///@brief Long cable Section A D [TGeoVolume] 
   class LSAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAD() : AgBlock("LSAD","Long cable Section A D [TGeoVolume]"){ 
      }; 
      ~LSAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAE -- 
   ///@defgroup LSAE_doc 
   ///@class LSAE 
   ///@brief Long cable Section A E [TGeoVolume] 
   class LSAE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAE() : AgBlock("LSAE","Long cable Section A E [TGeoVolume]"){ 
      }; 
      ~LSAE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAF -- 
   ///@defgroup LSAF_doc 
   ///@class LSAF 
   ///@brief Long cable Section A F [TGeoVolume] 
   class LSAF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAF() : AgBlock("LSAF","Long cable Section A F [TGeoVolume]"){ 
      }; 
      ~LSAF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAG -- 
   ///@defgroup LSAG_doc 
   ///@class LSAG 
   ///@brief Long cable Section A G [TGeoVolume] 
   class LSAG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAG() : AgBlock("LSAG","Long cable Section A G [TGeoVolume]"){ 
      }; 
      ~LSAG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAH -- 
   ///@defgroup LSAH_doc 
   ///@class LSAH 
   ///@brief Long cable Section A H [TGeoVolume] 
   class LSAH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAH() : AgBlock("LSAH","Long cable Section A H [TGeoVolume]"){ 
      }; 
      ~LSAH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAI -- 
   ///@defgroup LSAI_doc 
   ///@class LSAI 
   ///@brief Long cable Section A I [TGeoVolume] 
   class LSAI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAI() : AgBlock("LSAI","Long cable Section A I [TGeoVolume]"){ 
      }; 
      ~LSAI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAJ -- 
   ///@defgroup LSAJ_doc 
   ///@class LSAJ 
   ///@brief Long cable Section A J [TGeoVolume] 
   class LSAJ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAJ() : AgBlock("LSAJ","Long cable Section A J [TGeoVolume]"){ 
      }; 
      ~LSAJ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAK -- 
   ///@defgroup LSAK_doc 
   ///@class LSAK 
   ///@brief Long cable Section A k [TGeoVolume] 
   class LSAK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAK() : AgBlock("LSAK","Long cable Section A k [TGeoVolume]"){ 
      }; 
      ~LSAK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAL -- 
   ///@defgroup LSAL_doc 
   ///@class LSAL 
   ///@brief Long cable Section A L [TGeoVolume] 
   class LSAL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAL() : AgBlock("LSAL","Long cable Section A L [TGeoVolume]"){ 
      }; 
      ~LSAL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAM -- 
   ///@defgroup LSAM_doc 
   ///@class LSAM 
   ///@brief Long cable Section A M [TGeoVolume] 
   class LSAM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAM() : AgBlock("LSAM","Long cable Section A M [TGeoVolume]"){ 
      }; 
      ~LSAM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAN -- 
   ///@defgroup LSAN_doc 
   ///@class LSAN 
   ///@brief Long cable Section A N [TGeoVolume] 
   class LSAN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAN() : AgBlock("LSAN","Long cable Section A N [TGeoVolume]"){ 
      }; 
      ~LSAN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAO -- 
   ///@defgroup LSAO_doc 
   ///@class LSAO 
   ///@brief Long cable Section A O [TGeoVolume] 
   class LSAO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAO() : AgBlock("LSAO","Long cable Section A O [TGeoVolume]"){ 
      }; 
      ~LSAO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAP -- 
   ///@defgroup LSAP_doc 
   ///@class LSAP 
   ///@brief Long cable Section A P [TGeoVolume] 
   class LSAP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAP() : AgBlock("LSAP","Long cable Section A P [TGeoVolume]"){ 
      }; 
      ~LSAP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAQ -- 
   ///@defgroup LSAQ_doc 
   ///@class LSAQ 
   ///@brief Long cable Section A Q [TGeoVolume] 
   class LSAQ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAQ() : AgBlock("LSAQ","Long cable Section A Q [TGeoVolume]"){ 
      }; 
      ~LSAQ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAR -- 
   ///@defgroup LSAR_doc 
   ///@class LSAR 
   ///@brief Long cable Section A R [TGeoVolume] 
   class LSAR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAR() : AgBlock("LSAR","Long cable Section A R [TGeoVolume]"){ 
      }; 
      ~LSAR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAS -- 
   ///@defgroup LSAS_doc 
   ///@class LSAS 
   ///@brief Long cable Section A S [TGeoVolume] 
   class LSAS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAS() : AgBlock("LSAS","Long cable Section A S [TGeoVolume]"){ 
      }; 
      ~LSAS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LSAT -- 
   ///@defgroup LSAT_doc 
   ///@class LSAT 
   ///@brief Long cable Section A T [TGeoVolume] 
   class LSAT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LSAT() : AgBlock("LSAT","Long cable Section A T [TGeoVolume]"){ 
      }; 
      ~LSAT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class DtubGeo1 
   /// \brief Geometry for Pixel DTube 
   class DtubGeo1 : public AgModule 
   { 
      public: 
      DtubGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~DtubGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace DtubGeo1 
#endif // __DtubGeo1__ 
