#ifndef __CALB_CONFIG__ 
#define __CALB_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/CalbGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/CalbGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/CalbGeo2.h" 
namespace CALB { //
struct CALBof {
  static const char *name()    { return "CALBof"; }
  static const char *comment() { return "No CALB"; }
  static const char *module()  { return "CalbGeo"; }
  static       bool  list();
  typedef CALBGEO::CalbGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CALB { //
struct CALB00 {
  static const char *name()    { return "CALB00"; }
  static const char *comment() { return "Full BEMC 2007"; }
  static const char *module()  { return "CalbGeo"; }
  static       bool  list();
  typedef CALBGEO::CalbGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CALB { //
struct CALBa0 {
  static const char *name()    { return "CALBa0"; }
  static const char *comment() { return "Full BEMC 2007"; }
  static const char *module()  { return "CalbGeo"; }
  static       bool  list();
  typedef CALBGEO::CalbGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CALB { //
struct CALBb0 {
  static const char *name()    { return "CALBb0"; }
  static const char *comment() { return "Full BEMC 2007"; }
  static const char *module()  { return "CalbGeo"; }
  static       bool  list();
  typedef CALBGEO::CalbGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CALB { //
struct CALBc0 {
  static const char *name()    { return "CALBc0"; }
  static const char *comment() { return "Full BEMC 2007"; }
  static const char *module()  { return "CalbGeo"; }
  static       bool  list();
  typedef CALBGEO::CalbGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CALB { //
struct CALBd0 {
  static const char *name()    { return "CALBd0"; }
  static const char *comment() { return "Full BEMC 2007"; }
  static const char *module()  { return "CalbGeo"; }
  static       bool  list();
  typedef CALBGEO::CalbGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CALB { //
struct CALBe0 {
  static const char *name()    { return "CALBe0"; }
  static const char *comment() { return "Full BEMC 2007"; }
  static const char *module()  { return "CalbGeo"; }
  static       bool  list();
  typedef CALBGEO::CalbGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CALB { //
struct CALB01 {
  static const char *name()    { return "CALB01"; }
  static const char *comment() { return "Full BEMC 2007"; }
  static const char *module()  { return "CalbGeo1"; }
  static       bool  list();
  typedef CALBGEO1::CalbGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CALB { //
struct CALB02 {
  static const char *name()    { return "CALB02"; }
  static const char *comment() { return "Full BEMC 2007"; }
  static const char *module()  { return "CalbGeo2"; }
  static       bool  list();
  typedef CALBGEO2::CalbGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CALB { //
struct CALB02_cut00 {
  static const char *name()    { return "CALB02_cut00"; }
  static const char *comment() { return "Full BEMC 2007 diable EM cuts"; }
  static const char *module()  { return "CalbGeo2"; }
  static       bool  list();
  typedef CALBGEO2::CalbGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
