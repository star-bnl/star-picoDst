#ifndef __EtofGeo0__ 
#define __EtofGeo0__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace ETOFGEO0 // $NMSPC 
{ 
   struct etoc_t {
float version;
int _index;
};
 
   struct _etoc_docum_ {
string version;
string _index;
};
 
    struct _etoc_types_ {
  typedef float version;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct etoc_info {
typedef etoc_t Type;
static const char *name(){ return "etoc_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct etoc_t, version ); }
  static void* address(){ 
         long long iadd = (long long)etoc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct etoc_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)etoc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct etog_t {
float version;
float zplane[3];
int active[12];
int sector[12];
int _index;
};
 
   struct _etog_docum_ {
string version;
string zplane;
string active;
string sector;
string _index;
};
 
    struct _etog_types_ {
  typedef float version;
  typedef float zplane[3];
  typedef int active[12];
  typedef int sector[12];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct etog_info {
typedef etog_t Type;
static const char *name(){ return "etog_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct etog_t, version ); }
  static void* address(){ 
         long long iadd = (long long)etog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zplane {
  static const char *name() { return  "zplane"; }
  static int Offset(){ return offsetof( struct etog_t, zplane ); }
  static void* address(){ 
         long long iadd = (long long)etog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct active {
  static const char *name() { return  "active"; }
  static int Offset(){ return offsetof( struct etog_t, active ); }
  static void* address(){ 
         long long iadd = (long long)etog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type[12];
};
struct sector {
  static const char *name() { return  "sector"; }
  static int Offset(){ return offsetof( struct etog_t, sector ); }
  static void* address(){ 
         long long iadd = (long long)etog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type[12];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct etog_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)etog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- ETOF -- 
   ///@defgroup ETOF_doc 
   ///@class ETOF 
   ///@brief  [TGeoVolume] 
   class ETOF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ETOF() : AgBlock("ETOF"," [TGeoVolume]"){ 
      }; 
      ~ETOF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EGAS -- 
   ///@defgroup EGAS_doc 
   ///@class EGAS 
   ///@brief  [TGeoVolume] 
   class EGAS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EGAS() : AgBlock("EGAS"," [TGeoVolume]"){ 
      }; 
      ~EGAS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ECOU -- 
   ///@defgroup ECOU_doc 
   ///@class ECOU 
   ///@brief  [TGeoVolume] 
   class ECOU : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ECOU() : AgBlock("ECOU"," [TGeoVolume]"){ 
      }; 
      ~ECOU(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EGLA -- 
   ///@defgroup EGLA_doc 
   ///@class EGLA 
   ///@brief  [TGeoVolume] 
   class EGLA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EGLA() : AgBlock("EGLA"," [TGeoVolume]"){ 
      }; 
      ~EGLA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EGAP -- 
   ///@defgroup EGAP_doc 
   ///@class EGAP 
   ///@brief  [TGeoVolume] 
   class EGAP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EGAP() : AgBlock("EGAP"," [TGeoVolume]"){ 
      }; 
      ~EGAP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ECEL -- 
   ///@defgroup ECEL_doc 
   ///@class ECEL 
   ///@brief  [TGeoVolume] 
   class ECEL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ECEL() : AgBlock("ECEL"," [TGeoVolume]"){ 
      }; 
      ~ECEL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EPCB -- 
   ///@defgroup EPCB_doc 
   ///@class EPCB 
   ///@brief  [TGeoVolume] 
   class EPCB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EPCB() : AgBlock("EPCB"," [TGeoVolume]"){ 
      }; 
      ~EPCB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class EtofGeo0 
   /// \brief Imported from tof_v14s.root 
   class EtofGeo0 : public AgModule 
   { 
      public: 
      EtofGeo0(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~EtofGeo0(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace EtofGeo0 
#endif // __EtofGeo0__ 
