#ifndef __PipeGeo__ 
#define __PipeGeo__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace PIPEGEO // $NMSPC 
{ 
   struct pipv_t {
float version;
float pipeconfig;
int pipeflag;
int _index;
};
 
   struct _pipv_docum_ {
string version;
string pipeconfig;
string pipeflag;
string _index;
};
 
    struct _pipv_types_ {
  typedef float version;
  typedef float pipeconfig;
  typedef int pipeflag;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pipv_info {
typedef pipv_t Type;
static const char *name(){ return "pipv_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct pipv_t, version ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pipeconfig {
  static const char *name() { return  "pipeconfig"; }
  static int Offset(){ return offsetof( struct pipv_t, pipeconfig ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pipeflag {
  static const char *name() { return  "pipeflag"; }
  static int Offset(){ return offsetof( struct pipv_t, pipeflag ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pipv_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct pipg_t {
float config;
float beinnr;
float beoutr;
float beleng;
string material;
float s1innr;
float s1outr;
float s1leng;
float s2innr;
float s2outr;
float s2leng;
float s3innr;
float s3outr;
float s3leng;
float s4innr;
float s4outr;
float s4leng;
float flange1t;
float flange1r;
float conelen;
float ribnum;
float ribspa;
float ribthk;
float riboutr;
float ribcent;
float wrpinnr;
float wrpoutr;
float wrpleng;
float sldinnr;
float sldoutr;
float sldleng;
int _index;
};
 
   struct _pipg_docum_ {
string config;
string beinnr;
string beoutr;
string beleng;
string material;
string s1innr;
string s1outr;
string s1leng;
string s2innr;
string s2outr;
string s2leng;
string s3innr;
string s3outr;
string s3leng;
string s4innr;
string s4outr;
string s4leng;
string flange1t;
string flange1r;
string conelen;
string ribnum;
string ribspa;
string ribthk;
string riboutr;
string ribcent;
string wrpinnr;
string wrpoutr;
string wrpleng;
string sldinnr;
string sldoutr;
string sldleng;
string _index;
};
 
    struct _pipg_types_ {
  typedef float config;
  typedef float beinnr;
  typedef float beoutr;
  typedef float beleng;
  typedef string material;
  typedef float s1innr;
  typedef float s1outr;
  typedef float s1leng;
  typedef float s2innr;
  typedef float s2outr;
  typedef float s2leng;
  typedef float s3innr;
  typedef float s3outr;
  typedef float s3leng;
  typedef float s4innr;
  typedef float s4outr;
  typedef float s4leng;
  typedef float flange1t;
  typedef float flange1r;
  typedef float conelen;
  typedef float ribnum;
  typedef float ribspa;
  typedef float ribthk;
  typedef float riboutr;
  typedef float ribcent;
  typedef float wrpinnr;
  typedef float wrpoutr;
  typedef float wrpleng;
  typedef float sldinnr;
  typedef float sldoutr;
  typedef float sldleng;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pipg_info {
typedef pipg_t Type;
static const char *name(){ return "pipg_t"; }
struct config {
  static const char *name() { return  "config"; }
  static int Offset(){ return offsetof( struct pipg_t, config ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct beinnr {
  static const char *name() { return  "beinnr"; }
  static int Offset(){ return offsetof( struct pipg_t, beinnr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct beoutr {
  static const char *name() { return  "beoutr"; }
  static int Offset(){ return offsetof( struct pipg_t, beoutr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct beleng {
  static const char *name() { return  "beleng"; }
  static int Offset(){ return offsetof( struct pipg_t, beleng ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct material {
  static const char *name() { return  "material"; }
  static int Offset(){ return offsetof( struct pipg_t, material ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef string Type;
  static const int rank = 0;};
struct s1innr {
  static const char *name() { return  "s1innr"; }
  static int Offset(){ return offsetof( struct pipg_t, s1innr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s1outr {
  static const char *name() { return  "s1outr"; }
  static int Offset(){ return offsetof( struct pipg_t, s1outr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s1leng {
  static const char *name() { return  "s1leng"; }
  static int Offset(){ return offsetof( struct pipg_t, s1leng ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s2innr {
  static const char *name() { return  "s2innr"; }
  static int Offset(){ return offsetof( struct pipg_t, s2innr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s2outr {
  static const char *name() { return  "s2outr"; }
  static int Offset(){ return offsetof( struct pipg_t, s2outr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s2leng {
  static const char *name() { return  "s2leng"; }
  static int Offset(){ return offsetof( struct pipg_t, s2leng ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s3innr {
  static const char *name() { return  "s3innr"; }
  static int Offset(){ return offsetof( struct pipg_t, s3innr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s3outr {
  static const char *name() { return  "s3outr"; }
  static int Offset(){ return offsetof( struct pipg_t, s3outr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s3leng {
  static const char *name() { return  "s3leng"; }
  static int Offset(){ return offsetof( struct pipg_t, s3leng ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s4innr {
  static const char *name() { return  "s4innr"; }
  static int Offset(){ return offsetof( struct pipg_t, s4innr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s4outr {
  static const char *name() { return  "s4outr"; }
  static int Offset(){ return offsetof( struct pipg_t, s4outr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct s4leng {
  static const char *name() { return  "s4leng"; }
  static int Offset(){ return offsetof( struct pipg_t, s4leng ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct flange1t {
  static const char *name() { return  "flange1t"; }
  static int Offset(){ return offsetof( struct pipg_t, flange1t ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct flange1r {
  static const char *name() { return  "flange1r"; }
  static int Offset(){ return offsetof( struct pipg_t, flange1r ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct conelen {
  static const char *name() { return  "conelen"; }
  static int Offset(){ return offsetof( struct pipg_t, conelen ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ribnum {
  static const char *name() { return  "ribnum"; }
  static int Offset(){ return offsetof( struct pipg_t, ribnum ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ribspa {
  static const char *name() { return  "ribspa"; }
  static int Offset(){ return offsetof( struct pipg_t, ribspa ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ribthk {
  static const char *name() { return  "ribthk"; }
  static int Offset(){ return offsetof( struct pipg_t, ribthk ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct riboutr {
  static const char *name() { return  "riboutr"; }
  static int Offset(){ return offsetof( struct pipg_t, riboutr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ribcent {
  static const char *name() { return  "ribcent"; }
  static int Offset(){ return offsetof( struct pipg_t, ribcent ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wrpinnr {
  static const char *name() { return  "wrpinnr"; }
  static int Offset(){ return offsetof( struct pipg_t, wrpinnr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wrpoutr {
  static const char *name() { return  "wrpoutr"; }
  static int Offset(){ return offsetof( struct pipg_t, wrpoutr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wrpleng {
  static const char *name() { return  "wrpleng"; }
  static int Offset(){ return offsetof( struct pipg_t, wrpleng ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sldinnr {
  static const char *name() { return  "sldinnr"; }
  static int Offset(){ return offsetof( struct pipg_t, sldinnr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sldoutr {
  static const char *name() { return  "sldoutr"; }
  static int Offset(){ return offsetof( struct pipg_t, sldoutr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sldleng {
  static const char *name() { return  "sldleng"; }
  static int Offset(){ return offsetof( struct pipg_t, sldleng ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pipg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- PIPE -- 
   ///@defgroup PIPE_doc 
   ///@class PIPE 
   ///@brief is the STAR beam pipe mother volume [TGeoVolume] 
   class PIPE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPE() : AgBlock("PIPE","is the STAR beam pipe mother volume [TGeoVolume]"){ 
      }; 
      ~PIPE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PIPC -- 
   ///@defgroup PIPC_doc 
   ///@class PIPC 
   ///@brief is the Central Beam PIPe Volume [TGeoVolume] 
   class PIPC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPC() : AgBlock("PIPC","is the Central Beam PIPe Volume [TGeoVolume]"){ 
      }; 
      ~PIPC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAC -- 
   ///@defgroup PVAC_doc 
   ///@class PVAC 
   ///@brief is the Vacuum Volume of Be section of pipe [TGeoVolume] 
   class PVAC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAC() : AgBlock("PVAC","is the Vacuum Volume of Be section of pipe [TGeoVolume]"){ 
      }; 
      ~PVAC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PIPO -- 
   ///@defgroup PIPO_doc 
   ///@class PIPO 
   ///@brief is Steel pipe from Be to 1st flanges [TGeoVolume] 
   class PIPO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPO() : AgBlock("PIPO","is Steel pipe from Be to 1st flanges [TGeoVolume]"){ 
      }; 
      ~PIPO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAO -- 
   ///@defgroup PVAO_doc 
   ///@class PVAO 
   ///@brief is its cavity [TGeoVolume] 
   class PVAO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAO() : AgBlock("PVAO","is its cavity [TGeoVolume]"){ 
      }; 
      ~PVAO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PIPI -- 
   ///@defgroup PIPI_doc 
   ///@class PIPI 
   ///@brief is Steel pipe of the Bellow section [TGeoVolume] 
   class PIPI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPI() : AgBlock("PIPI","is Steel pipe of the Bellow section [TGeoVolume]"){ 
      }; 
      ~PIPI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAI -- 
   ///@defgroup PVAI_doc 
   ///@class PVAI 
   ///@brief is its cavity [TGeoVolume] 
   class PVAI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAI() : AgBlock("PVAI","is its cavity [TGeoVolume]"){ 
      }; 
      ~PVAI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PIPT -- 
   ///@defgroup PIPT_doc 
   ///@class PIPT 
   ///@brief is short Steel pipe of the transition section [TGeoVolume] 
   class PIPT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPT() : AgBlock("PIPT","is short Steel pipe of the transition section [TGeoVolume]"){ 
      }; 
      ~PIPT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAT -- 
   ///@defgroup PVAT_doc 
   ///@class PVAT 
   ///@brief is its cavity [TGeoVolume] 
   class PVAT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAT() : AgBlock("PVAT","is its cavity [TGeoVolume]"){ 
      }; 
      ~PVAT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PIPB -- 
   ///@defgroup PIPB_doc 
   ///@class PIPB 
   ///@brief is the beam pipe Bell reducing section [TGeoVolume] 
   class PIPB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPB() : AgBlock("PIPB","is the beam pipe Bell reducing section [TGeoVolume]"){ 
      }; 
      ~PIPB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAB -- 
   ///@defgroup PVAB_doc 
   ///@class PVAB 
   ///@brief is its cavity [TGeoVolume] 
   class PVAB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAB() : AgBlock("PVAB","is its cavity [TGeoVolume]"){ 
      }; 
      ~PVAB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PIPS -- 
   ///@defgroup PIPS_doc 
   ///@class PIPS 
   ///@brief 5 inch OD steel beam pipe starting ~4.5 m from IR [TGeoVolume] 
   class PIPS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPS() : AgBlock("PIPS","5 inch OD steel beam pipe starting ~4.5 m from IR [TGeoVolume]"){ 
      }; 
      ~PIPS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAS -- 
   ///@defgroup PVAS_doc 
   ///@class PVAS 
   ///@brief is its cavity [TGeoVolume] 
   class PVAS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAS() : AgBlock("PVAS","is its cavity [TGeoVolume]"){ 
      }; 
      ~PVAS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PFLO -- 
   ///@defgroup PFLO_doc 
   ///@class PFLO 
   ///@brief is the 1st set of flanges at ~3.9 m from IR [TGeoVolume] 
   class PFLO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PFLO() : AgBlock("PFLO","is the 1st set of flanges at ~3.9 m from IR [TGeoVolume]"){ 
      }; 
      ~PFLO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PFLT -- 
   ///@defgroup PFLT_doc 
   ///@class PFLT 
   ///@brief is the 2nd set of flanges at ~4.2 m from IR [TGeoVolume] 
   class PFLT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PFLT() : AgBlock("PFLT","is the 2nd set of flanges at ~4.2 m from IR [TGeoVolume]"){ 
      }; 
      ~PFLT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PRIS -- 
   ///@defgroup PRIS_doc 
   ///@class PRIS 
   ///@brief is the Bellow Steel Rib Set [TGeoVolume] 
   class PRIS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PRIS() : AgBlock("PRIS","is the Bellow Steel Rib Set [TGeoVolume]"){ 
      }; 
      ~PRIS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PRID -- 
   ///@defgroup PRID_doc 
   ///@class PRID 
   ///@brief is a Rib section [TGeoVolume] 
   class PRID : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PRID() : AgBlock("PRID","is a Rib section [TGeoVolume]"){ 
      }; 
      ~PRID(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PRIB -- 
   ///@defgroup PRIB_doc 
   ///@class PRIB 
   ///@brief is a Rib of Steel Bellows [TGeoVolume] 
   class PRIB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PRIB() : AgBlock("PRIB","is a Rib of Steel Bellows [TGeoVolume]"){ 
      }; 
      ~PRIB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PWRP -- 
   ///@defgroup PWRP_doc 
   ///@class PWRP 
   ///@brief is the beampipe wrap of Kapton and aluminum [TGeoVolume] 
   class PWRP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PWRP() : AgBlock("PWRP","is the beampipe wrap of Kapton and aluminum [TGeoVolume]"){ 
      }; 
      ~PWRP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSLD -- 
   ///@defgroup PSLD_doc 
   ///@class PSLD 
   ///@brief is the svt beampipe shield [TGeoVolume] 
   class PSLD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSLD() : AgBlock("PSLD","is the svt beampipe shield [TGeoVolume]"){ 
      }; 
      ~PSLD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class PipeGeo 
   /// \brief  is the geometry  of the STAR beam pipe.  
   class PipeGeo : public AgModule 
   { 
      public: 
      PipeGeo(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~PipeGeo(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace PipeGeo 
#endif // __PipeGeo__ 
