#ifndef __HcalGeo1__ 
#define __HcalGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace HCALGEO1 // $NMSPC 
{ 
   struct mcdt_t {
float version;
float x;
float y;
float z;
float dx;
float dy;
float dz;
int _index;
};
 
   struct _mcdt_docum_ {
string version;
string x;
string y;
string z;
string dx;
string dy;
string dz;
string _index;
};
 
    struct _mcdt_types_ {
  typedef float version;
  typedef float x;
  typedef float y;
  typedef float z;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mcdt_info {
typedef mcdt_t Type;
static const char *name(){ return "mcdt_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct mcdt_t, version ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct mcdt_t, x ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct mcdt_t, y ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct mcdt_t, z ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct mcdt_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct mcdt_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct mcdt_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mcdt_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct towr_t {
float version;
float dx;
float dy;
float dz;
float ntowerx;
float ntowery;
int _index;
};
 
   struct _towr_docum_ {
string version;
string dx;
string dy;
string dz;
string ntowerx;
string ntowery;
string _index;
};
 
    struct _towr_types_ {
  typedef float version;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef float ntowerx;
  typedef float ntowery;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct towr_info {
typedef towr_t Type;
static const char *name(){ return "towr_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct towr_t, version ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct towr_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct towr_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct towr_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ntowerx {
  static const char *name() { return  "ntowerx"; }
  static int Offset(){ return offsetof( struct towr_t, ntowerx ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ntowery {
  static const char *name() { return  "ntowery"; }
  static int Offset(){ return offsetof( struct towr_t, ntowery ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct towr_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct cell_t {
float version;
float dx;
float dy;
float dz;
float ncellx;
float ncelly;
float nfiberxl;
float nfiberyl;
float nfiberxs;
float nfiberys;
int _index;
};
 
   struct _cell_docum_ {
string version;
string dx;
string dy;
string dz;
string ncellx;
string ncelly;
string nfiberxl;
string nfiberyl;
string nfiberxs;
string nfiberys;
string _index;
};
 
    struct _cell_types_ {
  typedef float version;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef float ncellx;
  typedef float ncelly;
  typedef float nfiberxl;
  typedef float nfiberyl;
  typedef float nfiberxs;
  typedef float nfiberys;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct cell_info {
typedef cell_t Type;
static const char *name(){ return "cell_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct cell_t, version ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct cell_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct cell_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct cell_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ncellx {
  static const char *name() { return  "ncellx"; }
  static int Offset(){ return offsetof( struct cell_t, ncellx ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ncelly {
  static const char *name() { return  "ncelly"; }
  static int Offset(){ return offsetof( struct cell_t, ncelly ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberxl {
  static const char *name() { return  "nfiberxl"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberxl ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberyl {
  static const char *name() { return  "nfiberyl"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberyl ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberxs {
  static const char *name() { return  "nfiberxs"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberxs ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberys {
  static const char *name() { return  "nfiberys"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberys ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct cell_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fibr_t {
float version;
float rmin;
float rmax;
float dz;
float startx1;
float starty1;
float startx2;
float starty2;
float stepx;
float stepy;
int _index;
};
 
   struct _fibr_docum_ {
string version;
string rmin;
string rmax;
string dz;
string startx1;
string starty1;
string startx2;
string starty2;
string stepx;
string stepy;
string _index;
};
 
    struct _fibr_types_ {
  typedef float version;
  typedef float rmin;
  typedef float rmax;
  typedef float dz;
  typedef float startx1;
  typedef float starty1;
  typedef float startx2;
  typedef float starty2;
  typedef float stepx;
  typedef float stepy;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fibr_info {
typedef fibr_t Type;
static const char *name(){ return "fibr_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct fibr_t, version ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct fibr_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct fibr_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct fibr_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct startx1 {
  static const char *name() { return  "startx1"; }
  static int Offset(){ return offsetof( struct fibr_t, startx1 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct starty1 {
  static const char *name() { return  "starty1"; }
  static int Offset(){ return offsetof( struct fibr_t, starty1 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct startx2 {
  static const char *name() { return  "startx2"; }
  static int Offset(){ return offsetof( struct fibr_t, startx2 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct starty2 {
  static const char *name() { return  "starty2"; }
  static int Offset(){ return offsetof( struct fibr_t, starty2 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stepx {
  static const char *name() { return  "stepx"; }
  static int Offset(){ return offsetof( struct fibr_t, stepx ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stepy {
  static const char *name() { return  "stepy"; }
  static int Offset(){ return offsetof( struct fibr_t, stepy ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fibr_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct prsw_t {
float dbox[3];
float xoff[4];
float yoff[4];
float zoff[4];
float dz[4];
float dhole;
int ntype;
int nprs[2];
float dprs[3];
int nskipv;
int nskiph;
float dycut;
float dlg[3];
float dsipm[4];
float dzbbd[4];
float dxbbd[2];
int _index;
};
 
   struct _prsw_docum_ {
string dbox;
string xoff;
string yoff;
string zoff;
string dz;
string dhole;
string ntype;
string nprs;
string dprs;
string nskipv;
string nskiph;
string dycut;
string dlg;
string dsipm;
string dzbbd;
string dxbbd;
string _index;
};
 
    struct _prsw_types_ {
  typedef float dbox[3];
  typedef float xoff[4];
  typedef float yoff[4];
  typedef float zoff[4];
  typedef float dz[4];
  typedef float dhole;
  typedef int ntype;
  typedef int nprs[2];
  typedef float dprs[3];
  typedef int nskipv;
  typedef int nskiph;
  typedef float dycut;
  typedef float dlg[3];
  typedef float dsipm[4];
  typedef float dzbbd[4];
  typedef float dxbbd[2];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct prsw_info {
typedef prsw_t Type;
static const char *name(){ return "prsw_t"; }
struct dbox {
  static const char *name() { return  "dbox"; }
  static int Offset(){ return offsetof( struct prsw_t, dbox ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct xoff {
  static const char *name() { return  "xoff"; }
  static int Offset(){ return offsetof( struct prsw_t, xoff ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct yoff {
  static const char *name() { return  "yoff"; }
  static int Offset(){ return offsetof( struct prsw_t, yoff ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct zoff {
  static const char *name() { return  "zoff"; }
  static int Offset(){ return offsetof( struct prsw_t, zoff ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct prsw_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct dhole {
  static const char *name() { return  "dhole"; }
  static int Offset(){ return offsetof( struct prsw_t, dhole ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ntype {
  static const char *name() { return  "ntype"; }
  static int Offset(){ return offsetof( struct prsw_t, ntype ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct nprs {
  static const char *name() { return  "nprs"; }
  static int Offset(){ return offsetof( struct prsw_t, nprs ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type[2];
};
struct dprs {
  static const char *name() { return  "dprs"; }
  static int Offset(){ return offsetof( struct prsw_t, dprs ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct nskipv {
  static const char *name() { return  "nskipv"; }
  static int Offset(){ return offsetof( struct prsw_t, nskipv ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct nskiph {
  static const char *name() { return  "nskiph"; }
  static int Offset(){ return offsetof( struct prsw_t, nskiph ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct dycut {
  static const char *name() { return  "dycut"; }
  static int Offset(){ return offsetof( struct prsw_t, dycut ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dlg {
  static const char *name() { return  "dlg"; }
  static int Offset(){ return offsetof( struct prsw_t, dlg ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct dsipm {
  static const char *name() { return  "dsipm"; }
  static int Offset(){ return offsetof( struct prsw_t, dsipm ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct dzbbd {
  static const char *name() { return  "dzbbd"; }
  static int Offset(){ return offsetof( struct prsw_t, dzbbd ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct dxbbd {
  static const char *name() { return  "dxbbd"; }
  static int Offset(){ return offsetof( struct prsw_t, dxbbd ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[2];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct prsw_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)prsw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct wpfm_t {
float poled[4];
float polep[3];
float istrd[4];
float ist1p[3];
float ist2p[3];
float ustfd[4];
float ustfp[3];
float ustnd[4];
float ustnp[3];
float ustsd[4];
float ustsp[3];
int _index;
};
 
   struct _wpfm_docum_ {
string poled;
string polep;
string istrd;
string ist1p;
string ist2p;
string ustfd;
string ustfp;
string ustnd;
string ustnp;
string ustsd;
string ustsp;
string _index;
};
 
    struct _wpfm_types_ {
  typedef float poled[4];
  typedef float polep[3];
  typedef float istrd[4];
  typedef float ist1p[3];
  typedef float ist2p[3];
  typedef float ustfd[4];
  typedef float ustfp[3];
  typedef float ustnd[4];
  typedef float ustnp[3];
  typedef float ustsd[4];
  typedef float ustsp[3];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct wpfm_info {
typedef wpfm_t Type;
static const char *name(){ return "wpfm_t"; }
struct poled {
  static const char *name() { return  "poled"; }
  static int Offset(){ return offsetof( struct wpfm_t, poled ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct polep {
  static const char *name() { return  "polep"; }
  static int Offset(){ return offsetof( struct wpfm_t, polep ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct istrd {
  static const char *name() { return  "istrd"; }
  static int Offset(){ return offsetof( struct wpfm_t, istrd ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct ist1p {
  static const char *name() { return  "ist1p"; }
  static int Offset(){ return offsetof( struct wpfm_t, ist1p ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct ist2p {
  static const char *name() { return  "ist2p"; }
  static int Offset(){ return offsetof( struct wpfm_t, ist2p ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct ustfd {
  static const char *name() { return  "ustfd"; }
  static int Offset(){ return offsetof( struct wpfm_t, ustfd ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct ustfp {
  static const char *name() { return  "ustfp"; }
  static int Offset(){ return offsetof( struct wpfm_t, ustfp ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct ustnd {
  static const char *name() { return  "ustnd"; }
  static int Offset(){ return offsetof( struct wpfm_t, ustnd ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct ustnp {
  static const char *name() { return  "ustnp"; }
  static int Offset(){ return offsetof( struct wpfm_t, ustnp ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct ustsd {
  static const char *name() { return  "ustsd"; }
  static int Offset(){ return offsetof( struct wpfm_t, ustsd ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[4];
};
struct ustsp {
  static const char *name() { return  "ustsp"; }
  static int Offset(){ return offsetof( struct wpfm_t, ustsp ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[3];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct wpfm_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)wpfm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- HCMO -- 
   ///@defgroup HCMO_doc 
   ///@class HCMO 
   ///@brief Mother Calorimeter [TGeoVolume] 
   class HCMO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCMO() : AgBlock("HCMO","Mother Calorimeter [TGeoVolume]"){ 
      }; 
      ~HCMO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HTWR -- 
   ///@defgroup HTWR_doc 
   ///@class HTWR 
   ///@brief Towrs  of Calorimeter [TGeoVolume] 
   class HTWR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HTWR() : AgBlock("HTWR","Towrs  of Calorimeter [TGeoVolume]"){ 
      }; 
      ~HTWR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCES -- 
   ///@defgroup HCES_doc 
   ///@class HCES 
   ///@brief 3*3 cell in tower, HCES has 15*15 fibers [TGeoVolume] 
   class HCES : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCES() : AgBlock("HCES","3*3 cell in tower, HCES has 15*15 fibers [TGeoVolume]"){ 
      }; 
      ~HCES(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCEL -- 
   ///@defgroup HCEL_doc 
   ///@class HCEL 
   ///@brief 3*3 cell in tower, HCES has 16*16 fibers [TGeoVolume] 
   class HCEL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCEL() : AgBlock("HCEL","3*3 cell in tower, HCES has 16*16 fibers [TGeoVolume]"){ 
      }; 
      ~HCEL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCSX -- 
   ///@defgroup HCSX_doc 
   ///@class HCSX 
   ///@brief 3*3 cell in tower x divisions [TGeoVolume] 
   class HCSX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCSX() : AgBlock("HCSX","3*3 cell in tower x divisions [TGeoVolume]"){ 
      }; 
      ~HCSX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCSY -- 
   ///@defgroup HCSY_doc 
   ///@class HCSY 
   ///@brief 3*3 cell in tower y divisions [TGeoVolume] 
   class HCSY : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCSY() : AgBlock("HCSY","3*3 cell in tower y divisions [TGeoVolume]"){ 
      }; 
      ~HCSY(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCLX -- 
   ///@defgroup HCLX_doc 
   ///@class HCLX 
   ///@brief 3*3 cell in tower x divisions [TGeoVolume] 
   class HCLX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCLX() : AgBlock("HCLX","3*3 cell in tower x divisions [TGeoVolume]"){ 
      }; 
      ~HCLX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCLY -- 
   ///@defgroup HCLY_doc 
   ///@class HCLY 
   ///@brief 3*3 cell in tower y divisions [TGeoVolume] 
   class HCLY : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCLY() : AgBlock("HCLY","3*3 cell in tower y divisions [TGeoVolume]"){ 
      }; 
      ~HCLY(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HFIB -- 
   ///@defgroup HFIB_doc 
   ///@class HFIB 
   ///@brief fiber in cells [TGeoVolume] 
   class HFIB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HFIB() : AgBlock("HFIB","fiber in cells [TGeoVolume]"){ 
      }; 
      ~HFIB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HFIC -- 
   ///@defgroup HFIC_doc 
   ///@class HFIC 
   ///@brief fiber in cells [TGeoVolume] 
   class HFIC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HFIC() : AgBlock("HFIC","fiber in cells [TGeoVolume]"){ 
      }; 
      ~HFIC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HACL -- 
   ///@defgroup HACL_doc 
   ///@class HACL 
   ///@brief  Aluminum suporting cells [TGeoVolume] 
   class HACL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HACL() : AgBlock("HACL"," Aluminum suporting cells [TGeoVolume]"){ 
      }; 
      ~HACL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FPRS -- 
   ///@defgroup FPRS_doc 
   ///@class FPRS 
   ///@brief is box for plastic schinti FMS pre-shower detectors [TGeoVolume] 
   class FPRS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FPRS() : AgBlock("FPRS","is box for plastic schinti FMS pre-shower detectors [TGeoVolume]"){ 
      }; 
      ~FPRS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FPLY -- 
   ///@defgroup FPLY_doc 
   ///@class FPLY 
   ///@brief is a layer of FMS Preshower [TGeoVolume] 
   class FPLY : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FPLY() : AgBlock("FPLY","is a layer of FMS Preshower [TGeoVolume]"){ 
      }; 
      ~FPLY(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FPBB -- 
   ///@defgroup FPBB_doc 
   ///@class FPBB 
   ///@brief is the G10 back board [TGeoVolume] 
   class FPBB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FPBB() : AgBlock("FPBB","is the G10 back board [TGeoVolume]"){ 
      }; 
      ~FPBB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FPPB -- 
   ///@defgroup FPPB_doc 
   ///@class FPPB 
   ///@brief is FMS PS Pb converter [TGeoVolume] 
   class FPPB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FPPB() : AgBlock("FPPB","is FMS PS Pb converter [TGeoVolume]"){ 
      }; 
      ~FPPB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FPSC -- 
   ///@defgroup FPSC_doc 
   ///@class FPSC 
   ///@brief is a piece of scintillator in FMS Preshower [TGeoVolume] 
   class FPSC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FPSC() : AgBlock("FPSC","is a piece of scintillator in FMS Preshower [TGeoVolume]"){ 
      }; 
      ~FPSC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FLIG -- 
   ///@defgroup FLIG_doc 
   ///@class FLIG 
   ///@brief is a light guide + SiPM board for Preshower [TGeoVolume] 
   class FLIG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FLIG() : AgBlock("FLIG","is a light guide + SiPM board for Preshower [TGeoVolume]"){ 
      }; 
      ~FLIG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FLLG -- 
   ///@defgroup FLLG_doc 
   ///@class FLLG 
   ///@brief is a light guide + SiPM board for Preshower for large [TGeoVolume] 
   class FLLG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FLLG() : AgBlock("FLLG","is a light guide + SiPM board for Preshower for large [TGeoVolume]"){ 
      }; 
      ~FLLG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FLBA -- 
   ///@defgroup FLBA_doc 
   ///@class FLBA 
   ///@brief is a light guide base for Preshower [TGeoVolume] 
   class FLBA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FLBA() : AgBlock("FLBA","is a light guide base for Preshower [TGeoVolume]"){ 
      }; 
      ~FLBA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FBLL -- 
   ///@defgroup FBLL_doc 
   ///@class FBLL 
   ///@brief is a light guide base for Preshower large [TGeoVolume] 
   class FBLL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FBLL() : AgBlock("FBLL","is a light guide base for Preshower large [TGeoVolume]"){ 
      }; 
      ~FBLL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FLCO -- 
   ///@defgroup FLCO_doc 
   ///@class FLCO 
   ///@brief is a light guide cone for Preshower [TGeoVolume] 
   class FLCO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FLCO() : AgBlock("FLCO","is a light guide cone for Preshower [TGeoVolume]"){ 
      }; 
      ~FLCO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FCLL -- 
   ///@defgroup FCLL_doc 
   ///@class FCLL 
   ///@brief is a light guide cone for Preshower large [TGeoVolume] 
   class FCLL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FCLL() : AgBlock("FCLL","is a light guide cone for Preshower large [TGeoVolume]"){ 
      }; 
      ~FCLL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FPMT -- 
   ///@defgroup FPMT_doc 
   ///@class FPMT 
   ///@brief is a SiPM board for Preshower [TGeoVolume] 
   class FPMT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FPMT() : AgBlock("FPMT","is a SiPM board for Preshower [TGeoVolume]"){ 
      }; 
      ~FPMT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FFEE -- 
   ///@defgroup FFEE_doc 
   ///@class FFEE 
   ///@brief is a FEE board for Preshower [TGeoVolume] 
   class FFEE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FFEE() : AgBlock("FFEE","is a FEE board for Preshower [TGeoVolume]"){ 
      }; 
      ~FFEE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- WPPL -- 
   ///@defgroup WPPL_doc 
   ///@class WPPL 
   ///@brief is a pole for west platform [TGeoVolume] 
   class WPPL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      WPPL() : AgBlock("WPPL","is a pole for west platform [TGeoVolume]"){ 
      }; 
      ~WPPL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- WPIS -- 
   ///@defgroup WPIS_doc 
   ///@class WPIS 
   ///@brief is a I-struct for west platform [TGeoVolume] 
   class WPIS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      WPIS() : AgBlock("WPIS","is a I-struct for west platform [TGeoVolume]"){ 
      }; 
      ~WPIS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- WPUF -- 
   ///@defgroup WPUF_doc 
   ///@class WPUF 
   ///@brief is a front U-struct for west platform [TGeoVolume] 
   class WPUF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      WPUF() : AgBlock("WPUF","is a front U-struct for west platform [TGeoVolume]"){ 
      }; 
      ~WPUF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- WPUN -- 
   ///@defgroup WPUN_doc 
   ///@class WPUN 
   ///@brief is a north U-struct for west platform [TGeoVolume] 
   class WPUN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      WPUN() : AgBlock("WPUN","is a north U-struct for west platform [TGeoVolume]"){ 
      }; 
      ~WPUN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- WPUS -- 
   ///@defgroup WPUS_doc 
   ///@class WPUS 
   ///@brief is a south U-struct for west platform [TGeoVolume] 
   class WPUS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      WPUS() : AgBlock("WPUS","is a south U-struct for west platform [TGeoVolume]"){ 
      }; 
      ~WPUS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- WPAR -- 
   ///@defgroup WPAR_doc 
   ///@class WPAR 
   ///@brief is a platform structs air [TGeoVolume] 
   class WPAR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      WPAR() : AgBlock("WPAR","is a platform structs air [TGeoVolume]"){ 
      }; 
      ~WPAR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class HcalGeo1 
   /// \brief  forward hadronic calorimeter, Proposed Full Geometry, 2016 
   class HcalGeo1 : public AgModule 
   { 
      public: 
      HcalGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~HcalGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace HcalGeo1 
#endif // __HcalGeo1__ 
