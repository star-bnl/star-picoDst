#ifndef __FTRO_CONFIG__ 
#define __FTRO_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/FtroGeo.h" 
namespace FTRO { //
struct FTROof {
  static const char *name()    { return "FTROof"; }
  static const char *comment() { return "FTPC readout off"; }
  static const char *module()  { return "FtroGeo"; }
  static       bool  list();
  typedef FTROGEO::FtroGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTRO { //
struct FTROon {
  static const char *name()    { return "FTROon"; }
  static const char *comment() { return "Default configuration for the FTPC readout"; }
  static const char *module()  { return "FtroGeo"; }
  static       bool  list();
  typedef FTROGEO::FtroGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTRO { //
struct FTRO01 {
  static const char *name()    { return "FTRO01"; }
  static const char *comment() { return "Default configuration for the FTPC readout"; }
  static const char *module()  { return "FtroGeo"; }
  static       bool  list();
  typedef FTROGEO::FtroGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
