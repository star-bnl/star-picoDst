#ifndef __MAGP_CONFIG__ 
#define __MAGP_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/MagpGeo.h" 
namespace MAGP { //
struct MAGPof {
  static const char *name()    { return "MAGPof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "MagpGeo"; }
  static       bool  list();
  typedef MAGPGEO::MagpGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MAGP { //
struct MAGPon {
  static const char *name()    { return "MAGPon"; }
  static const char *comment() { return "STAR Magnet"; }
  static const char *module()  { return "MagpGeo"; }
  static       bool  list();
  typedef MAGPGEO::MagpGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MAGP { //
struct MAGPv1 {
  static const char *name()    { return "MAGPv1"; }
  static const char *comment() { return "Improved STAR Magnet"; }
  static const char *module()  { return "MagpGeo"; }
  static       bool  list();
  typedef MAGPGEO::MagpGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
