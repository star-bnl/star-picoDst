#ifndef __IDSM_CONFIG__ 
#define __IDSM_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/IdsmGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/IdsmGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/IdsmGeo2a.h" 
namespace IDSM { //
struct IDSMof {
  static const char *name()    { return "IDSMof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "IdsmGeo1"; }
  static       bool  list();
  typedef IDSMGEO1::IdsmGeo1 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace IDSM { //
struct IDSMon {
  static const char *name()    { return "IDSMon"; }
  static const char *comment() { return "Inner detector support module"; }
  static const char *module()  { return "IdsmGeo1"; }
  static       bool  list();
  typedef IDSMGEO1::IdsmGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace IDSM { //
struct IDSM01 {
  static const char *name()    { return "IDSM01"; }
  static const char *comment() { return "Inner detector support module"; }
  static const char *module()  { return "IdsmGeo1"; }
  static       bool  list();
  typedef IDSMGEO1::IdsmGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace IDSM { //
struct IDSM02 {
  static const char *name()    { return "IDSM02"; }
  static const char *comment() { return "Inner detector support module"; }
  static const char *module()  { return "IdsmGeo2"; }
  static       bool  list();
  typedef IDSMGEO2::IdsmGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace IDSM { //
struct IDSM14 {
  static const char *name()    { return "IDSM14"; }
  static const char *comment() { return "Inner detector support module"; }
  static const char *module()  { return "IdsmGeo2"; }
  static       bool  list();
  typedef IDSMGEO2::IdsmGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace IDSM { //
struct IDSM02a {
  static const char *name()    { return "IDSM02a"; }
  static const char *comment() { return "Inner detector support module"; }
  static const char *module()  { return "IdsmGeo2a"; }
  static       bool  list();
  typedef IDSMGEO2A::IdsmGeo2a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace IDSM { //
struct IDSM14a {
  static const char *name()    { return "IDSM14a"; }
  static const char *comment() { return "Inner detector support module"; }
  static const char *module()  { return "IdsmGeo2a"; }
  static       bool  list();
  typedef IDSMGEO2A::IdsmGeo2a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
