#ifndef __SisdGeo__ 
#define __SisdGeo__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace SISDGEO // $NMSPC 
{ 
   struct ssdp_t {
float version;
float config;
int placement;
int _index;
};
 
   struct _ssdp_docum_ {
string version;
string config;
string placement;
string _index;
};
 
    struct _ssdp_types_ {
  typedef float version;
  typedef float config;
  typedef int placement;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct ssdp_info {
typedef ssdp_t Type;
static const char *name(){ return "ssdp_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct ssdp_t, version ); }
  static void* address(){ 
         long long iadd = (long long)ssdp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct config {
  static const char *name() { return  "config"; }
  static int Offset(){ return offsetof( struct ssdp_t, config ); }
  static void* address(){ 
         long long iadd = (long long)ssdp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct placement {
  static const char *name() { return  "placement"; }
  static int Offset(){ return offsetof( struct ssdp_t, placement ); }
  static void* address(){ 
         long long iadd = (long long)ssdp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct ssdp_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)ssdp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct sfpa_t {
float version;
float rmin;
float rmax;
float len;
float rad;
float nssd;
float dmwid;
float dmthk;
float dmlen;
float smwid;
float smthk;
float smlen;
float sslen;
float wplen;
float sdlen;
float tilt;
float cprad;
float cpral;
float cfrad;
float gpthk;
int laddermap[20];
float ladderangle[20];
float laddertilt[20];
float ladderradius[20];
int _index;
};
 
   struct _sfpa_docum_ {
string version;
string rmin;
string rmax;
string len;
string rad;
string nssd;
string dmwid;
string dmthk;
string dmlen;
string smwid;
string smthk;
string smlen;
string sslen;
string wplen;
string sdlen;
string tilt;
string cprad;
string cpral;
string cfrad;
string gpthk;
string laddermap;
string ladderangle;
string laddertilt;
string ladderradius;
string _index;
};
 
    struct _sfpa_types_ {
  typedef float version;
  typedef float rmin;
  typedef float rmax;
  typedef float len;
  typedef float rad;
  typedef float nssd;
  typedef float dmwid;
  typedef float dmthk;
  typedef float dmlen;
  typedef float smwid;
  typedef float smthk;
  typedef float smlen;
  typedef float sslen;
  typedef float wplen;
  typedef float sdlen;
  typedef float tilt;
  typedef float cprad;
  typedef float cpral;
  typedef float cfrad;
  typedef float gpthk;
  typedef int laddermap[20];
  typedef float ladderangle[20];
  typedef float laddertilt[20];
  typedef float ladderradius[20];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct sfpa_info {
typedef sfpa_t Type;
static const char *name(){ return "sfpa_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct sfpa_t, version ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct sfpa_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct sfpa_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct len {
  static const char *name() { return  "len"; }
  static int Offset(){ return offsetof( struct sfpa_t, len ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rad {
  static const char *name() { return  "rad"; }
  static int Offset(){ return offsetof( struct sfpa_t, rad ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nssd {
  static const char *name() { return  "nssd"; }
  static int Offset(){ return offsetof( struct sfpa_t, nssd ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dmwid {
  static const char *name() { return  "dmwid"; }
  static int Offset(){ return offsetof( struct sfpa_t, dmwid ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dmthk {
  static const char *name() { return  "dmthk"; }
  static int Offset(){ return offsetof( struct sfpa_t, dmthk ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dmlen {
  static const char *name() { return  "dmlen"; }
  static int Offset(){ return offsetof( struct sfpa_t, dmlen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smwid {
  static const char *name() { return  "smwid"; }
  static int Offset(){ return offsetof( struct sfpa_t, smwid ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smthk {
  static const char *name() { return  "smthk"; }
  static int Offset(){ return offsetof( struct sfpa_t, smthk ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smlen {
  static const char *name() { return  "smlen"; }
  static int Offset(){ return offsetof( struct sfpa_t, smlen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sslen {
  static const char *name() { return  "sslen"; }
  static int Offset(){ return offsetof( struct sfpa_t, sslen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wplen {
  static const char *name() { return  "wplen"; }
  static int Offset(){ return offsetof( struct sfpa_t, wplen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sdlen {
  static const char *name() { return  "sdlen"; }
  static int Offset(){ return offsetof( struct sfpa_t, sdlen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tilt {
  static const char *name() { return  "tilt"; }
  static int Offset(){ return offsetof( struct sfpa_t, tilt ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cprad {
  static const char *name() { return  "cprad"; }
  static int Offset(){ return offsetof( struct sfpa_t, cprad ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cpral {
  static const char *name() { return  "cpral"; }
  static int Offset(){ return offsetof( struct sfpa_t, cpral ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cfrad {
  static const char *name() { return  "cfrad"; }
  static int Offset(){ return offsetof( struct sfpa_t, cfrad ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gpthk {
  static const char *name() { return  "gpthk"; }
  static int Offset(){ return offsetof( struct sfpa_t, gpthk ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct laddermap {
  static const char *name() { return  "laddermap"; }
  static int Offset(){ return offsetof( struct sfpa_t, laddermap ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type[20];
};
struct ladderangle {
  static const char *name() { return  "ladderangle"; }
  static int Offset(){ return offsetof( struct sfpa_t, ladderangle ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[20];
};
struct laddertilt {
  static const char *name() { return  "laddertilt"; }
  static int Offset(){ return offsetof( struct sfpa_t, laddertilt ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[20];
};
struct ladderradius {
  static const char *name() { return  "ladderradius"; }
  static int Offset(){ return offsetof( struct sfpa_t, ladderradius ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[20];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct sfpa_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- SFMO -- 
   ///@defgroup SFMO_doc 
   ///@class SFMO 
   ///@brief is the mother of all Silicon Strip Detector volumes [TGeoVolume] 
   class SFMO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFMO() : AgBlock("SFMO","is the mother of all Silicon Strip Detector volumes [TGeoVolume]"){ 
      }; 
      ~SFMO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFLM -- 
   ///@defgroup SFLM_doc 
   ///@class SFLM 
   ///@brief is the mother of the ladder [TGeoVolume] 
   class SFLM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFLM() : AgBlock("SFLM","is the mother of the ladder [TGeoVolume]"){ 
      }; 
      ~SFLM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFDM -- 
   ///@defgroup SFDM_doc 
   ///@class SFDM 
   ///@brief is the mother of the detectors [TGeoVolume] 
   class SFDM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFDM() : AgBlock("SFDM","is the mother of the detectors [TGeoVolume]"){ 
      }; 
      ~SFDM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFSW -- 
   ///@defgroup SFSW_doc 
   ///@class SFSW 
   ///@brief is a single wafer container [TGeoVolume] 
   class SFSW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFSW() : AgBlock("SFSW","is a single wafer container [TGeoVolume]"){ 
      }; 
      ~SFSW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFSD -- 
   ///@defgroup SFSD_doc 
   ///@class SFSD 
   ///@brief is the strip detector [TGeoVolume] 
   class SFSD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFSD() : AgBlock("SFSD","is the strip detector [TGeoVolume]"){ 
      }; 
      ~SFSD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFSM -- 
   ///@defgroup SFSM_doc 
   ///@class SFSM 
   ///@brief is the mother of the ladder struct. [TGeoVolume] 
   class SFSM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFSM() : AgBlock("SFSM","is the mother of the ladder struct. [TGeoVolume]"){ 
      }; 
      ~SFSM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFSS -- 
   ///@defgroup SFSS_doc 
   ///@class SFSS 
   ///@brief is the subvolume of the mother struct. [TGeoVolume] 
   class SFSS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFSS() : AgBlock("SFSS","is the subvolume of the mother struct. [TGeoVolume]"){ 
      }; 
      ~SFSS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFCP -- 
   ///@defgroup SFCP_doc 
   ///@class SFCP 
   ///@brief is the cooling pipe [TGeoVolume] 
   class SFCP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFCP() : AgBlock("SFCP","is the cooling pipe [TGeoVolume]"){ 
      }; 
      ~SFCP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFCW -- 
   ///@defgroup SFCW_doc 
   ///@class SFCW 
   ///@brief is the water cylinder in the cooling pipe [TGeoVolume] 
   class SFCW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFCW() : AgBlock("SFCW","is the water cylinder in the cooling pipe [TGeoVolume]"){ 
      }; 
      ~SFCW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFCF -- 
   ///@defgroup SFCF_doc 
   ///@class SFCF 
   ///@brief is the carbon fiber structure container [TGeoVolume] 
   class SFCF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFCF() : AgBlock("SFCF","is the carbon fiber structure container [TGeoVolume]"){ 
      }; 
      ~SFCF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFCT -- 
   ///@defgroup SFCT_doc 
   ///@class SFCT 
   ///@brief is the carbon fiber tube [TGeoVolume] 
   class SFCT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFCT() : AgBlock("SFCT","is the carbon fiber tube [TGeoVolume]"){ 
      }; 
      ~SFCT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFCX -- 
   ///@defgroup SFCX_doc 
   ///@class SFCX 
   ///@brief is the carbon fiber tube [TGeoVolume] 
   class SFCX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFCX() : AgBlock("SFCX","is the carbon fiber tube [TGeoVolume]"){ 
      }; 
      ~SFCX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class SisdGeo 
   /// \brief   is the Silicon Strip Detector  
   class SisdGeo : public AgModule 
   { 
      public: 
      SisdGeo(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~SisdGeo(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace SisdGeo 
#endif // __SisdGeo__ 
