#ifndef __PSUP_CONFIG__ 
#define __PSUP_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PsupGeo.h" 
namespace PSUP { //
struct PSUPof {
  static const char *name()    { return "PSUPof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "PsupGeo"; }
  static       bool  list();
  typedef PSUPGEO::PsupGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PSUP { //
struct PSUP01 {
  static const char *name()    { return "PSUP01"; }
  static const char *comment() { return "Pixel D-tube"; }
  static const char *module()  { return "PsupGeo"; }
  static       bool  list();
  typedef PSUPGEO::PsupGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
