#ifndef __TutrGeo2__ 
#define __TutrGeo2__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace TUTRGEO2 // $NMSPC 
{ 
   // ---------------------------------------------------------------------- TUTR -- 
   ///@defgroup TUTR_doc 
   ///@class TUTR 
   ///@brief Main volume in the AGML tutorial geometry [TGeoVolume] 
   class TUTR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TUTR() : AgBlock("TUTR","Main volume in the AGML tutorial geometry [TGeoVolume]"){ 
      }; 
      ~TUTR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ABOX -- 
   ///@defgroup ABOX_doc 
   ///@class ABOX 
   ///@brief A volume which is a box in the tutorial [TGeoVolume] 
   class ABOX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ABOX() : AgBlock("ABOX","A volume which is a box in the tutorial [TGeoVolume]"){ 
      }; 
      ~ABOX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ATUB -- 
   ///@defgroup ATUB_doc 
   ///@class ATUB 
   ///@brief A TUBE with innner and outer radius [TGeoVolume] 
   class ATUB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ATUB() : AgBlock("ATUB","A TUBE with innner and outer radius [TGeoVolume]"){ 
      }; 
      ~ATUB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ATBS -- 
   ///@defgroup ATBS_doc 
   ///@class ATBS 
   ///@brief A TUBE segment with innner and outer radius... and limits in phi [TGeoVolume] 
   class ATBS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ATBS() : AgBlock("ATBS","A TUBE segment with innner and outer radius... and limits in phi [TGeoVolume]"){ 
      }; 
      ~ATBS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ACON -- 
   ///@defgroup ACON_doc 
   ///@class ACON 
   ///@brief A CONE with innner and outer radius [TGeoVolume] 
   class ACON : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ACON() : AgBlock("ACON","A CONE with innner and outer radius [TGeoVolume]"){ 
      }; 
      ~ACON(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ACNS -- 
   ///@defgroup ACNS_doc 
   ///@class ACNS 
   ///@brief A CONE segment with innner and outer radius... and limits in phi [TGeoVolume] 
   class ACNS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ACNS() : AgBlock("ACNS","A CONE segment with innner and outer radius... and limits in phi [TGeoVolume]"){ 
      }; 
      ~ACNS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class TutrGeo2 
   /// \brief Tutorial Geometry 1 
   class TutrGeo2 : public AgModule 
   { 
      public: 
      TutrGeo2(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~TutrGeo2(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace TutrGeo2 
#endif // __TutrGeo2__ 
