#ifndef __ETOF_CONFIG__ 
#define __ETOF_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/EtofGeo0.h" 
namespace ETOF { //
struct ETOFof {
  static const char *name()    { return "ETOFof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "EtofGeo0"; }
  static       bool  list();
  typedef ETOFGEO0::EtofGeo0 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ETOF { //
struct ETOFv14s {
  static const char *name()    { return "ETOFv14s"; }
  static const char *comment() { return "tof_v14s.root 2018 install"; }
  static const char *module()  { return "EtofGeo0"; }
  static       bool  list();
  typedef ETOFGEO0::EtofGeo0 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ETOF { //
struct ETOFv14f {
  static const char *name()    { return "ETOFv14f"; }
  static const char *comment() { return "tof_v14s.root full"; }
  static const char *module()  { return "EtofGeo0"; }
  static       bool  list();
  typedef ETOFGEO0::EtofGeo0 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
