#ifndef __SisdGeo1__ 
#define __SisdGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace SISDGEO1 // $NMSPC 
{ 
   struct ssdp_t {
float version;
float config;
int placement;
int _index;
};
 
   struct _ssdp_docum_ {
string version;
string config;
string placement;
string _index;
};
 
    struct _ssdp_types_ {
  typedef float version;
  typedef float config;
  typedef int placement;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct ssdp_info {
typedef ssdp_t Type;
static const char *name(){ return "ssdp_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct ssdp_t, version ); }
  static void* address(){ 
         long long iadd = (long long)ssdp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct config {
  static const char *name() { return  "config"; }
  static int Offset(){ return offsetof( struct ssdp_t, config ); }
  static void* address(){ 
         long long iadd = (long long)ssdp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct placement {
  static const char *name() { return  "placement"; }
  static int Offset(){ return offsetof( struct ssdp_t, placement ); }
  static void* address(){ 
         long long iadd = (long long)ssdp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct ssdp_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)ssdp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct sfpb_t {
float hhight;
float khight;
float hbase;
float kbase;
float fsize;
float zcoor;
int _index;
};
 
   struct _sfpb_docum_ {
string hhight;
string khight;
string hbase;
string kbase;
string fsize;
string zcoor;
string _index;
};
 
    struct _sfpb_types_ {
  typedef float hhight;
  typedef float khight;
  typedef float hbase;
  typedef float kbase;
  typedef float fsize;
  typedef float zcoor;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct sfpb_info {
typedef sfpb_t Type;
static const char *name(){ return "sfpb_t"; }
struct hhight {
  static const char *name() { return  "hhight"; }
  static int Offset(){ return offsetof( struct sfpb_t, hhight ); }
  static void* address(){ 
         long long iadd = (long long)sfpb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct khight {
  static const char *name() { return  "khight"; }
  static int Offset(){ return offsetof( struct sfpb_t, khight ); }
  static void* address(){ 
         long long iadd = (long long)sfpb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct hbase {
  static const char *name() { return  "hbase"; }
  static int Offset(){ return offsetof( struct sfpb_t, hbase ); }
  static void* address(){ 
         long long iadd = (long long)sfpb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct kbase {
  static const char *name() { return  "kbase"; }
  static int Offset(){ return offsetof( struct sfpb_t, kbase ); }
  static void* address(){ 
         long long iadd = (long long)sfpb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fsize {
  static const char *name() { return  "fsize"; }
  static int Offset(){ return offsetof( struct sfpb_t, fsize ); }
  static void* address(){ 
         long long iadd = (long long)sfpb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zcoor {
  static const char *name() { return  "zcoor"; }
  static int Offset(){ return offsetof( struct sfpb_t, zcoor ); }
  static void* address(){ 
         long long iadd = (long long)sfpb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct sfpb_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)sfpb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct sfpa_t {
float version;
float rmin;
float rmax;
float len;
float rad;
float nssd;
float dmwid;
float dmthk;
float dmlen;
float smwid;
float smthk;
float smlen;
float sslen;
float wplen;
float sdlen;
float tilt;
float cprad;
float cpral;
float cfrad;
float gpthk;
int laddermap[20];
float ladderangle[20];
float laddertilt[20];
float ladderradius[20];
int _index;
};
 
   struct _sfpa_docum_ {
string version;
string rmin;
string rmax;
string len;
string rad;
string nssd;
string dmwid;
string dmthk;
string dmlen;
string smwid;
string smthk;
string smlen;
string sslen;
string wplen;
string sdlen;
string tilt;
string cprad;
string cpral;
string cfrad;
string gpthk;
string laddermap;
string ladderangle;
string laddertilt;
string ladderradius;
string _index;
};
 
    struct _sfpa_types_ {
  typedef float version;
  typedef float rmin;
  typedef float rmax;
  typedef float len;
  typedef float rad;
  typedef float nssd;
  typedef float dmwid;
  typedef float dmthk;
  typedef float dmlen;
  typedef float smwid;
  typedef float smthk;
  typedef float smlen;
  typedef float sslen;
  typedef float wplen;
  typedef float sdlen;
  typedef float tilt;
  typedef float cprad;
  typedef float cpral;
  typedef float cfrad;
  typedef float gpthk;
  typedef int laddermap[20];
  typedef float ladderangle[20];
  typedef float laddertilt[20];
  typedef float ladderradius[20];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct sfpa_info {
typedef sfpa_t Type;
static const char *name(){ return "sfpa_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct sfpa_t, version ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct sfpa_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct sfpa_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct len {
  static const char *name() { return  "len"; }
  static int Offset(){ return offsetof( struct sfpa_t, len ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rad {
  static const char *name() { return  "rad"; }
  static int Offset(){ return offsetof( struct sfpa_t, rad ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nssd {
  static const char *name() { return  "nssd"; }
  static int Offset(){ return offsetof( struct sfpa_t, nssd ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dmwid {
  static const char *name() { return  "dmwid"; }
  static int Offset(){ return offsetof( struct sfpa_t, dmwid ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dmthk {
  static const char *name() { return  "dmthk"; }
  static int Offset(){ return offsetof( struct sfpa_t, dmthk ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dmlen {
  static const char *name() { return  "dmlen"; }
  static int Offset(){ return offsetof( struct sfpa_t, dmlen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smwid {
  static const char *name() { return  "smwid"; }
  static int Offset(){ return offsetof( struct sfpa_t, smwid ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smthk {
  static const char *name() { return  "smthk"; }
  static int Offset(){ return offsetof( struct sfpa_t, smthk ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smlen {
  static const char *name() { return  "smlen"; }
  static int Offset(){ return offsetof( struct sfpa_t, smlen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sslen {
  static const char *name() { return  "sslen"; }
  static int Offset(){ return offsetof( struct sfpa_t, sslen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wplen {
  static const char *name() { return  "wplen"; }
  static int Offset(){ return offsetof( struct sfpa_t, wplen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sdlen {
  static const char *name() { return  "sdlen"; }
  static int Offset(){ return offsetof( struct sfpa_t, sdlen ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tilt {
  static const char *name() { return  "tilt"; }
  static int Offset(){ return offsetof( struct sfpa_t, tilt ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cprad {
  static const char *name() { return  "cprad"; }
  static int Offset(){ return offsetof( struct sfpa_t, cprad ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cpral {
  static const char *name() { return  "cpral"; }
  static int Offset(){ return offsetof( struct sfpa_t, cpral ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cfrad {
  static const char *name() { return  "cfrad"; }
  static int Offset(){ return offsetof( struct sfpa_t, cfrad ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gpthk {
  static const char *name() { return  "gpthk"; }
  static int Offset(){ return offsetof( struct sfpa_t, gpthk ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct laddermap {
  static const char *name() { return  "laddermap"; }
  static int Offset(){ return offsetof( struct sfpa_t, laddermap ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type[20];
};
struct ladderangle {
  static const char *name() { return  "ladderangle"; }
  static int Offset(){ return offsetof( struct sfpa_t, ladderangle ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[20];
};
struct laddertilt {
  static const char *name() { return  "laddertilt"; }
  static int Offset(){ return offsetof( struct sfpa_t, laddertilt ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[20];
};
struct ladderradius {
  static const char *name() { return  "ladderradius"; }
  static int Offset(){ return offsetof( struct sfpa_t, ladderradius ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[20];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct sfpa_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)sfpa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- SFMO -- 
   ///@defgroup SFMO_doc 
   ///@class SFMO 
   ///@brief is the mother of all Silicon Strip Detector volumes [TGeoVolume] 
   class SFMO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFMO() : AgBlock("SFMO","is the mother of all Silicon Strip Detector volumes [TGeoVolume]"){ 
      }; 
      ~SFMO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFLM -- 
   ///@defgroup SFLM_doc 
   ///@class SFLM 
   ///@brief is the mother of the ladder [TGeoVolume] 
   class SFLM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFLM() : AgBlock("SFLM","is the mother of the ladder [TGeoVolume]"){ 
      }; 
      ~SFLM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFDM -- 
   ///@defgroup SFDM_doc 
   ///@class SFDM 
   ///@brief is the mother of the detectors [TGeoVolume] 
   class SFDM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFDM() : AgBlock("SFDM","is the mother of the detectors [TGeoVolume]"){ 
      }; 
      ~SFDM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFSW -- 
   ///@defgroup SFSW_doc 
   ///@class SFSW 
   ///@brief is a single wafer container [TGeoVolume] 
   class SFSW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFSW() : AgBlock("SFSW","is a single wafer container [TGeoVolume]"){ 
      }; 
      ~SFSW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFRA -- 
   ///@defgroup SFRA_doc 
   ///@class SFRA 
   ///@brief is the hybrid stiffneer [TGeoVolume] 
   class SFRA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFRA() : AgBlock("SFRA","is the hybrid stiffneer [TGeoVolume]"){ 
      }; 
      ~SFRA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFRS -- 
   ///@defgroup SFRS_doc 
   ///@class SFRS 
   ///@brief two supports of the hybrid stiffneer (piece of it) [TGeoVolume] 
   class SFRS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFRS() : AgBlock("SFRS","two supports of the hybrid stiffneer (piece of it) [TGeoVolume]"){ 
      }; 
      ~SFRS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFFX -- 
   ///@defgroup SFFX_doc 
   ///@class SFFX 
   ///@brief is the flex [TGeoVolume] 
   class SFFX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFFX() : AgBlock("SFFX","is the flex [TGeoVolume]"){ 
      }; 
      ~SFFX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFAA -- 
   ///@defgroup SFAA_doc 
   ///@class SFAA 
   ///@brief is the A128C chip [TGeoVolume] 
   class SFAA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFAA() : AgBlock("SFAA","is the A128C chip [TGeoVolume]"){ 
      }; 
      ~SFAA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFPI -- 
   ///@defgroup SFPI_doc 
   ///@class SFPI 
   ///@brief are the pions [TGeoVolume] 
   class SFPI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFPI() : AgBlock("SFPI","are the pions [TGeoVolume]"){ 
      }; 
      ~SFPI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFPJ -- 
   ///@defgroup SFPJ_doc 
   ///@class SFPJ 
   ///@brief is the base of the pions [TGeoVolume] 
   class SFPJ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFPJ() : AgBlock("SFPJ","is the base of the pions [TGeoVolume]"){ 
      }; 
      ~SFPJ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFSD -- 
   ///@defgroup SFSD_doc 
   ///@class SFSD 
   ///@brief is the strip detector [TGeoVolume] 
   class SFSD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFSD() : AgBlock("SFSD","is the strip detector [TGeoVolume]"){ 
      }; 
      ~SFSD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFSM -- 
   ///@defgroup SFSM_doc 
   ///@class SFSM 
   ///@brief is the mother volume of the ladder (mechanic structure) [TGeoVolume] 
   class SFSM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFSM() : AgBlock("SFSM","is the mother volume of the ladder (mechanic structure) [TGeoVolume]"){ 
      }; 
      ~SFSM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFLT -- 
   ///@defgroup SFLT_doc 
   ///@class SFLT 
   ///@brief is (half) the top corner of the triangular ladder skeleton [TGeoVolume] 
   class SFLT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFLT() : AgBlock("SFLT","is (half) the top corner of the triangular ladder skeleton [TGeoVolume]"){ 
      }; 
      ~SFLT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFLU -- 
   ///@defgroup SFLU_doc 
   ///@class SFLU 
   ///@brief is (half) the side corner of the triangular ladder skeleton [TGeoVolume] 
   class SFLU : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFLU() : AgBlock("SFLU","is (half) the side corner of the triangular ladder skeleton [TGeoVolume]"){ 
      }; 
      ~SFLU(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFFK -- 
   ///@defgroup SFFK_doc 
   ///@class SFFK 
   ///@brief horizontal part of the ladder skeleton carbon base [TGeoVolume] 
   class SFFK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFFK() : AgBlock("SFFK","horizontal part of the ladder skeleton carbon base [TGeoVolume]"){ 
      }; 
      ~SFFK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFFL -- 
   ///@defgroup SFFL_doc 
   ///@class SFFL 
   ///@brief titled part of the ladder skeleton carbon base [TGeoVolume] 
   class SFFL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFFL() : AgBlock("SFFL","titled part of the ladder skeleton carbon base [TGeoVolume]"){ 
      }; 
      ~SFFL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFKK -- 
   ///@defgroup SFKK_doc 
   ///@class SFKK 
   ///@brief horizontal part of the kapton film under the ladder base [TGeoVolume] 
   class SFKK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFKK() : AgBlock("SFKK","horizontal part of the kapton film under the ladder base [TGeoVolume]"){ 
      }; 
      ~SFKK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFKL -- 
   ///@defgroup SFKL_doc 
   ///@class SFKL 
   ///@brief titled part of the kpaton film under the ladder base [TGeoVolume] 
   class SFKL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFKL() : AgBlock("SFKL","titled part of the kpaton film under the ladder base [TGeoVolume]"){ 
      }; 
      ~SFKL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFLA -- 
   ///@defgroup SFLA_doc 
   ///@class SFLA 
   ///@brief is the long part of the bus cable linking the modules to the connection board [TGeoVolume] 
   class SFLA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFLA() : AgBlock("SFLA","is the long part of the bus cable linking the modules to the connection board [TGeoVolume]"){ 
      }; 
      ~SFLA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFLB -- 
   ///@defgroup SFLB_doc 
   ///@class SFLB 
   ///@brief is the part of the long bus cable on the connection board [TGeoVolume] 
   class SFLB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFLB() : AgBlock("SFLB","is the part of the long bus cable on the connection board [TGeoVolume]"){ 
      }; 
      ~SFLB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFLC -- 
   ///@defgroup SFLC_doc 
   ///@class SFLC 
   ///@brief is the part of the long bus cable on the connection board up to the connector [TGeoVolume] 
   class SFLC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFLC() : AgBlock("SFLC","is the part of the long bus cable on the connection board up to the connector [TGeoVolume]"){ 
      }; 
      ~SFLC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFEB -- 
   ///@defgroup SFEB_doc 
   ///@class SFEB 
   ///@brief is the big bus elbow [TGeoVolume] 
   class SFEB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFEB() : AgBlock("SFEB","is the big bus elbow [TGeoVolume]"){ 
      }; 
      ~SFEB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFES -- 
   ///@defgroup SFES_doc 
   ///@class SFES 
   ///@brief is the small bus elbow [TGeoVolume] 
   class SFES : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFES() : AgBlock("SFES","is the small bus elbow [TGeoVolume]"){ 
      }; 
      ~SFES(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFAM -- 
   ///@defgroup SFAM_doc 
   ///@class SFAM 
   ///@brief is the mother volume of the adc board [TGeoVolume] 
   class SFAM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFAM() : AgBlock("SFAM","is the mother volume of the adc board [TGeoVolume]"){ 
      }; 
      ~SFAM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFAB -- 
   ///@defgroup SFAB_doc 
   ///@class SFAB 
   ///@brief is the big volume of the adc board [TGeoVolume] 
   class SFAB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFAB() : AgBlock("SFAB","is the big volume of the adc board [TGeoVolume]"){ 
      }; 
      ~SFAB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFAS -- 
   ///@defgroup SFAS_doc 
   ///@class SFAS 
   ///@brief is the small volume of the adc board [TGeoVolume] 
   class SFAS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFAS() : AgBlock("SFAS","is the small volume of the adc board [TGeoVolume]"){ 
      }; 
      ~SFAS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SAPP -- 
   ///@defgroup SAPP_doc 
   ///@class SAPP 
   ///@brief is the mother volume of the adc board appendice [TGeoVolume] 
   class SAPP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SAPP() : AgBlock("SAPP","is the mother volume of the adc board appendice [TGeoVolume]"){ 
      }; 
      ~SAPP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SAPC -- 
   ///@defgroup SAPC_doc 
   ///@class SAPC 
   ///@brief is the core (Epoxy) of the adc board appendice [TGeoVolume] 
   class SAPC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SAPC() : AgBlock("SAPC","is the core (Epoxy) of the adc board appendice [TGeoVolume]"){ 
      }; 
      ~SAPC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SAPS -- 
   ///@defgroup SAPS_doc 
   ///@class SAPS 
   ///@brief is the side shell (Carbon) of the adc board appendice [TGeoVolume] 
   class SAPS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SAPS() : AgBlock("SAPS","is the side shell (Carbon) of the adc board appendice [TGeoVolume]"){ 
      }; 
      ~SAPS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SAPT -- 
   ///@defgroup SAPT_doc 
   ///@class SAPT 
   ///@brief is the top-bottom shell (Carbon) of the adc board appendice [TGeoVolume] 
   class SAPT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SAPT() : AgBlock("SAPT","is the top-bottom shell (Carbon) of the adc board appendice [TGeoVolume]"){ 
      }; 
      ~SAPT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFCO -- 
   ///@defgroup SFCO_doc 
   ///@class SFCO 
   ///@brief is the connection board (rectangular with Hirose connectors) [TGeoVolume] 
   class SFCO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFCO() : AgBlock("SFCO","is the connection board (rectangular with Hirose connectors) [TGeoVolume]"){ 
      }; 
      ~SFCO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFCM -- 
   ///@defgroup SFCM_doc 
   ///@class SFCM 
   ///@brief is the mother volume of the second connection board [TGeoVolume] 
   class SFCM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFCM() : AgBlock("SFCM","is the mother volume of the second connection board [TGeoVolume]"){ 
      }; 
      ~SFCM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFCB -- 
   ///@defgroup SFCB_doc 
   ///@class SFCB 
   ///@brief is the big part of the second connection board [TGeoVolume] 
   class SFCB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFCB() : AgBlock("SFCB","is the big part of the second connection board [TGeoVolume]"){ 
      }; 
      ~SFCB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFCS -- 
   ///@defgroup SFCS_doc 
   ///@class SFCS 
   ///@brief is the big part of the second connection board [TGeoVolume] 
   class SFCS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFCS() : AgBlock("SFCS","is the big part of the second connection board [TGeoVolume]"){ 
      }; 
      ~SFCS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFKF -- 
   ///@defgroup SFKF_doc 
   ///@class SFKF 
   ///@brief is the first part of the kapton flex circuit [TGeoVolume] 
   class SFKF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFKF() : AgBlock("SFKF","is the first part of the kapton flex circuit [TGeoVolume]"){ 
      }; 
      ~SFKF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFKS -- 
   ///@defgroup SFKS_doc 
   ///@class SFKS 
   ///@brief is the second part of the kapton flex circuit [TGeoVolume] 
   class SFKS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFKS() : AgBlock("SFKS","is the second part of the kapton flex circuit [TGeoVolume]"){ 
      }; 
      ~SFKS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFPR -- 
   ///@defgroup SFPR_doc 
   ///@class SFPR 
   ///@brief is the ladder end inside mechanical part (prism with g10 with half density) [TGeoVolume] 
   class SFPR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFPR() : AgBlock("SFPR","is the ladder end inside mechanical part (prism with g10 with half density) [TGeoVolume]"){ 
      }; 
      ~SFPR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SFPB -- 
   ///@defgroup SFPB_doc 
   ///@class SFPB 
   ///@brief is the ladder end outside mechanical part (rectangle with g10) [TGeoVolume] 
   class SFPB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SFPB() : AgBlock("SFPB","is the ladder end outside mechanical part (rectangle with g10) [TGeoVolume]"){ 
      }; 
      ~SFPB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SSBS -- 
   ///@defgroup SSBS_doc 
   ///@class SSBS 
   ///@brief is the small part of the aluminium plate linking the ladder to the sector [TGeoVolume] 
   class SSBS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SSBS() : AgBlock("SSBS","is the small part of the aluminium plate linking the ladder to the sector [TGeoVolume]"){ 
      }; 
      ~SSBS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SSBB -- 
   ///@defgroup SSBB_doc 
   ///@class SSBB 
   ///@brief is the Big part of the aluminium plate linking the ladder to the sector [TGeoVolume] 
   class SSBB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SSBB() : AgBlock("SSBB","is the Big part of the aluminium plate linking the ladder to the sector [TGeoVolume]"){ 
      }; 
      ~SSBB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SSST -- 
   ///@defgroup SSST_doc 
   ///@class SSST 
   ///@brief is the top of the small sector [TGeoVolume] 
   class SSST : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SSST() : AgBlock("SSST","is the top of the small sector [TGeoVolume]"){ 
      }; 
      ~SSST(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SSSS -- 
   ///@defgroup SSSS_doc 
   ///@class SSSS 
   ///@brief is the side of the small sector [TGeoVolume] 
   class SSSS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SSSS() : AgBlock("SSSS","is the side of the small sector [TGeoVolume]"){ 
      }; 
      ~SSSS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SSRT -- 
   ///@defgroup SSRT_doc 
   ///@class SSRT 
   ///@brief is the top of the side rib [TGeoVolume] 
   class SSRT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SSRT() : AgBlock("SSRT","is the top of the side rib [TGeoVolume]"){ 
      }; 
      ~SSRT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SSRS -- 
   ///@defgroup SSRS_doc 
   ///@class SSRS 
   ///@brief is the side of the small rib [TGeoVolume] 
   class SSRS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SSRS() : AgBlock("SSRS","is the side of the small rib [TGeoVolume]"){ 
      }; 
      ~SSRS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SSLB -- 
   ///@defgroup SSLB_doc 
   ///@class SSLB 
   ///@brief is the linking (sector to the cone) box [TGeoVolume] 
   class SSLB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SSLB() : AgBlock("SSLB","is the linking (sector to the cone) box [TGeoVolume]"){ 
      }; 
      ~SSLB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SSLT -- 
   ///@defgroup SSLT_doc 
   ///@class SSLT 
   ///@brief is the linking (sector to the cone) tube [TGeoVolume] 
   class SSLT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SSLT() : AgBlock("SSLT","is the linking (sector to the cone) tube [TGeoVolume]"){ 
      }; 
      ~SSLT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SCMP -- 
   ///@defgroup SCMP_doc 
   ///@class SCMP 
   ///@brief is the mounting plate inserted in the cones. [TGeoVolume] 
   class SCMP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SCMP() : AgBlock("SCMP","is the mounting plate inserted in the cones. [TGeoVolume]"){ 
      }; 
      ~SCMP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SCVM -- 
   ///@defgroup SCVM_doc 
   ///@class SCVM 
   ///@brief is the mother volume of the V-shape piece [TGeoVolume] 
   class SCVM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SCVM() : AgBlock("SCVM","is the mother volume of the V-shape piece [TGeoVolume]"){ 
      }; 
      ~SCVM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SCVB -- 
   ///@defgroup SCVB_doc 
   ///@class SCVB 
   ///@brief is the base plate of the V-shape piece [TGeoVolume] 
   class SCVB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SCVB() : AgBlock("SCVB","is the base plate of the V-shape piece [TGeoVolume]"){ 
      }; 
      ~SCVB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SCVS -- 
   ///@defgroup SCVS_doc 
   ///@class SCVS 
   ///@brief is the side plate of the V-shape piece [TGeoVolume] 
   class SCVS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SCVS() : AgBlock("SCVS","is the side plate of the V-shape piece [TGeoVolume]"){ 
      }; 
      ~SCVS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class SisdGeo1 
   /// \brief   is the Silicon Strip Detector  
   class SisdGeo1 : public AgModule 
   { 
      public: 
      SisdGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~SisdGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace SisdGeo1 
#endif // __SisdGeo1__ 
