#ifndef __FtpcGeo1__ 
#define __FtpcGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace FTPCGEO1 // $NMSPC 
{ 
   struct ftpg_t {
float version;
float rinnerms;
float routerms;
float rgasout;
float rrom;
float relcard;
float rcooplm;
float rcoople;
float zstart;
float totlen;
float laylen;
float hitlay;
float drinall1;
float drinall2;
float drinisol;
float dzkapton;
float drifr;
float dzifr;
float dzer;
float dzrom;
float dzsura;
float dzsurb;
float dzsmpr;
float dzbipr;
float msrdz;
float serhole;
float risring;
float isringdz;
float sbsrdx;
float sbsrdy;
float sbsrdz;
float gasvoldz;
int _index;
};
 
   struct _ftpg_docum_ {
string version;
string rinnerms;
string routerms;
string rgasout;
string rrom;
string relcard;
string rcooplm;
string rcoople;
string zstart;
string totlen;
string laylen;
string hitlay;
string drinall1;
string drinall2;
string drinisol;
string dzkapton;
string drifr;
string dzifr;
string dzer;
string dzrom;
string dzsura;
string dzsurb;
string dzsmpr;
string dzbipr;
string msrdz;
string serhole;
string risring;
string isringdz;
string sbsrdx;
string sbsrdy;
string sbsrdz;
string gasvoldz;
string _index;
};
 
    struct _ftpg_types_ {
  typedef float version;
  typedef float rinnerms;
  typedef float routerms;
  typedef float rgasout;
  typedef float rrom;
  typedef float relcard;
  typedef float rcooplm;
  typedef float rcoople;
  typedef float zstart;
  typedef float totlen;
  typedef float laylen;
  typedef float hitlay;
  typedef float drinall1;
  typedef float drinall2;
  typedef float drinisol;
  typedef float dzkapton;
  typedef float drifr;
  typedef float dzifr;
  typedef float dzer;
  typedef float dzrom;
  typedef float dzsura;
  typedef float dzsurb;
  typedef float dzsmpr;
  typedef float dzbipr;
  typedef float msrdz;
  typedef float serhole;
  typedef float risring;
  typedef float isringdz;
  typedef float sbsrdx;
  typedef float sbsrdy;
  typedef float sbsrdz;
  typedef float gasvoldz;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct ftpg_info {
typedef ftpg_t Type;
static const char *name(){ return "ftpg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct ftpg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rinnerms {
  static const char *name() { return  "rinnerms"; }
  static int Offset(){ return offsetof( struct ftpg_t, rinnerms ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct routerms {
  static const char *name() { return  "routerms"; }
  static int Offset(){ return offsetof( struct ftpg_t, routerms ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rgasout {
  static const char *name() { return  "rgasout"; }
  static int Offset(){ return offsetof( struct ftpg_t, rgasout ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rrom {
  static const char *name() { return  "rrom"; }
  static int Offset(){ return offsetof( struct ftpg_t, rrom ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct relcard {
  static const char *name() { return  "relcard"; }
  static int Offset(){ return offsetof( struct ftpg_t, relcard ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rcooplm {
  static const char *name() { return  "rcooplm"; }
  static int Offset(){ return offsetof( struct ftpg_t, rcooplm ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rcoople {
  static const char *name() { return  "rcoople"; }
  static int Offset(){ return offsetof( struct ftpg_t, rcoople ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zstart {
  static const char *name() { return  "zstart"; }
  static int Offset(){ return offsetof( struct ftpg_t, zstart ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct totlen {
  static const char *name() { return  "totlen"; }
  static int Offset(){ return offsetof( struct ftpg_t, totlen ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct laylen {
  static const char *name() { return  "laylen"; }
  static int Offset(){ return offsetof( struct ftpg_t, laylen ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct hitlay {
  static const char *name() { return  "hitlay"; }
  static int Offset(){ return offsetof( struct ftpg_t, hitlay ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct drinall1 {
  static const char *name() { return  "drinall1"; }
  static int Offset(){ return offsetof( struct ftpg_t, drinall1 ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct drinall2 {
  static const char *name() { return  "drinall2"; }
  static int Offset(){ return offsetof( struct ftpg_t, drinall2 ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct drinisol {
  static const char *name() { return  "drinisol"; }
  static int Offset(){ return offsetof( struct ftpg_t, drinisol ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzkapton {
  static const char *name() { return  "dzkapton"; }
  static int Offset(){ return offsetof( struct ftpg_t, dzkapton ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct drifr {
  static const char *name() { return  "drifr"; }
  static int Offset(){ return offsetof( struct ftpg_t, drifr ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzifr {
  static const char *name() { return  "dzifr"; }
  static int Offset(){ return offsetof( struct ftpg_t, dzifr ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzer {
  static const char *name() { return  "dzer"; }
  static int Offset(){ return offsetof( struct ftpg_t, dzer ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzrom {
  static const char *name() { return  "dzrom"; }
  static int Offset(){ return offsetof( struct ftpg_t, dzrom ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzsura {
  static const char *name() { return  "dzsura"; }
  static int Offset(){ return offsetof( struct ftpg_t, dzsura ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzsurb {
  static const char *name() { return  "dzsurb"; }
  static int Offset(){ return offsetof( struct ftpg_t, dzsurb ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzsmpr {
  static const char *name() { return  "dzsmpr"; }
  static int Offset(){ return offsetof( struct ftpg_t, dzsmpr ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzbipr {
  static const char *name() { return  "dzbipr"; }
  static int Offset(){ return offsetof( struct ftpg_t, dzbipr ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct msrdz {
  static const char *name() { return  "msrdz"; }
  static int Offset(){ return offsetof( struct ftpg_t, msrdz ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct serhole {
  static const char *name() { return  "serhole"; }
  static int Offset(){ return offsetof( struct ftpg_t, serhole ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct risring {
  static const char *name() { return  "risring"; }
  static int Offset(){ return offsetof( struct ftpg_t, risring ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct isringdz {
  static const char *name() { return  "isringdz"; }
  static int Offset(){ return offsetof( struct ftpg_t, isringdz ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sbsrdx {
  static const char *name() { return  "sbsrdx"; }
  static int Offset(){ return offsetof( struct ftpg_t, sbsrdx ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sbsrdy {
  static const char *name() { return  "sbsrdy"; }
  static int Offset(){ return offsetof( struct ftpg_t, sbsrdy ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sbsrdz {
  static const char *name() { return  "sbsrdz"; }
  static int Offset(){ return offsetof( struct ftpg_t, sbsrdz ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gasvoldz {
  static const char *name() { return  "gasvoldz"; }
  static int Offset(){ return offsetof( struct ftpg_t, gasvoldz ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct ftpg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)ftpg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct ffcc_t {
float version;
float stileng;
float stidia;
float stirpos;
float rithick;
float ridr;
float rigap;
float barleng;
float barwidt;
float barthik;
int _index;
};
 
   struct _ffcc_docum_ {
string version;
string stileng;
string stidia;
string stirpos;
string rithick;
string ridr;
string rigap;
string barleng;
string barwidt;
string barthik;
string _index;
};
 
    struct _ffcc_types_ {
  typedef float version;
  typedef float stileng;
  typedef float stidia;
  typedef float stirpos;
  typedef float rithick;
  typedef float ridr;
  typedef float rigap;
  typedef float barleng;
  typedef float barwidt;
  typedef float barthik;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct ffcc_info {
typedef ffcc_t Type;
static const char *name(){ return "ffcc_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct ffcc_t, version ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stileng {
  static const char *name() { return  "stileng"; }
  static int Offset(){ return offsetof( struct ffcc_t, stileng ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stidia {
  static const char *name() { return  "stidia"; }
  static int Offset(){ return offsetof( struct ffcc_t, stidia ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stirpos {
  static const char *name() { return  "stirpos"; }
  static int Offset(){ return offsetof( struct ffcc_t, stirpos ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rithick {
  static const char *name() { return  "rithick"; }
  static int Offset(){ return offsetof( struct ffcc_t, rithick ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ridr {
  static const char *name() { return  "ridr"; }
  static int Offset(){ return offsetof( struct ffcc_t, ridr ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rigap {
  static const char *name() { return  "rigap"; }
  static int Offset(){ return offsetof( struct ffcc_t, rigap ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct barleng {
  static const char *name() { return  "barleng"; }
  static int Offset(){ return offsetof( struct ffcc_t, barleng ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct barwidt {
  static const char *name() { return  "barwidt"; }
  static int Offset(){ return offsetof( struct ffcc_t, barwidt ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct barthik {
  static const char *name() { return  "barthik"; }
  static int Offset(){ return offsetof( struct ffcc_t, barthik ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct ffcc_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)ffcc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct frbd_t {
float version;
float phi1;
float phi2;
float phi3;
float phi4;
float phi5;
float phi6;
float phi7;
float phi8;
float phi9;
float phi10;
float phi11;
float phi12;
float phi13;
float xrom;
float yrom;
float zrom;
float rahol;
float xehol;
float yehol;
float xlhol;
float ylhol;
float boffset;
float zoffb;
float modleng;
float electrdx;
float electrdy;
float electrdz;
float coolpldx;
float coolpldy;
float coolpldz;
float eclpldx;
float eclpldy;
float eclpldz;
float cakehir;
float cakehor;
float cakehwz;
float boxhx;
float boxhy;
float boxhz;
float eboxhx;
float eboxhy;
float eboxhz;
float lboxhx;
float lboxhy;
float lboxhz;
int _index;
};
 
   struct _frbd_docum_ {
string version;
string phi1;
string phi2;
string phi3;
string phi4;
string phi5;
string phi6;
string phi7;
string phi8;
string phi9;
string phi10;
string phi11;
string phi12;
string phi13;
string xrom;
string yrom;
string zrom;
string rahol;
string xehol;
string yehol;
string xlhol;
string ylhol;
string boffset;
string zoffb;
string modleng;
string electrdx;
string electrdy;
string electrdz;
string coolpldx;
string coolpldy;
string coolpldz;
string eclpldx;
string eclpldy;
string eclpldz;
string cakehir;
string cakehor;
string cakehwz;
string boxhx;
string boxhy;
string boxhz;
string eboxhx;
string eboxhy;
string eboxhz;
string lboxhx;
string lboxhy;
string lboxhz;
string _index;
};
 
    struct _frbd_types_ {
  typedef float version;
  typedef float phi1;
  typedef float phi2;
  typedef float phi3;
  typedef float phi4;
  typedef float phi5;
  typedef float phi6;
  typedef float phi7;
  typedef float phi8;
  typedef float phi9;
  typedef float phi10;
  typedef float phi11;
  typedef float phi12;
  typedef float phi13;
  typedef float xrom;
  typedef float yrom;
  typedef float zrom;
  typedef float rahol;
  typedef float xehol;
  typedef float yehol;
  typedef float xlhol;
  typedef float ylhol;
  typedef float boffset;
  typedef float zoffb;
  typedef float modleng;
  typedef float electrdx;
  typedef float electrdy;
  typedef float electrdz;
  typedef float coolpldx;
  typedef float coolpldy;
  typedef float coolpldz;
  typedef float eclpldx;
  typedef float eclpldy;
  typedef float eclpldz;
  typedef float cakehir;
  typedef float cakehor;
  typedef float cakehwz;
  typedef float boxhx;
  typedef float boxhy;
  typedef float boxhz;
  typedef float eboxhx;
  typedef float eboxhy;
  typedef float eboxhz;
  typedef float lboxhx;
  typedef float lboxhy;
  typedef float lboxhz;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct frbd_info {
typedef frbd_t Type;
static const char *name(){ return "frbd_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct frbd_t, version ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi1 {
  static const char *name() { return  "phi1"; }
  static int Offset(){ return offsetof( struct frbd_t, phi1 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi2 {
  static const char *name() { return  "phi2"; }
  static int Offset(){ return offsetof( struct frbd_t, phi2 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi3 {
  static const char *name() { return  "phi3"; }
  static int Offset(){ return offsetof( struct frbd_t, phi3 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi4 {
  static const char *name() { return  "phi4"; }
  static int Offset(){ return offsetof( struct frbd_t, phi4 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi5 {
  static const char *name() { return  "phi5"; }
  static int Offset(){ return offsetof( struct frbd_t, phi5 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi6 {
  static const char *name() { return  "phi6"; }
  static int Offset(){ return offsetof( struct frbd_t, phi6 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi7 {
  static const char *name() { return  "phi7"; }
  static int Offset(){ return offsetof( struct frbd_t, phi7 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi8 {
  static const char *name() { return  "phi8"; }
  static int Offset(){ return offsetof( struct frbd_t, phi8 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi9 {
  static const char *name() { return  "phi9"; }
  static int Offset(){ return offsetof( struct frbd_t, phi9 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi10 {
  static const char *name() { return  "phi10"; }
  static int Offset(){ return offsetof( struct frbd_t, phi10 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi11 {
  static const char *name() { return  "phi11"; }
  static int Offset(){ return offsetof( struct frbd_t, phi11 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi12 {
  static const char *name() { return  "phi12"; }
  static int Offset(){ return offsetof( struct frbd_t, phi12 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phi13 {
  static const char *name() { return  "phi13"; }
  static int Offset(){ return offsetof( struct frbd_t, phi13 ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xrom {
  static const char *name() { return  "xrom"; }
  static int Offset(){ return offsetof( struct frbd_t, xrom ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yrom {
  static const char *name() { return  "yrom"; }
  static int Offset(){ return offsetof( struct frbd_t, yrom ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zrom {
  static const char *name() { return  "zrom"; }
  static int Offset(){ return offsetof( struct frbd_t, zrom ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rahol {
  static const char *name() { return  "rahol"; }
  static int Offset(){ return offsetof( struct frbd_t, rahol ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xehol {
  static const char *name() { return  "xehol"; }
  static int Offset(){ return offsetof( struct frbd_t, xehol ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yehol {
  static const char *name() { return  "yehol"; }
  static int Offset(){ return offsetof( struct frbd_t, yehol ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xlhol {
  static const char *name() { return  "xlhol"; }
  static int Offset(){ return offsetof( struct frbd_t, xlhol ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ylhol {
  static const char *name() { return  "ylhol"; }
  static int Offset(){ return offsetof( struct frbd_t, ylhol ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct boffset {
  static const char *name() { return  "boffset"; }
  static int Offset(){ return offsetof( struct frbd_t, boffset ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zoffb {
  static const char *name() { return  "zoffb"; }
  static int Offset(){ return offsetof( struct frbd_t, zoffb ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct modleng {
  static const char *name() { return  "modleng"; }
  static int Offset(){ return offsetof( struct frbd_t, modleng ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct electrdx {
  static const char *name() { return  "electrdx"; }
  static int Offset(){ return offsetof( struct frbd_t, electrdx ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct electrdy {
  static const char *name() { return  "electrdy"; }
  static int Offset(){ return offsetof( struct frbd_t, electrdy ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct electrdz {
  static const char *name() { return  "electrdz"; }
  static int Offset(){ return offsetof( struct frbd_t, electrdz ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct coolpldx {
  static const char *name() { return  "coolpldx"; }
  static int Offset(){ return offsetof( struct frbd_t, coolpldx ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct coolpldy {
  static const char *name() { return  "coolpldy"; }
  static int Offset(){ return offsetof( struct frbd_t, coolpldy ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct coolpldz {
  static const char *name() { return  "coolpldz"; }
  static int Offset(){ return offsetof( struct frbd_t, coolpldz ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eclpldx {
  static const char *name() { return  "eclpldx"; }
  static int Offset(){ return offsetof( struct frbd_t, eclpldx ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eclpldy {
  static const char *name() { return  "eclpldy"; }
  static int Offset(){ return offsetof( struct frbd_t, eclpldy ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eclpldz {
  static const char *name() { return  "eclpldz"; }
  static int Offset(){ return offsetof( struct frbd_t, eclpldz ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cakehir {
  static const char *name() { return  "cakehir"; }
  static int Offset(){ return offsetof( struct frbd_t, cakehir ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cakehor {
  static const char *name() { return  "cakehor"; }
  static int Offset(){ return offsetof( struct frbd_t, cakehor ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cakehwz {
  static const char *name() { return  "cakehwz"; }
  static int Offset(){ return offsetof( struct frbd_t, cakehwz ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct boxhx {
  static const char *name() { return  "boxhx"; }
  static int Offset(){ return offsetof( struct frbd_t, boxhx ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct boxhy {
  static const char *name() { return  "boxhy"; }
  static int Offset(){ return offsetof( struct frbd_t, boxhy ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct boxhz {
  static const char *name() { return  "boxhz"; }
  static int Offset(){ return offsetof( struct frbd_t, boxhz ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eboxhx {
  static const char *name() { return  "eboxhx"; }
  static int Offset(){ return offsetof( struct frbd_t, eboxhx ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eboxhy {
  static const char *name() { return  "eboxhy"; }
  static int Offset(){ return offsetof( struct frbd_t, eboxhy ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eboxhz {
  static const char *name() { return  "eboxhz"; }
  static int Offset(){ return offsetof( struct frbd_t, eboxhz ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct lboxhx {
  static const char *name() { return  "lboxhx"; }
  static int Offset(){ return offsetof( struct frbd_t, lboxhx ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct lboxhy {
  static const char *name() { return  "lboxhy"; }
  static int Offset(){ return offsetof( struct frbd_t, lboxhy ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct lboxhz {
  static const char *name() { return  "lboxhz"; }
  static int Offset(){ return offsetof( struct frbd_t, lboxhz ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct frbd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)frbd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fssd_t {
float version;
float eringrmn;
float eringrmx;
float eringdz;
float oeringdz;
float erposz;
float meringrm;
float meringdz;
float erpolyrm;
float trapr;
float polyr;
float polydz;
float polyir;
float polyor;
float trapx1;
float trapx2;
float trapdy;
float trapdz;
float pgonpdz;
float sbsdy;
int _index;
};
 
   struct _fssd_docum_ {
string version;
string eringrmn;
string eringrmx;
string eringdz;
string oeringdz;
string erposz;
string meringrm;
string meringdz;
string erpolyrm;
string trapr;
string polyr;
string polydz;
string polyir;
string polyor;
string trapx1;
string trapx2;
string trapdy;
string trapdz;
string pgonpdz;
string sbsdy;
string _index;
};
 
    struct _fssd_types_ {
  typedef float version;
  typedef float eringrmn;
  typedef float eringrmx;
  typedef float eringdz;
  typedef float oeringdz;
  typedef float erposz;
  typedef float meringrm;
  typedef float meringdz;
  typedef float erpolyrm;
  typedef float trapr;
  typedef float polyr;
  typedef float polydz;
  typedef float polyir;
  typedef float polyor;
  typedef float trapx1;
  typedef float trapx2;
  typedef float trapdy;
  typedef float trapdz;
  typedef float pgonpdz;
  typedef float sbsdy;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fssd_info {
typedef fssd_t Type;
static const char *name(){ return "fssd_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct fssd_t, version ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eringrmn {
  static const char *name() { return  "eringrmn"; }
  static int Offset(){ return offsetof( struct fssd_t, eringrmn ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eringrmx {
  static const char *name() { return  "eringrmx"; }
  static int Offset(){ return offsetof( struct fssd_t, eringrmx ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eringdz {
  static const char *name() { return  "eringdz"; }
  static int Offset(){ return offsetof( struct fssd_t, eringdz ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct oeringdz {
  static const char *name() { return  "oeringdz"; }
  static int Offset(){ return offsetof( struct fssd_t, oeringdz ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct erposz {
  static const char *name() { return  "erposz"; }
  static int Offset(){ return offsetof( struct fssd_t, erposz ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct meringrm {
  static const char *name() { return  "meringrm"; }
  static int Offset(){ return offsetof( struct fssd_t, meringrm ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct meringdz {
  static const char *name() { return  "meringdz"; }
  static int Offset(){ return offsetof( struct fssd_t, meringdz ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct erpolyrm {
  static const char *name() { return  "erpolyrm"; }
  static int Offset(){ return offsetof( struct fssd_t, erpolyrm ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct trapr {
  static const char *name() { return  "trapr"; }
  static int Offset(){ return offsetof( struct fssd_t, trapr ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct polyr {
  static const char *name() { return  "polyr"; }
  static int Offset(){ return offsetof( struct fssd_t, polyr ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct polydz {
  static const char *name() { return  "polydz"; }
  static int Offset(){ return offsetof( struct fssd_t, polydz ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct polyir {
  static const char *name() { return  "polyir"; }
  static int Offset(){ return offsetof( struct fssd_t, polyir ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct polyor {
  static const char *name() { return  "polyor"; }
  static int Offset(){ return offsetof( struct fssd_t, polyor ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct trapx1 {
  static const char *name() { return  "trapx1"; }
  static int Offset(){ return offsetof( struct fssd_t, trapx1 ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct trapx2 {
  static const char *name() { return  "trapx2"; }
  static int Offset(){ return offsetof( struct fssd_t, trapx2 ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct trapdy {
  static const char *name() { return  "trapdy"; }
  static int Offset(){ return offsetof( struct fssd_t, trapdy ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct trapdz {
  static const char *name() { return  "trapdz"; }
  static int Offset(){ return offsetof( struct fssd_t, trapdz ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pgonpdz {
  static const char *name() { return  "pgonpdz"; }
  static int Offset(){ return offsetof( struct fssd_t, pgonpdz ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sbsdy {
  static const char *name() { return  "sbsdy"; }
  static int Offset(){ return offsetof( struct fssd_t, sbsdy ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fssd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fssd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- FTPC -- 
   ///@defgroup FTPC_doc 
   ///@class FTPC 
   ///@brief is the Forward TPC mother (needed for standalong test only) [TGeoVolume] 
   class FTPC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FTPC() : AgBlock("FTPC","is the Forward TPC mother (needed for standalong test only) [TGeoVolume]"){ 
      }; 
      ~FTPC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FIAL -- 
   ///@defgroup FIAL_doc 
   ///@class FIAL 
   ///@brief is the inner AL-tube of the FTPC [TGeoVolume] 
   class FIAL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FIAL() : AgBlock("FIAL","is the inner AL-tube of the FTPC [TGeoVolume]"){ 
      }; 
      ~FIAL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FMPT -- 
   ///@defgroup FMPT_doc 
   ///@class FMPT 
   ///@brief is the insulating plastic tube of the drift-electrode [TGeoVolume] 
   class FMPT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FMPT() : AgBlock("FMPT","is the insulating plastic tube of the drift-electrode [TGeoVolume]"){ 
      }; 
      ~FMPT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FOAL -- 
   ///@defgroup FOAL_doc 
   ///@class FOAL 
   ///@brief is the Al drift-electrode [TGeoVolume] 
   class FOAL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FOAL() : AgBlock("FOAL","is the Al drift-electrode [TGeoVolume]"){ 
      }; 
      ~FOAL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGAS -- 
   ///@defgroup FGAS_doc 
   ///@class FGAS 
   ///@brief is the FTPC gas volume [TGeoVolume] 
   class FGAS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGAS() : AgBlock("FGAS","is the FTPC gas volume [TGeoVolume]"){ 
      }; 
      ~FGAS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSEN -- 
   ///@defgroup FSEN_doc 
   ///@class FSEN 
   ///@brief is the sensitive gas volume [TGeoVolume] 
   class FSEN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSEN() : AgBlock("FSEN","is the sensitive gas volume [TGeoVolume]"){ 
      }; 
      ~FSEN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSEC -- 
   ///@defgroup FSEC_doc 
   ///@class FSEC 
   ///@brief is a sensitive gas sector [TGeoVolume] 
   class FSEC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSEC() : AgBlock("FSEC","is a sensitive gas sector [TGeoVolume]"){ 
      }; 
      ~FSEC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FIFR -- 
   ///@defgroup FIFR_doc 
   ///@class FIFR 
   ///@brief is the Al inner flange ring [TGeoVolume] 
   class FIFR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FIFR() : AgBlock("FIFR","is the Al inner flange ring [TGeoVolume]"){ 
      }; 
      ~FIFR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FKWI -- 
   ///@defgroup FKWI_doc 
   ///@class FKWI 
   ///@brief is the double Kapton window [TGeoVolume] 
   class FKWI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FKWI() : AgBlock("FKWI","is the double Kapton window [TGeoVolume]"){ 
      }; 
      ~FKWI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FFSL -- 
   ///@defgroup FFSL_doc 
   ///@class FFSL 
   ///@brief is ceramic holder for fieldcage rings [TGeoVolume] 
   class FFSL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FFSL() : AgBlock("FFSL","is ceramic holder for fieldcage rings [TGeoVolume]"){ 
      }; 
      ~FFSL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FFCE -- 
   ///@defgroup FFCE_doc 
   ///@class FFCE 
   ///@brief is the Fildcage Enhanced Support Structure [TGeoVolume] 
   class FFCE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FFCE() : AgBlock("FFCE","is the Fildcage Enhanced Support Structure [TGeoVolume]"){ 
      }; 
      ~FFCE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FROS -- 
   ///@defgroup FROS_doc 
   ///@class FROS 
   ///@brief is one Ring of Readout Modules in the support Structure [TGeoVolume] 
   class FROS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FROS() : AgBlock("FROS","is one Ring of Readout Modules in the support Structure [TGeoVolume]"){ 
      }; 
      ~FROS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FROM -- 
   ///@defgroup FROM_doc 
   ///@class FROM 
   ///@brief is one Module of the Readout Chamber [TGeoVolume] 
   class FROM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FROM() : AgBlock("FROM","is one Module of the Readout Chamber [TGeoVolume]"){ 
      }; 
      ~FROM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FROB -- 
   ///@defgroup FROB_doc 
   ///@class FROB 
   ///@brief are the Box Holes in the Readout Chamber [TGeoVolume] 
   class FROB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FROB() : AgBlock("FROB","are the Box Holes in the Readout Chamber [TGeoVolume]"){ 
      }; 
      ~FROB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FROE -- 
   ///@defgroup FROE_doc 
   ///@class FROE 
   ///@brief are the End Box Holes in the Readout Chamber [TGeoVolume] 
   class FROE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FROE() : AgBlock("FROE","are the End Box Holes in the Readout Chamber [TGeoVolume]"){ 
      }; 
      ~FROE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FROL -- 
   ///@defgroup FROL_doc 
   ///@class FROL 
   ///@brief are the Length side Box Holes in the Readout Chamber [TGeoVolume] 
   class FROL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FROL() : AgBlock("FROL","are the Length side Box Holes in the Readout Chamber [TGeoVolume]"){ 
      }; 
      ~FROL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FROP -- 
   ///@defgroup FROP_doc 
   ///@class FROP 
   ///@brief are the Polygon part of the support bar [TGeoVolume] 
   class FROP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FROP() : AgBlock("FROP","are the Polygon part of the support bar [TGeoVolume]"){ 
      }; 
      ~FROP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FROT -- 
   ///@defgroup FROT_doc 
   ///@class FROT 
   ///@brief are the Trapezoid part of the support bar [TGeoVolume] 
   class FROT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FROT() : AgBlock("FROT","are the Trapezoid part of the support bar [TGeoVolume]"){ 
      }; 
      ~FROT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FREL -- 
   ///@defgroup FREL_doc 
   ///@class FREL 
   ///@brief is the Electronics Layer of the Readout Chamber [TGeoVolume] 
   class FREL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FREL() : AgBlock("FREL","is the Electronics Layer of the Readout Chamber [TGeoVolume]"){ 
      }; 
      ~FREL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FRCC -- 
   ///@defgroup FRCC_doc 
   ///@class FRCC 
   ///@brief is the Copper Cooling Layer of the Readout Chamber (Middle) [TGeoVolume] 
   class FRCC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FRCC() : AgBlock("FRCC","is the Copper Cooling Layer of the Readout Chamber (Middle) [TGeoVolume]"){ 
      }; 
      ~FRCC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FRCE -- 
   ///@defgroup FRCE_doc 
   ///@class FRCE 
   ///@brief is the Copper Cooling Layer of the Readout Chamber (Ends) [TGeoVolume] 
   class FRCE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FRCE() : AgBlock("FRCE","is the Copper Cooling Layer of the Readout Chamber (Ends) [TGeoVolume]"){ 
      }; 
      ~FRCE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSER -- 
   ///@defgroup FSER_doc 
   ///@class FSER 
   ///@brief is the Support End Ring [TGeoVolume] 
   class FSER : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSER() : AgBlock("FSER","is the Support End Ring [TGeoVolume]"){ 
      }; 
      ~FSER(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSRA -- 
   ///@defgroup FSRA_doc 
   ///@class FSRA 
   ///@brief is the outer Support End Ring [TGeoVolume] 
   class FSRA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSRA() : AgBlock("FSRA","is the outer Support End Ring [TGeoVolume]"){ 
      }; 
      ~FSRA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSRB -- 
   ///@defgroup FSRB_doc 
   ///@class FSRB 
   ///@brief is the medium Support End Ring [TGeoVolume] 
   class FSRB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSRB() : AgBlock("FSRB","is the medium Support End Ring [TGeoVolume]"){ 
      }; 
      ~FSRB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSSM -- 
   ///@defgroup FSSM_doc 
   ///@class FSSM 
   ///@brief is the main Support Stucture Module [TGeoVolume] 
   class FSSM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSSM() : AgBlock("FSSM","is the main Support Stucture Module [TGeoVolume]"){ 
      }; 
      ~FSSM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSPG -- 
   ///@defgroup FSPG_doc 
   ///@class FSPG 
   ///@brief is the inner Support End Ring and the outer support Rings [TGeoVolume] 
   class FSPG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSPG() : AgBlock("FSPG","is the inner Support End Ring and the outer support Rings [TGeoVolume]"){ 
      }; 
      ~FSPG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSPI -- 
   ///@defgroup FSPI_doc 
   ///@class FSPI 
   ///@brief is the Hole of the inner Support End Ring [TGeoVolume] 
   class FSPI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSPI() : AgBlock("FSPI","is the Hole of the inner Support End Ring [TGeoVolume]"){ 
      }; 
      ~FSPI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSRI -- 
   ///@defgroup FSRI_doc 
   ///@class FSRI 
   ///@brief is the inner Support Ring [TGeoVolume] 
   class FSRI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSRI() : AgBlock("FSRI","is the inner Support Ring [TGeoVolume]"){ 
      }; 
      ~FSRI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSBA -- 
   ///@defgroup FSBA_doc 
   ///@class FSBA 
   ///@brief are the Stabilizer Block for the inner Support Ring [TGeoVolume] 
   class FSBA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSBA() : AgBlock("FSBA","are the Stabilizer Block for the inner Support Ring [TGeoVolume]"){ 
      }; 
      ~FSBA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FPAD -- 
   ///@defgroup FPAD_doc 
   ///@class FPAD 
   ///@brief is the Pad plane of the FTPC [TGeoVolume] 
   class FPAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FPAD() : AgBlock("FPAD","is the Pad plane of the FTPC [TGeoVolume]"){ 
      }; 
      ~FPAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FFRA -- 
   ///@defgroup FFRA_doc 
   ///@class FFRA 
   ///@brief is outermost FC Ring [TGeoVolume] 
   class FFRA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FFRA() : AgBlock("FFRA","is outermost FC Ring [TGeoVolume]"){ 
      }; 
      ~FFRA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class FtpcGeo1 
   /// \brief   is the Forward TPC in STAR with corrected GAS  
   class FtpcGeo1 : public AgModule 
   { 
      public: 
      FtpcGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~FtpcGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace FtpcGeo1 
#endif // __FtpcGeo1__ 
