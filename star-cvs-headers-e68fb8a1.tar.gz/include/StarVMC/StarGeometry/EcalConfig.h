#ifndef __ECAL_CONFIG__ 
#define __ECAL_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/EcalGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/EcalGeo6.h" 
namespace ECAL { //
struct ECALof {
  static const char *name()    { return "ECALof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "EcalGeo"; }
  static       bool  list();
  typedef ECALGEO::EcalGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ECAL { //
struct ECALon {
  static const char *name()    { return "ECALon"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "EcalGeo"; }
  static       bool  list();
  typedef ECALGEO::EcalGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ECAL { //
struct ECAL31 {
  static const char *name()    { return "ECAL31"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "EcalGeo"; }
  static       bool  list();
  typedef ECALGEO::EcalGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ECAL { //
struct ECAL11 {
  static const char *name()    { return "ECAL11"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "EcalGeo"; }
  static       bool  list();
  typedef ECALGEO::EcalGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ECAL { //
struct ECAL33 {
  static const char *name()    { return "ECAL33"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "EcalGeo"; }
  static       bool  list();
  typedef ECALGEO::EcalGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ECAL { //
struct ECALv6 {
  static const char *name()    { return "ECALv6"; }
  static const char *comment() { return "Version 6 endcap"; }
  static const char *module()  { return "EcalGeo6"; }
  static       bool  list();
  typedef ECALGEO6::EcalGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ECAL { //
struct ECALv6_cut00 {
  static const char *name()    { return "ECALv6_cut00"; }
  static const char *comment() { return "Version 6 endcap [no emc cuts]"; }
  static const char *module()  { return "EcalGeo6"; }
  static       bool  list();
  typedef ECALGEO6::EcalGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
