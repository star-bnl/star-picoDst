#ifndef __PHMD_CONFIG__ 
#define __PHMD_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PhmdGeo.h" 
namespace PHMD { //
struct PHMDof {
  static const char *name()    { return "PHMDof"; }
  static const char *comment() { return "PHMD off"; }
  static const char *module()  { return "PhmdGeo"; }
  static       bool  list();
  typedef PHMDGEO::PhmdGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PHMD { //
struct PHMDon {
  static const char *name()    { return "PHMDon"; }
  static const char *comment() { return "Default configuration for the Forward GEM tracker"; }
  static const char *module()  { return "PhmdGeo"; }
  static       bool  list();
  typedef PHMDGEO::PhmdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PHMD { //
struct PHMD01 {
  static const char *name()    { return "PHMD01"; }
  static const char *comment() { return "Default configuration for the Forward GEM tracker"; }
  static const char *module()  { return "PhmdGeo"; }
  static       bool  list();
  typedef PHMDGEO::PhmdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PHMD { //
struct PHMD02 {
  static const char *name()    { return "PHMD02"; }
  static const char *comment() { return "Default configuration for the Forward GEM tracker"; }
  static const char *module()  { return "PhmdGeo"; }
  static       bool  list();
  typedef PHMDGEO::PhmdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
