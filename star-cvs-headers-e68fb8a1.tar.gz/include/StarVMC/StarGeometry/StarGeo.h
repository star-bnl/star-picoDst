#ifndef __construct_y2019_geometry__ 
#define __construct_y2019_geometry__ 
struct y2019 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2018_geometry__ 
#define __construct_y2018_geometry__ 
struct y2018 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2018a_geometry__ 
#define __construct_y2018a_geometry__ 
struct y2018a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2018x_geometry__ 
#define __construct_y2018x_geometry__ 
struct y2018x { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2017_geometry__ 
#define __construct_y2017_geometry__ 
struct y2017 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2017a_geometry__ 
#define __construct_y2017a_geometry__ 
struct y2017a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2016_geometry__ 
#define __construct_y2016_geometry__ 
struct y2016 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2016a_geometry__ 
#define __construct_y2016a_geometry__ 
struct y2016a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2016x_geometry__ 
#define __construct_y2016x_geometry__ 
struct y2016x { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2015_geometry__ 
#define __construct_y2015_geometry__ 
struct y2015 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2015a_geometry__ 
#define __construct_y2015a_geometry__ 
struct y2015a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2015b_geometry__ 
#define __construct_y2015b_geometry__ 
struct y2015b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2015c_geometry__ 
#define __construct_y2015c_geometry__ 
struct y2015c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2015d_geometry__ 
#define __construct_y2015d_geometry__ 
struct y2015d { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2015x_geometry__ 
#define __construct_y2015x_geometry__ 
struct y2015x { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2014_geometry__ 
#define __construct_y2014_geometry__ 
struct y2014 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2014a_geometry__ 
#define __construct_y2014a_geometry__ 
struct y2014a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2014b_geometry__ 
#define __construct_y2014b_geometry__ 
struct y2014b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2014c_geometry__ 
#define __construct_y2014c_geometry__ 
struct y2014c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2014x_geometry__ 
#define __construct_y2014x_geometry__ 
struct y2014x { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_geometry__ 
#define __construct_y2013_geometry__ 
struct y2013 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_1_geometry__ 
#define __construct_y2013_1_geometry__ 
struct y2013_1 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_2_geometry__ 
#define __construct_y2013_2_geometry__ 
struct y2013_2 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013a_geometry__ 
#define __construct_y2013a_geometry__ 
struct y2013a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_1a_geometry__ 
#define __construct_y2013_1a_geometry__ 
struct y2013_1a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_2a_geometry__ 
#define __construct_y2013_2a_geometry__ 
struct y2013_2a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013b_geometry__ 
#define __construct_y2013b_geometry__ 
struct y2013b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_1b_geometry__ 
#define __construct_y2013_1b_geometry__ 
struct y2013_1b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_2b_geometry__ 
#define __construct_y2013_2b_geometry__ 
struct y2013_2b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013c_geometry__ 
#define __construct_y2013c_geometry__ 
struct y2013c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_1c_geometry__ 
#define __construct_y2013_1c_geometry__ 
struct y2013_1c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_2c_geometry__ 
#define __construct_y2013_2c_geometry__ 
struct y2013_2c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013x_geometry__ 
#define __construct_y2013x_geometry__ 
struct y2013x { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_1x_geometry__ 
#define __construct_y2013_1x_geometry__ 
struct y2013_1x { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2013_2x_geometry__ 
#define __construct_y2013_2x_geometry__ 
struct y2013_2x { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2012_geometry__ 
#define __construct_y2012_geometry__ 
struct y2012 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2012a_geometry__ 
#define __construct_y2012a_geometry__ 
struct y2012a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2012b_geometry__ 
#define __construct_y2012b_geometry__ 
struct y2012b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2011_geometry__ 
#define __construct_y2011_geometry__ 
struct y2011 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2011a_geometry__ 
#define __construct_y2011a_geometry__ 
struct y2011a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2011b_geometry__ 
#define __construct_y2011b_geometry__ 
struct y2011b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2010_geometry__ 
#define __construct_y2010_geometry__ 
struct y2010 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2010a_geometry__ 
#define __construct_y2010a_geometry__ 
struct y2010a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2010b_geometry__ 
#define __construct_y2010b_geometry__ 
struct y2010b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2010c_geometry__ 
#define __construct_y2010c_geometry__ 
struct y2010c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2009_geometry__ 
#define __construct_y2009_geometry__ 
struct y2009 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2009a_geometry__ 
#define __construct_y2009a_geometry__ 
struct y2009a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2009b_geometry__ 
#define __construct_y2009b_geometry__ 
struct y2009b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2009c_geometry__ 
#define __construct_y2009c_geometry__ 
struct y2009c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2009d_geometry__ 
#define __construct_y2009d_geometry__ 
struct y2009d { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2008_geometry__ 
#define __construct_y2008_geometry__ 
struct y2008 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2008a_geometry__ 
#define __construct_y2008a_geometry__ 
struct y2008a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2008b_geometry__ 
#define __construct_y2008b_geometry__ 
struct y2008b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2008c_geometry__ 
#define __construct_y2008c_geometry__ 
struct y2008c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2008d_geometry__ 
#define __construct_y2008d_geometry__ 
struct y2008d { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2008e_geometry__ 
#define __construct_y2008e_geometry__ 
struct y2008e { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2007_geometry__ 
#define __construct_y2007_geometry__ 
struct y2007 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2007a_geometry__ 
#define __construct_y2007a_geometry__ 
struct y2007a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2007g_geometry__ 
#define __construct_y2007g_geometry__ 
struct y2007g { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2007h_geometry__ 
#define __construct_y2007h_geometry__ 
struct y2007h { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2006_geometry__ 
#define __construct_y2006_geometry__ 
struct y2006 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2006a_geometry__ 
#define __construct_y2006a_geometry__ 
struct y2006a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2006b_geometry__ 
#define __construct_y2006b_geometry__ 
struct y2006b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2006c_geometry__ 
#define __construct_y2006c_geometry__ 
struct y2006c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2006g_geometry__ 
#define __construct_y2006g_geometry__ 
struct y2006g { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2006h_geometry__ 
#define __construct_y2006h_geometry__ 
struct y2006h { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2005_geometry__ 
#define __construct_y2005_geometry__ 
struct y2005 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2005b_geometry__ 
#define __construct_y2005b_geometry__ 
struct y2005b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2005c_geometry__ 
#define __construct_y2005c_geometry__ 
struct y2005c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2005d_geometry__ 
#define __construct_y2005d_geometry__ 
struct y2005d { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2005e_geometry__ 
#define __construct_y2005e_geometry__ 
struct y2005e { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2005f_geometry__ 
#define __construct_y2005f_geometry__ 
struct y2005f { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2005g_geometry__ 
#define __construct_y2005g_geometry__ 
struct y2005g { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2005h_geometry__ 
#define __construct_y2005h_geometry__ 
struct y2005h { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2005i_geometry__ 
#define __construct_y2005i_geometry__ 
struct y2005i { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2004_geometry__ 
#define __construct_y2004_geometry__ 
struct y2004 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2004a_geometry__ 
#define __construct_y2004a_geometry__ 
struct y2004a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2004b_geometry__ 
#define __construct_y2004b_geometry__ 
struct y2004b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2004c_geometry__ 
#define __construct_y2004c_geometry__ 
struct y2004c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2004d_geometry__ 
#define __construct_y2004d_geometry__ 
struct y2004d { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2003_geometry__ 
#define __construct_y2003_geometry__ 
struct y2003 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2003a_geometry__ 
#define __construct_y2003a_geometry__ 
struct y2003a { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2003b_geometry__ 
#define __construct_y2003b_geometry__ 
struct y2003b { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_y2003c_geometry__ 
#define __construct_y2003c_geometry__ 
struct y2003c { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_ftsver1_geometry__ 
#define __construct_ftsver1_geometry__ 
struct ftsver1 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_ftsver2_geometry__ 
#define __construct_ftsver2_geometry__ 
struct ftsver2 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_ftsver3_geometry__ 
#define __construct_ftsver3_geometry__ 
struct ftsver3 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_ftsver4_geometry__ 
#define __construct_ftsver4_geometry__ 
struct ftsver4 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_ftsref1_geometry__ 
#define __construct_ftsref1_geometry__ 
struct ftsref1 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_ftsref2_geometry__ 
#define __construct_ftsref2_geometry__ 
struct ftsref2 { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 
#ifndef __construct_blackhole_geometry__ 
#define __construct_blackhole_geometry__ 
struct blackhole { 
   static bool construct(); 
   static bool list(); 
}; 
#endif 

#ifndef __StarGeometry_h__
#define __StarGeometry_h__
#include "TDataSet.h"        
        class StarGeometry {
        public:
        /// Construct geometry with the specified tag, and return wrapped in a TDataSet
        static TDataSet* Construct( const char* name = "y2016" );
        static bool      List     ( const char* name = "y2016");
        StarGeometry(){ /* nada */ };
        virtual ~StarGeometry(){ /* nada */ }
        private:
        protected:
        ClassDef(StarGeometry,1);
        };

        // backwards compatability hack with StarDb/AgMLGeometry
        class Geometry : public StarGeometry {
        public:
        static TDataSet *ConstructGeometry( const char* name ){ return Construct(name); }
        Geometry():StarGeometry(){ /* nada */ };
        virtual ~Geometry(){ /* nada */ }
        ClassDef(Geometry,1);
        };
#endif        
         
