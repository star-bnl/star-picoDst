#ifndef __SUPO_CONFIG__ 
#define __SUPO_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SupoGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SupoGeo1.h" 
namespace SUPO { //
struct SUPOof {
  static const char *name()    { return "SUPOof"; }
  static const char *comment() { return "SUPO off"; }
  static const char *module()  { return "SupoGeo"; }
  static       bool  list();
  typedef SUPOGEO::SupoGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SUPO { //
struct SUPO00 {
  static const char *name()    { return "SUPO00"; }
  static const char *comment() { return "Default configuration for the Forward TPC supports"; }
  static const char *module()  { return "SupoGeo"; }
  static       bool  list();
  typedef SUPOGEO::SupoGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SUPO { //
struct SUPO01 {
  static const char *name()    { return "SUPO01"; }
  static const char *comment() { return "Default configuration for the Forward TPC supports"; }
  static const char *module()  { return "SupoGeo1"; }
  static       bool  list();
  typedef SUPOGEO1::SupoGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
