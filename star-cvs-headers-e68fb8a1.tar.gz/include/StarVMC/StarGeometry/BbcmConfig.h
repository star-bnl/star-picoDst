#ifndef __BBCM_CONFIG__ 
#define __BBCM_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/BbcmGeo.h" 
namespace BBCM { //
struct BBCMof {
  static const char *name()    { return "BBCMof"; }
  static const char *comment() { return "No BBCM"; }
  static const char *module()  { return "BbcmGeo"; }
  static       bool  list();
  typedef BBCMGEO::BbcmGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BBCM { //
struct BBCMon {
  static const char *name()    { return "BBCMon"; }
  static const char *comment() { return "Default configuration for the Beam Beam counter"; }
  static const char *module()  { return "BbcmGeo"; }
  static       bool  list();
  typedef BBCMGEO::BbcmGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BBCM { //
struct BBCMin {
  static const char *name()    { return "BBCMin"; }
  static const char *comment() { return "BBC with inner tiles only"; }
  static const char *module()  { return "BbcmGeo"; }
  static       bool  list();
  typedef BBCMGEO::BbcmGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
