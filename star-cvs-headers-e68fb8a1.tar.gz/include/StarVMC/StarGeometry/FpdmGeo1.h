#ifndef __FpdmGeo1__ 
#define __FpdmGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace FPDMGEO1 // $NMSPC 
{ 
   struct fmcg_t {
float version;
float chkvsim;
int _index;
};
 
   struct _fmcg_docum_ {
string version;
string chkvsim;
string _index;
};
 
    struct _fmcg_types_ {
  typedef float version;
  typedef float chkvsim;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fmcg_info {
typedef fmcg_t Type;
static const char *name(){ return "fmcg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct fmcg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct chkvsim {
  static const char *name() { return  "chkvsim"; }
  static int Offset(){ return offsetof( struct fmcg_t, chkvsim ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fmcg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fpos_t {
float imod;
float itype;
float x;
float y;
float z;
float ay;
int _index;
};
 
   struct _fpos_docum_ {
string imod;
string itype;
string x;
string y;
string z;
string ay;
string _index;
};
 
    struct _fpos_types_ {
  typedef float imod;
  typedef float itype;
  typedef float x;
  typedef float y;
  typedef float z;
  typedef float ay;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fpos_info {
typedef fpos_t Type;
static const char *name(){ return "fpos_t"; }
struct imod {
  static const char *name() { return  "imod"; }
  static int Offset(){ return offsetof( struct fpos_t, imod ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct itype {
  static const char *name() { return  "itype"; }
  static int Offset(){ return offsetof( struct fpos_t, itype ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct fpos_t, x ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct fpos_t, y ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct fpos_t, z ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ay {
  static const char *name() { return  "ay"; }
  static int Offset(){ return offsetof( struct fpos_t, ay ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fpos_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fbxd_t {
float type;
float height;
float depth;
float nx;
float ny;
float xoffset;
float zoffset;
float psoffset;
float smdoffset;
int _index;
};
 
   struct _fbxd_docum_ {
string type;
string height;
string depth;
string nx;
string ny;
string xoffset;
string zoffset;
string psoffset;
string smdoffset;
string _index;
};
 
    struct _fbxd_types_ {
  typedef float type;
  typedef float height;
  typedef float depth;
  typedef float nx;
  typedef float ny;
  typedef float xoffset;
  typedef float zoffset;
  typedef float psoffset;
  typedef float smdoffset;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fbxd_info {
typedef fbxd_t Type;
static const char *name(){ return "fbxd_t"; }
struct type {
  static const char *name() { return  "type"; }
  static int Offset(){ return offsetof( struct fbxd_t, type ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct height {
  static const char *name() { return  "height"; }
  static int Offset(){ return offsetof( struct fbxd_t, height ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct depth {
  static const char *name() { return  "depth"; }
  static int Offset(){ return offsetof( struct fbxd_t, depth ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nx {
  static const char *name() { return  "nx"; }
  static int Offset(){ return offsetof( struct fbxd_t, nx ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ny {
  static const char *name() { return  "ny"; }
  static int Offset(){ return offsetof( struct fbxd_t, ny ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xoffset {
  static const char *name() { return  "xoffset"; }
  static int Offset(){ return offsetof( struct fbxd_t, xoffset ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zoffset {
  static const char *name() { return  "zoffset"; }
  static int Offset(){ return offsetof( struct fbxd_t, zoffset ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct psoffset {
  static const char *name() { return  "psoffset"; }
  static int Offset(){ return offsetof( struct fbxd_t, psoffset ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smdoffset {
  static const char *name() { return  "smdoffset"; }
  static int Offset(){ return offsetof( struct fbxd_t, smdoffset ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fbxd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct flgg_t {
float width;
float depth;
float dgap;
float althick;
float phcathdz;
float phcathr;
float mumetdz;
float mumetr;
int _index;
};
 
   struct _flgg_docum_ {
string width;
string depth;
string dgap;
string althick;
string phcathdz;
string phcathr;
string mumetdz;
string mumetr;
string _index;
};
 
    struct _flgg_types_ {
  typedef float width;
  typedef float depth;
  typedef float dgap;
  typedef float althick;
  typedef float phcathdz;
  typedef float phcathr;
  typedef float mumetdz;
  typedef float mumetr;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct flgg_info {
typedef flgg_t Type;
static const char *name(){ return "flgg_t"; }
struct width {
  static const char *name() { return  "width"; }
  static int Offset(){ return offsetof( struct flgg_t, width ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct depth {
  static const char *name() { return  "depth"; }
  static int Offset(){ return offsetof( struct flgg_t, depth ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dgap {
  static const char *name() { return  "dgap"; }
  static int Offset(){ return offsetof( struct flgg_t, dgap ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct althick {
  static const char *name() { return  "althick"; }
  static int Offset(){ return offsetof( struct flgg_t, althick ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phcathdz {
  static const char *name() { return  "phcathdz"; }
  static int Offset(){ return offsetof( struct flgg_t, phcathdz ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phcathr {
  static const char *name() { return  "phcathr"; }
  static int Offset(){ return offsetof( struct flgg_t, phcathr ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mumetdz {
  static const char *name() { return  "mumetdz"; }
  static int Offset(){ return offsetof( struct flgg_t, mumetdz ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mumetr {
  static const char *name() { return  "mumetr"; }
  static int Offset(){ return offsetof( struct flgg_t, mumetr ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct flgg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct flgm_t {
float density;
float radlen;
float pbcont;
float critene;
float molierer;
int _index;
};
 
   struct _flgm_docum_ {
string density;
string radlen;
string pbcont;
string critene;
string molierer;
string _index;
};
 
    struct _flgm_types_ {
  typedef float density;
  typedef float radlen;
  typedef float pbcont;
  typedef float critene;
  typedef float molierer;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct flgm_info {
typedef flgm_t Type;
static const char *name(){ return "flgm_t"; }
struct density {
  static const char *name() { return  "density"; }
  static int Offset(){ return offsetof( struct flgm_t, density ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct radlen {
  static const char *name() { return  "radlen"; }
  static int Offset(){ return offsetof( struct flgm_t, radlen ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pbcont {
  static const char *name() { return  "pbcont"; }
  static int Offset(){ return offsetof( struct flgm_t, pbcont ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct critene {
  static const char *name() { return  "critene"; }
  static int Offset(){ return offsetof( struct flgm_t, critene ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct molierer {
  static const char *name() { return  "molierer"; }
  static int Offset(){ return offsetof( struct flgm_t, molierer ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct flgm_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct pbpd_t {
float z;
float width;
float height;
float thick;
int _index;
};
 
   struct _pbpd_docum_ {
string z;
string width;
string height;
string thick;
string _index;
};
 
    struct _pbpd_types_ {
  typedef float z;
  typedef float width;
  typedef float height;
  typedef float thick;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pbpd_info {
typedef pbpd_t Type;
static const char *name(){ return "pbpd_t"; }
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct pbpd_t, z ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct width {
  static const char *name() { return  "width"; }
  static int Offset(){ return offsetof( struct pbpd_t, width ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct height {
  static const char *name() { return  "height"; }
  static int Offset(){ return offsetof( struct pbpd_t, height ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct thick {
  static const char *name() { return  "thick"; }
  static int Offset(){ return offsetof( struct pbpd_t, thick ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pbpd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fmxg_t {
float version;
float sapex;
float sbase;
float sgap;
float nstrip;
float g10width;
float g10height;
float g10thick;
int _index;
};
 
   struct _fmxg_docum_ {
string version;
string sapex;
string sbase;
string sgap;
string nstrip;
string g10width;
string g10height;
string g10thick;
string _index;
};
 
    struct _fmxg_types_ {
  typedef float version;
  typedef float sapex;
  typedef float sbase;
  typedef float sgap;
  typedef float nstrip;
  typedef float g10width;
  typedef float g10height;
  typedef float g10thick;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fmxg_info {
typedef fmxg_t Type;
static const char *name(){ return "fmxg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct fmxg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sapex {
  static const char *name() { return  "sapex"; }
  static int Offset(){ return offsetof( struct fmxg_t, sapex ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sbase {
  static const char *name() { return  "sbase"; }
  static int Offset(){ return offsetof( struct fmxg_t, sbase ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sgap {
  static const char *name() { return  "sgap"; }
  static int Offset(){ return offsetof( struct fmxg_t, sgap ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nstrip {
  static const char *name() { return  "nstrip"; }
  static int Offset(){ return offsetof( struct fmxg_t, nstrip ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct g10width {
  static const char *name() { return  "g10width"; }
  static int Offset(){ return offsetof( struct fmxg_t, g10width ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct g10height {
  static const char *name() { return  "g10height"; }
  static int Offset(){ return offsetof( struct fmxg_t, g10height ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct g10thick {
  static const char *name() { return  "g10thick"; }
  static int Offset(){ return offsetof( struct fmxg_t, g10thick ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fmxg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- FBOX -- 
   ///@defgroup FBOX_doc 
   ///@class FBOX 
   ///@brief is one Pb-Glass fpd detector [TGeoVolume] 
   class FBOX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FBOX() : AgBlock("FBOX","is one Pb-Glass fpd detector [TGeoVolume]"){ 
      }; 
      ~FBOX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FLGT -- 
   ///@defgroup FLGT_doc 
   ///@class FLGT 
   ///@brief is one PbG Tower [TGeoVolume] 
   class FLGT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FLGT() : AgBlock("FLGT","is one PbG Tower [TGeoVolume]"){ 
      }; 
      ~FLGT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FWAL -- 
   ///@defgroup FWAL_doc 
   ///@class FWAL 
   ///@brief is almunum wrapper [TGeoVolume] 
   class FWAL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FWAL() : AgBlock("FWAL","is almunum wrapper [TGeoVolume]"){ 
      }; 
      ~FWAL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FLGR -- 
   ///@defgroup FLGR_doc 
   ///@class FLGR 
   ///@brief is Lead Glass detector [TGeoVolume] 
   class FLGR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FLGR() : AgBlock("FLGR","is Lead Glass detector [TGeoVolume]"){ 
      }; 
      ~FLGR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FPCT -- 
   ///@defgroup FPCT_doc 
   ///@class FPCT 
   ///@brief is Photo Cathode [TGeoVolume] 
   class FPCT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FPCT() : AgBlock("FPCT","is Photo Cathode [TGeoVolume]"){ 
      }; 
      ~FPCT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FUMT -- 
   ///@defgroup FUMT_doc 
   ///@class FUMT 
   ///@brief is mu metal [TGeoVolume] 
   class FUMT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FUMT() : AgBlock("FUMT","is mu metal [TGeoVolume]"){ 
      }; 
      ~FUMT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PBPT -- 
   ///@defgroup PBPT_doc 
   ///@class PBPT 
   ///@brief is pb plate [TGeoVolume] 
   class PBPT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PBPT() : AgBlock("PBPT","is pb plate [TGeoVolume]"){ 
      }; 
      ~PBPT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSHM -- 
   ///@defgroup FSHM_doc 
   ///@class FSHM 
   ///@brief is the SHower Max section [TGeoVolume] 
   class FSHM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSHM() : AgBlock("FSHM","is the SHower Max section [TGeoVolume]"){ 
      }; 
      ~FSHM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FXGT -- 
   ///@defgroup FXGT_doc 
   ///@class FXGT 
   ///@brief is the G10 layer in the SMax [TGeoVolume] 
   class FXGT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FXGT() : AgBlock("FXGT","is the G10 layer in the SMax [TGeoVolume]"){ 
      }; 
      ~FXGT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FHMS -- 
   ///@defgroup FHMS_doc 
   ///@class FHMS 
   ///@brief is sHower Max Strip [TGeoVolume] 
   class FHMS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FHMS() : AgBlock("FHMS","is sHower Max Strip [TGeoVolume]"){ 
      }; 
      ~FHMS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class FpdmGeo1 
   /// \brief  is the Forward Pion Detector Modules GEOmetry  
   class FpdmGeo1 : public AgModule 
   { 
      public: 
      FpdmGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~FpdmGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace FpdmGeo1 
#endif // __FpdmGeo1__ 
