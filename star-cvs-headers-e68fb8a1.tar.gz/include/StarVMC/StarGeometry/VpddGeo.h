#ifndef __VpddGeo__ 
#define __VpddGeo__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace VPDDGEO // $NMSPC 
{ 
   struct vpdv_t {
float version;
float vpdconfig;
int _index;
};
 
   struct _vpdv_docum_ {
string version;
string vpdconfig;
string _index;
};
 
    struct _vpdv_types_ {
  typedef float version;
  typedef float vpdconfig;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct vpdv_info {
typedef vpdv_t Type;
static const char *name(){ return "vpdv_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct vpdv_t, version ); }
  static void* address(){ 
         long long iadd = (long long)vpdv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct vpdconfig {
  static const char *name() { return  "vpdconfig"; }
  static int Offset(){ return offsetof( struct vpdv_t, vpdconfig ); }
  static void* address(){ 
         long long iadd = (long long)vpdv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct vpdv_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)vpdv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct vpdg_t {
float version;
float zposeast;
float zposwest;
float rmin;
float rmax;
float bpwidth;
float bplength;
float bpthick;
float bxheight;
float bxlength;
float bxwidth;
float bxthick;
float bxzposc;
float fpwidth;
float fpheight;
float fpthick;
float fpawidth;
float fpahght;
float fpchght;
float fphhght;
float fphwidth;
float fphthick;
float stthick;
float stheight;
float stangle;
float stdiagsz;
float scwidth;
float scheight;
float sclength;
float scthick;
float clheight;
float clwidth;
float cllength;
float clthick;
float detlen;
float detrad;
float detfront;
float convthk;
float radithk;
float eleleng;
float drlayer;
float numpmt;
float pmtwall;
float pmtrad;
float pmtlen;
float ibchoice;
float ibposyc;
float ibposzc;
float ibleng;
float ibthickh;
float ibthickv;
float ibheight;
float ibwidth;
float ibwlen;
float ibwhghtf;
float ibwhghtb;
int _index;
};
 
   struct _vpdg_docum_ {
string version;
string zposeast;
string zposwest;
string rmin;
string rmax;
string bpwidth;
string bplength;
string bpthick;
string bxheight;
string bxlength;
string bxwidth;
string bxthick;
string bxzposc;
string fpwidth;
string fpheight;
string fpthick;
string fpawidth;
string fpahght;
string fpchght;
string fphhght;
string fphwidth;
string fphthick;
string stthick;
string stheight;
string stangle;
string stdiagsz;
string scwidth;
string scheight;
string sclength;
string scthick;
string clheight;
string clwidth;
string cllength;
string clthick;
string detlen;
string detrad;
string detfront;
string convthk;
string radithk;
string eleleng;
string drlayer;
string numpmt;
string pmtwall;
string pmtrad;
string pmtlen;
string ibchoice;
string ibposyc;
string ibposzc;
string ibleng;
string ibthickh;
string ibthickv;
string ibheight;
string ibwidth;
string ibwlen;
string ibwhghtf;
string ibwhghtb;
string _index;
};
 
    struct _vpdg_types_ {
  typedef float version;
  typedef float zposeast;
  typedef float zposwest;
  typedef float rmin;
  typedef float rmax;
  typedef float bpwidth;
  typedef float bplength;
  typedef float bpthick;
  typedef float bxheight;
  typedef float bxlength;
  typedef float bxwidth;
  typedef float bxthick;
  typedef float bxzposc;
  typedef float fpwidth;
  typedef float fpheight;
  typedef float fpthick;
  typedef float fpawidth;
  typedef float fpahght;
  typedef float fpchght;
  typedef float fphhght;
  typedef float fphwidth;
  typedef float fphthick;
  typedef float stthick;
  typedef float stheight;
  typedef float stangle;
  typedef float stdiagsz;
  typedef float scwidth;
  typedef float scheight;
  typedef float sclength;
  typedef float scthick;
  typedef float clheight;
  typedef float clwidth;
  typedef float cllength;
  typedef float clthick;
  typedef float detlen;
  typedef float detrad;
  typedef float detfront;
  typedef float convthk;
  typedef float radithk;
  typedef float eleleng;
  typedef float drlayer;
  typedef float numpmt;
  typedef float pmtwall;
  typedef float pmtrad;
  typedef float pmtlen;
  typedef float ibchoice;
  typedef float ibposyc;
  typedef float ibposzc;
  typedef float ibleng;
  typedef float ibthickh;
  typedef float ibthickv;
  typedef float ibheight;
  typedef float ibwidth;
  typedef float ibwlen;
  typedef float ibwhghtf;
  typedef float ibwhghtb;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct vpdg_info {
typedef vpdg_t Type;
static const char *name(){ return "vpdg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct vpdg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zposeast {
  static const char *name() { return  "zposeast"; }
  static int Offset(){ return offsetof( struct vpdg_t, zposeast ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zposwest {
  static const char *name() { return  "zposwest"; }
  static int Offset(){ return offsetof( struct vpdg_t, zposwest ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct vpdg_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct vpdg_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bpwidth {
  static const char *name() { return  "bpwidth"; }
  static int Offset(){ return offsetof( struct vpdg_t, bpwidth ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bplength {
  static const char *name() { return  "bplength"; }
  static int Offset(){ return offsetof( struct vpdg_t, bplength ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bpthick {
  static const char *name() { return  "bpthick"; }
  static int Offset(){ return offsetof( struct vpdg_t, bpthick ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bxheight {
  static const char *name() { return  "bxheight"; }
  static int Offset(){ return offsetof( struct vpdg_t, bxheight ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bxlength {
  static const char *name() { return  "bxlength"; }
  static int Offset(){ return offsetof( struct vpdg_t, bxlength ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bxwidth {
  static const char *name() { return  "bxwidth"; }
  static int Offset(){ return offsetof( struct vpdg_t, bxwidth ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bxthick {
  static const char *name() { return  "bxthick"; }
  static int Offset(){ return offsetof( struct vpdg_t, bxthick ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bxzposc {
  static const char *name() { return  "bxzposc"; }
  static int Offset(){ return offsetof( struct vpdg_t, bxzposc ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fpwidth {
  static const char *name() { return  "fpwidth"; }
  static int Offset(){ return offsetof( struct vpdg_t, fpwidth ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fpheight {
  static const char *name() { return  "fpheight"; }
  static int Offset(){ return offsetof( struct vpdg_t, fpheight ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fpthick {
  static const char *name() { return  "fpthick"; }
  static int Offset(){ return offsetof( struct vpdg_t, fpthick ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fpawidth {
  static const char *name() { return  "fpawidth"; }
  static int Offset(){ return offsetof( struct vpdg_t, fpawidth ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fpahght {
  static const char *name() { return  "fpahght"; }
  static int Offset(){ return offsetof( struct vpdg_t, fpahght ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fpchght {
  static const char *name() { return  "fpchght"; }
  static int Offset(){ return offsetof( struct vpdg_t, fpchght ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fphhght {
  static const char *name() { return  "fphhght"; }
  static int Offset(){ return offsetof( struct vpdg_t, fphhght ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fphwidth {
  static const char *name() { return  "fphwidth"; }
  static int Offset(){ return offsetof( struct vpdg_t, fphwidth ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fphthick {
  static const char *name() { return  "fphthick"; }
  static int Offset(){ return offsetof( struct vpdg_t, fphthick ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stthick {
  static const char *name() { return  "stthick"; }
  static int Offset(){ return offsetof( struct vpdg_t, stthick ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stheight {
  static const char *name() { return  "stheight"; }
  static int Offset(){ return offsetof( struct vpdg_t, stheight ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stangle {
  static const char *name() { return  "stangle"; }
  static int Offset(){ return offsetof( struct vpdg_t, stangle ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stdiagsz {
  static const char *name() { return  "stdiagsz"; }
  static int Offset(){ return offsetof( struct vpdg_t, stdiagsz ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct scwidth {
  static const char *name() { return  "scwidth"; }
  static int Offset(){ return offsetof( struct vpdg_t, scwidth ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct scheight {
  static const char *name() { return  "scheight"; }
  static int Offset(){ return offsetof( struct vpdg_t, scheight ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sclength {
  static const char *name() { return  "sclength"; }
  static int Offset(){ return offsetof( struct vpdg_t, sclength ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct scthick {
  static const char *name() { return  "scthick"; }
  static int Offset(){ return offsetof( struct vpdg_t, scthick ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct clheight {
  static const char *name() { return  "clheight"; }
  static int Offset(){ return offsetof( struct vpdg_t, clheight ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct clwidth {
  static const char *name() { return  "clwidth"; }
  static int Offset(){ return offsetof( struct vpdg_t, clwidth ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cllength {
  static const char *name() { return  "cllength"; }
  static int Offset(){ return offsetof( struct vpdg_t, cllength ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct clthick {
  static const char *name() { return  "clthick"; }
  static int Offset(){ return offsetof( struct vpdg_t, clthick ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct detlen {
  static const char *name() { return  "detlen"; }
  static int Offset(){ return offsetof( struct vpdg_t, detlen ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct detrad {
  static const char *name() { return  "detrad"; }
  static int Offset(){ return offsetof( struct vpdg_t, detrad ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct detfront {
  static const char *name() { return  "detfront"; }
  static int Offset(){ return offsetof( struct vpdg_t, detfront ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct convthk {
  static const char *name() { return  "convthk"; }
  static int Offset(){ return offsetof( struct vpdg_t, convthk ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct radithk {
  static const char *name() { return  "radithk"; }
  static int Offset(){ return offsetof( struct vpdg_t, radithk ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eleleng {
  static const char *name() { return  "eleleng"; }
  static int Offset(){ return offsetof( struct vpdg_t, eleleng ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct drlayer {
  static const char *name() { return  "drlayer"; }
  static int Offset(){ return offsetof( struct vpdg_t, drlayer ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct numpmt {
  static const char *name() { return  "numpmt"; }
  static int Offset(){ return offsetof( struct vpdg_t, numpmt ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtwall {
  static const char *name() { return  "pmtwall"; }
  static int Offset(){ return offsetof( struct vpdg_t, pmtwall ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtrad {
  static const char *name() { return  "pmtrad"; }
  static int Offset(){ return offsetof( struct vpdg_t, pmtrad ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtlen {
  static const char *name() { return  "pmtlen"; }
  static int Offset(){ return offsetof( struct vpdg_t, pmtlen ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibchoice {
  static const char *name() { return  "ibchoice"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibchoice ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibposyc {
  static const char *name() { return  "ibposyc"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibposyc ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibposzc {
  static const char *name() { return  "ibposzc"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibposzc ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibleng {
  static const char *name() { return  "ibleng"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibleng ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibthickh {
  static const char *name() { return  "ibthickh"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibthickh ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibthickv {
  static const char *name() { return  "ibthickv"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibthickv ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibheight {
  static const char *name() { return  "ibheight"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibheight ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibwidth {
  static const char *name() { return  "ibwidth"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibwidth ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibwlen {
  static const char *name() { return  "ibwlen"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibwlen ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibwhghtf {
  static const char *name() { return  "ibwhghtf"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibwhghtf ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ibwhghtb {
  static const char *name() { return  "ibwhghtb"; }
  static int Offset(){ return offsetof( struct vpdg_t, ibwhghtb ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct vpdg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)vpdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- VPDD -- 
   ///@defgroup VPDD_doc 
   ///@class VPDD 
   ///@brief is the whole VPPD assembly [TGeoVolume] 
   class VPDD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPDD() : AgBlock("VPDD","is the whole VPPD assembly [TGeoVolume]"){ 
      }; 
      ~VPDD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPBP -- 
   ///@defgroup VPBP_doc 
   ///@class VPBP 
   ///@brief is the Base Plate [TGeoVolume] 
   class VPBP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPBP() : AgBlock("VPBP","is the Base Plate [TGeoVolume]"){ 
      }; 
      ~VPBP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPBO -- 
   ///@defgroup VPBO_doc 
   ///@class VPBO 
   ///@brief is container for the hook [TGeoVolume] 
   class VPBO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPBO() : AgBlock("VPBO","is container for the hook [TGeoVolume]"){ 
      }; 
      ~VPBO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPBA -- 
   ///@defgroup VPBA_doc 
   ///@class VPBA 
   ///@brief is the part of the hook that mounts to the front/back plate [TGeoVolume] 
   class VPBA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPBA() : AgBlock("VPBA","is the part of the hook that mounts to the front/back plate [TGeoVolume]"){ 
      }; 
      ~VPBA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPBB -- 
   ///@defgroup VPBB_doc 
   ///@class VPBB 
   ///@brief is the part of the hook that mounts to the base plate [TGeoVolume] 
   class VPBB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPBB() : AgBlock("VPBB","is the part of the hook that mounts to the base plate [TGeoVolume]"){ 
      }; 
      ~VPBB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPFP -- 
   ///@defgroup VPFP_doc 
   ///@class VPFP 
   ///@brief is a single rectangular piece of the frontpanel [TGeoVolume] 
   class VPFP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPFP() : AgBlock("VPFP","is a single rectangular piece of the frontpanel [TGeoVolume]"){ 
      }; 
      ~VPFP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPFA -- 
   ///@defgroup VPFA_doc 
   ///@class VPFA 
   ///@brief is the central upper part of the frontplate [TGeoVolume] 
   class VPFA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPFA() : AgBlock("VPFA","is the central upper part of the frontplate [TGeoVolume]"){ 
      }; 
      ~VPFA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPFB -- 
   ///@defgroup VPFB_doc 
   ///@class VPFB 
   ///@brief is the middle upper part of the frontplate [TGeoVolume] 
   class VPFB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPFB() : AgBlock("VPFB","is the middle upper part of the frontplate [TGeoVolume]"){ 
      }; 
      ~VPFB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPFC -- 
   ///@defgroup VPFC_doc 
   ///@class VPFC 
   ///@brief is the outer upper part of the frontplate [TGeoVolume] 
   class VPFC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPFC() : AgBlock("VPFC","is the outer upper part of the frontplate [TGeoVolume]"){ 
      }; 
      ~VPFC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPST -- 
   ///@defgroup VPST_doc 
   ///@class VPST 
   ///@brief is the strut volume [TGeoVolume] 
   class VPST : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPST() : AgBlock("VPST","is the strut volume [TGeoVolume]"){ 
      }; 
      ~VPST(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPSV -- 
   ///@defgroup VPSV_doc 
   ///@class VPSV 
   ///@brief is the actual strut between front and backplates [TGeoVolume] 
   class VPSV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPSV() : AgBlock("VPSV","is the actual strut between front and backplates [TGeoVolume]"){ 
      }; 
      ~VPSV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPSW -- 
   ///@defgroup VPSW_doc 
   ///@class VPSW 
   ///@brief is a tiny piece of aluminium that belongs to the strut [TGeoVolume] 
   class VPSW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPSW() : AgBlock("VPSW","is a tiny piece of aluminium that belongs to the strut [TGeoVolume]"){ 
      }; 
      ~VPSW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPSC -- 
   ///@defgroup VPSC_doc 
   ///@class VPSC 
   ///@brief is a clamp that holds the strut [TGeoVolume] 
   class VPSC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPSC() : AgBlock("VPSC","is a clamp that holds the strut [TGeoVolume]"){ 
      }; 
      ~VPSC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPSA -- 
   ///@defgroup VPSA_doc 
   ///@class VPSA 
   ///@brief is part of a strut clamp that holds to the frontplate [TGeoVolume] 
   class VPSA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPSA() : AgBlock("VPSA","is part of a strut clamp that holds to the frontplate [TGeoVolume]"){ 
      }; 
      ~VPSA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPSB -- 
   ///@defgroup VPSB_doc 
   ///@class VPSB 
   ///@brief is part of a strut clamp that holds to the strut [TGeoVolume] 
   class VPSB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPSB() : AgBlock("VPSB","is part of a strut clamp that holds to the strut [TGeoVolume]"){ 
      }; 
      ~VPSB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPBX -- 
   ///@defgroup VPBX_doc 
   ///@class VPBX 
   ///@brief is the FEE box [TGeoVolume] 
   class VPBX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPBX() : AgBlock("VPBX","is the FEE box [TGeoVolume]"){ 
      }; 
      ~VPBX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPBI -- 
   ///@defgroup VPBI_doc 
   ///@class VPBI 
   ///@brief is the empty space inside of the FEE box [TGeoVolume] 
   class VPBI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPBI() : AgBlock("VPBI","is the empty space inside of the FEE box [TGeoVolume]"){ 
      }; 
      ~VPBI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VFEE -- 
   ///@defgroup VFEE_doc 
   ///@class VFEE 
   ///@brief is the FEE inside the box [TGeoVolume] 
   class VFEE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VFEE() : AgBlock("VFEE","is the FEE inside the box [TGeoVolume]"){ 
      }; 
      ~VFEE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VLEM -- 
   ///@defgroup VLEM_doc 
   ///@class VLEM 
   ///@brief is a Lemo connector on the FEE boards [TGeoVolume] 
   class VLEM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VLEM() : AgBlock("VLEM","is a Lemo connector on the FEE boards [TGeoVolume]"){ 
      }; 
      ~VLEM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPIP -- 
   ///@defgroup VPIP_doc 
   ///@class VPIP 
   ///@brief is the Long Pipe [TGeoVolume] 
   class VPIP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPIP() : AgBlock("VPIP","is the Long Pipe [TGeoVolume]"){ 
      }; 
      ~VPIP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VRNG -- 
   ///@defgroup VRNG_doc 
   ///@class VRNG 
   ///@brief is a single VPD Ring [TGeoVolume] 
   class VRNG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VRNG() : AgBlock("VRNG","is a single VPD Ring [TGeoVolume]"){ 
      }; 
      ~VRNG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VSEC -- 
   ///@defgroup VSEC_doc 
   ///@class VSEC 
   ///@brief is one VPD sector with all stuff inside [TGeoVolume] 
   class VSEC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VSEC() : AgBlock("VSEC","is one VPD sector with all stuff inside [TGeoVolume]"){ 
      }; 
      ~VSEC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VDET -- 
   ///@defgroup VDET_doc 
   ///@class VDET 
   ///@brief is a single detector (Radiator+converter and PMT+electroncs) [TGeoVolume] 
   class VDET : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VDET() : AgBlock("VDET","is a single detector (Radiator+converter and PMT+electroncs) [TGeoVolume]"){ 
      }; 
      ~VDET(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VDTI -- 
   ///@defgroup VDTI_doc 
   ///@class VDTI 
   ///@brief is inner part of the single detector [TGeoVolume] 
   class VDTI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VDTI() : AgBlock("VDTI","is inner part of the single detector [TGeoVolume]"){ 
      }; 
      ~VDTI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VCNV -- 
   ///@defgroup VCNV_doc 
   ///@class VCNV 
   ///@brief is converter layer (radiator included) [TGeoVolume] 
   class VCNV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VCNV() : AgBlock("VCNV","is converter layer (radiator included) [TGeoVolume]"){ 
      }; 
      ~VCNV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VRAD -- 
   ///@defgroup VRAD_doc 
   ///@class VRAD 
   ///@brief is Cerenkov Radiator layer [TGeoVolume] 
   class VRAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VRAD() : AgBlock("VRAD","is Cerenkov Radiator layer [TGeoVolume]"){ 
      }; 
      ~VRAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPMT -- 
   ///@defgroup VPMT_doc 
   ///@class VPMT 
   ///@brief is the PMT inner volume [TGeoVolume] 
   class VPMT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPMT() : AgBlock("VPMT","is the PMT inner volume [TGeoVolume]"){ 
      }; 
      ~VPMT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VXST -- 
   ///@defgroup VXST_doc 
   ///@class VXST 
   ///@brief are PMT output cables (just to look nicer) [TGeoVolume] 
   class VXST : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VXST() : AgBlock("VXST","are PMT output cables (just to look nicer) [TGeoVolume]"){ 
      }; 
      ~VXST(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPCL -- 
   ///@defgroup VPCL_doc 
   ///@class VPCL 
   ///@brief is the boat clamp [TGeoVolume] 
   class VPCL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPCL() : AgBlock("VPCL","is the boat clamp [TGeoVolume]"){ 
      }; 
      ~VPCL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPCF -- 
   ///@defgroup VPCF_doc 
   ///@class VPCF 
   ///@brief is the front plate of the boat clamp [TGeoVolume] 
   class VPCF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPCF() : AgBlock("VPCF","is the front plate of the boat clamp [TGeoVolume]"){ 
      }; 
      ~VPCF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPCH -- 
   ///@defgroup VPCH_doc 
   ///@class VPCH 
   ///@brief is the horizontal plate of the boat clamp [TGeoVolume] 
   class VPCH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPCH() : AgBlock("VPCH","is the horizontal plate of the boat clamp [TGeoVolume]"){ 
      }; 
      ~VPCH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- VPCV -- 
   ///@defgroup VPCV_doc 
   ///@class VPCV 
   ///@brief is the vertical plate of the boat clamp [TGeoVolume] 
   class VPCV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      VPCV() : AgBlock("VPCV","is the vertical plate of the boat clamp [TGeoVolume]"){ 
      }; 
      ~VPCV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- IBEM -- 
   ///@defgroup IBEM_doc 
   ///@class IBEM 
   ///@brief is the IBeam structure beneath the Bell reducer cone [TGeoVolume] 
   class IBEM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      IBEM() : AgBlock("IBEM","is the IBeam structure beneath the Bell reducer cone [TGeoVolume]"){ 
      }; 
      ~IBEM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- IBEH -- 
   ///@defgroup IBEH_doc 
   ///@class IBEH 
   ///@brief is a horizontal IBeam plate [TGeoVolume] 
   class IBEH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      IBEH() : AgBlock("IBEH","is a horizontal IBeam plate [TGeoVolume]"){ 
      }; 
      ~IBEH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- IBEV -- 
   ///@defgroup IBEV_doc 
   ///@class IBEV 
   ///@brief is a vertical IBeam plate [TGeoVolume] 
   class IBEV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      IBEV() : AgBlock("IBEV","is a vertical IBeam plate [TGeoVolume]"){ 
      }; 
      ~IBEV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- IBEW -- 
   ///@defgroup IBEW_doc 
   ///@class IBEW 
   ///@brief is the first part of the IBeam plate [TGeoVolume] 
   class IBEW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      IBEW() : AgBlock("IBEW","is the first part of the IBeam plate [TGeoVolume]"){ 
      }; 
      ~IBEW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class VpddGeo 
   /// \brief   is the Pseudo Vertex Position Detector of STAR  
   class VpddGeo : public AgModule 
   { 
      public: 
      VpddGeo(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~VpddGeo(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace VpddGeo 
#endif // __VpddGeo__ 
