#ifndef __QUAD_CONFIG__ 
#define __QUAD_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/QuadGeo.h" 
namespace QUAD { //
struct QUADof {
  static const char *name()    { return "QUADof"; }
  static const char *comment() { return "FGT off"; }
  static const char *module()  { return "QuadGeo"; }
  static       bool  list();
  typedef QUADGEO::QuadGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace QUAD { //
struct QUADon {
  static const char *name()    { return "QUADon"; }
  static const char *comment() { return "Default configuration for the Forward GEM tracker"; }
  static const char *module()  { return "QuadGeo"; }
  static       bool  list();
  typedef QUADGEO::QuadGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
