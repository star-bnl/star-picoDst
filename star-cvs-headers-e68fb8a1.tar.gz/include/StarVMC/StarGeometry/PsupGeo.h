#ifndef __PsupGeo__ 
#define __PsupGeo__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace PSUPGEO // $NMSPC 
{ 
   struct mtbp_t {
float dy[5];
int _index;
};
 
   struct _mtbp_docum_ {
string dy;
string _index;
};
 
    struct _mtbp_types_ {
  typedef float dy[5];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mtbp_info {
typedef mtbp_t Type;
static const char *name(){ return "mtbp_t"; }
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct mtbp_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)mtbp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[5];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mtbp_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mtbp_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- PSUP -- 
   ///@defgroup PSUP_doc 
   ///@class PSUP 
   ///@brief Pixel Support mother volume [TGeoVolume] 
   class PSUP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSUP() : AgBlock("PSUP","Pixel Support mother volume [TGeoVolume]"){ 
      }; 
      ~PSUP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSBA -- 
   ///@defgroup PSBA_doc 
   ///@class PSBA 
   ///@brief Carriage Base [TGeoVolume] 
   class PSBA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSBA() : AgBlock("PSBA","Carriage Base [TGeoVolume]"){ 
      }; 
      ~PSBA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PHBB -- 
   ///@defgroup PHBB_doc 
   ///@class PHBB 
   ///@brief Carriage support ring [TGeoVolume] 
   class PHBB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PHBB() : AgBlock("PHBB","Carriage support ring [TGeoVolume]"){ 
      }; 
      ~PHBB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHA -- 
   ///@defgroup PSHA_doc 
   ///@class PSHA 
   ///@brief PSHA Hinge release partA (1) [TGeoVolume] 
   class PSHA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHA() : AgBlock("PSHA","PSHA Hinge release partA (1) [TGeoVolume]"){ 
      }; 
      ~PSHA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHC -- 
   ///@defgroup PSHC_doc 
   ///@class PSHC 
   ///@brief PSHC Hinge release partA (1) [TGeoVolume] 
   class PSHC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHC() : AgBlock("PSHC","PSHC Hinge release partA (1) [TGeoVolume]"){ 
      }; 
      ~PSHC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHE -- 
   ///@defgroup PSHE_doc 
   ///@class PSHE 
   ///@brief PSHE Hinge release partA (1) [TGeoVolume] 
   class PSHE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHE() : AgBlock("PSHE","PSHE Hinge release partA (1) [TGeoVolume]"){ 
      }; 
      ~PSHE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHG -- 
   ///@defgroup PSHG_doc 
   ///@class PSHG 
   ///@brief PSHG Hinge release partA (1) [TGeoVolume] 
   class PSHG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHG() : AgBlock("PSHG","PSHG Hinge release partA (1) [TGeoVolume]"){ 
      }; 
      ~PSHG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHS -- 
   ///@defgroup PSHS_doc 
   ///@class PSHS 
   ///@brief PSHG Hinge release air cylinder [TGeoVolume] 
   class PSHS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHS() : AgBlock("PSHS","PSHG Hinge release air cylinder [TGeoVolume]"){ 
      }; 
      ~PSHS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHT -- 
   ///@defgroup PSHT_doc 
   ///@class PSHT 
   ///@brief PSHG Hinge release air cylinder- inner part [TGeoVolume] 
   class PSHT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHT() : AgBlock("PSHT","PSHG Hinge release air cylinder- inner part [TGeoVolume]"){ 
      }; 
      ~PSHT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHL -- 
   ///@defgroup PSHL_doc 
   ///@class PSHL 
   ///@brief Hinge leaf inner Mother volume [TGeoVolume] 
   class PSHL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHL() : AgBlock("PSHL","Hinge leaf inner Mother volume [TGeoVolume]"){ 
      }; 
      ~PSHL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PHHA -- 
   ///@defgroup PHHA_doc 
   ///@class PHHA 
   ///@brief Part of hinge leave [TGeoVolume] 
   class PHHA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PHHA() : AgBlock("PHHA","Part of hinge leave [TGeoVolume]"){ 
      }; 
      ~PHHA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PHHB -- 
   ///@defgroup PHHB_doc 
   ///@class PHHB 
   ///@brief Part of hinge leave [TGeoVolume] 
   class PHHB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PHHB() : AgBlock("PHHB","Part of hinge leave [TGeoVolume]"){ 
      }; 
      ~PHHB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PHHC -- 
   ///@defgroup PHHC_doc 
   ///@class PHHC 
   ///@brief Outer hinge leaf [TGeoVolume] 
   class PHHC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PHHC() : AgBlock("PHHC","Outer hinge leaf [TGeoVolume]"){ 
      }; 
      ~PHHC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHU -- 
   ///@defgroup PSHU_doc 
   ///@class PSHU 
   ///@brief Outer hinge leaf [TGeoVolume] 
   class PSHU : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHU() : AgBlock("PSHU","Outer hinge leaf [TGeoVolume]"){ 
      }; 
      ~PSHU(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHM -- 
   ///@defgroup PSHM_doc 
   ///@class PSHM 
   ///@brief Extension tube attach ring [TGeoVolume] 
   class PSHM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHM() : AgBlock("PSHM","Extension tube attach ring [TGeoVolume]"){ 
      }; 
      ~PSHM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSTO -- 
   ///@defgroup PSTO_doc 
   ///@class PSTO 
   ///@brief Dtube ext plane top [TGeoVolume] 
   class PSTO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSTO() : AgBlock("PSTO","Dtube ext plane top [TGeoVolume]"){ 
      }; 
      ~PSTO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSOC -- 
   ///@defgroup PSOC_doc 
   ///@class PSOC 
   ///@brief a Outside CYLinder  [TGeoVolume] 
   class PSOC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSOC() : AgBlock("PSOC","a Outside CYLinder  [TGeoVolume]"){ 
      }; 
      ~PSOC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSIC -- 
   ///@defgroup PSIC_doc 
   ///@class PSIC 
   ///@brief a Outside CYLinder  [TGeoVolume] 
   class PSIC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSIC() : AgBlock("PSIC","a Outside CYLinder  [TGeoVolume]"){ 
      }; 
      ~PSIC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSUC -- 
   ///@defgroup PSUC_doc 
   ///@class PSUC 
   ///@brief a Upper corner [TGeoVolume] 
   class PSUC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSUC() : AgBlock("PSUC","a Upper corner [TGeoVolume]"){ 
      }; 
      ~PSUC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSBC -- 
   ///@defgroup PSBC_doc 
   ///@class PSBC 
   ///@brief a Upper corner [TGeoVolume] 
   class PSBC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSBC() : AgBlock("PSBC","a Upper corner [TGeoVolume]"){ 
      }; 
      ~PSBC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHN -- 
   ///@defgroup PSHN_doc 
   ///@class PSHN 
   ///@brief Carriage Base ext [TGeoVolume] 
   class PSHN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHN() : AgBlock("PSHN","Carriage Base ext [TGeoVolume]"){ 
      }; 
      ~PSHN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHO -- 
   ///@defgroup PSHO_doc 
   ///@class PSHO 
   ///@brief Carriage Base ext center part [TGeoVolume] 
   class PSHO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHO() : AgBlock("PSHO","Carriage Base ext center part [TGeoVolume]"){ 
      }; 
      ~PSHO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHP -- 
   ///@defgroup PSHP_doc 
   ///@class PSHP 
   ///@brief Carriage Base ext [TGeoVolume] 
   class PSHP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHP() : AgBlock("PSHP","Carriage Base ext [TGeoVolume]"){ 
      }; 
      ~PSHP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHQ -- 
   ///@defgroup PSHQ_doc 
   ///@class PSHQ 
   ///@brief Carriage Base ext [TGeoVolume] 
   class PSHQ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHQ() : AgBlock("PSHQ","Carriage Base ext [TGeoVolume]"){ 
      }; 
      ~PSHQ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAL -- 
   ///@defgroup PSAL_doc 
   ///@class PSAL 
   ///@brief Air Al hose [TGeoVolume] 
   class PSAL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAL() : AgBlock("PSAL","Air Al hose [TGeoVolume]"){ 
      }; 
      ~PSAL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAK -- 
   ///@defgroup PSAK_doc 
   ///@class PSAK 
   ///@brief Air duct 1/2  [TGeoVolume] 
   class PSAK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAK() : AgBlock("PSAK","Air duct 1/2  [TGeoVolume]"){ 
      }; 
      ~PSAK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCC -- 
   ///@defgroup PSCC_doc 
   ///@class PSCC 
   ///@brief Carriage tray bracket (solid part) [TGeoVolume] 
   class PSCC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCC() : AgBlock("PSCC","Carriage tray bracket (solid part) [TGeoVolume]"){ 
      }; 
      ~PSCC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCI -- 
   ///@defgroup PSCI_doc 
   ///@class PSCI 
   ///@brief Carriage tray bracket (hollow part) [TGeoVolume] 
   class PSCI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCI() : AgBlock("PSCI","Carriage tray bracket (hollow part) [TGeoVolume]"){ 
      }; 
      ~PSCI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSHI -- 
   ///@defgroup PSHI_doc 
   ///@class PSHI 
   ///@brief Carriage hinge part [TGeoVolume] 
   class PSHI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSHI() : AgBlock("PSHI","Carriage hinge part [TGeoVolume]"){ 
      }; 
      ~PSHI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCL -- 
   ///@defgroup PSCL_doc 
   ///@class PSCL 
   ///@brief Cable support ladder [TGeoVolume] 
   class PSCL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCL() : AgBlock("PSCL","Cable support ladder [TGeoVolume]"){ 
      }; 
      ~PSCL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCK -- 
   ///@defgroup PSCK_doc 
   ///@class PSCK 
   ///@brief Cable support ladder top and bottom [TGeoVolume] 
   class PSCK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCK() : AgBlock("PSCK","Cable support ladder top and bottom [TGeoVolume]"){ 
      }; 
      ~PSCK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAR -- 
   ///@defgroup PSAR_doc 
   ///@class PSAR 
   ///@brief base slide  center, vertical part [TGeoVolume] 
   class PSAR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAR() : AgBlock("PSAR","base slide  center, vertical part [TGeoVolume]"){ 
      }; 
      ~PSAR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAH -- 
   ///@defgroup PSAH_doc 
   ///@class PSAH 
   ///@brief base slide  cutout in vertical part  [TGeoVolume] 
   class PSAH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAH() : AgBlock("PSAH","base slide  cutout in vertical part  [TGeoVolume]"){ 
      }; 
      ~PSAH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAT -- 
   ///@defgroup PSAT_doc 
   ///@class PSAT 
   ///@brief base slide  center, top and bottom part [TGeoVolume] 
   class PSAT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAT() : AgBlock("PSAT","base slide  center, top and bottom part [TGeoVolume]"){ 
      }; 
      ~PSAT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAS -- 
   ///@defgroup PSAS_doc 
   ///@class PSAS 
   ///@brief base slide - cable holder support [TGeoVolume] 
   class PSAS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAS() : AgBlock("PSAS","base slide - cable holder support [TGeoVolume]"){ 
      }; 
      ~PSAS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAA -- 
   ///@defgroup PSAA_doc 
   ///@class PSAA 
   ///@brief base slide-1  center, vertical part [TGeoVolume] 
   class PSAA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAA() : AgBlock("PSAA","base slide-1  center, vertical part [TGeoVolume]"){ 
      }; 
      ~PSAA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAC -- 
   ///@defgroup PSAC_doc 
   ///@class PSAC 
   ///@brief base slide-1  hole in vertical part [TGeoVolume] 
   class PSAC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAC() : AgBlock("PSAC","base slide-1  hole in vertical part [TGeoVolume]"){ 
      }; 
      ~PSAC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAB -- 
   ///@defgroup PSAB_doc 
   ///@class PSAB 
   ///@brief base slide-1  center, top and bottom  [TGeoVolume] 
   class PSAB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAB() : AgBlock("PSAB","base slide-1  center, top and bottom  [TGeoVolume]"){ 
      }; 
      ~PSAB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAD -- 
   ///@defgroup PSAD_doc 
   ///@class PSAD 
   ///@brief base slide-1 hingepin, includes part from BH termination  [TGeoVolume] 
   class PSAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAD() : AgBlock("PSAD","base slide-1 hingepin, includes part from BH termination  [TGeoVolume]"){ 
      }; 
      ~PSAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAE -- 
   ///@defgroup PSAE_doc 
   ///@class PSAE 
   ///@brief base slide-1  arm hinge female [TGeoVolume] 
   class PSAE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAE() : AgBlock("PSAE","base slide-1  arm hinge female [TGeoVolume]"){ 
      }; 
      ~PSAE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSAF -- 
   ///@defgroup PSAF_doc 
   ///@class PSAF 
   ///@brief base slide-1  arm hinge termination plate [TGeoVolume] 
   class PSAF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSAF() : AgBlock("PSAF","base slide-1  arm hinge termination plate [TGeoVolume]"){ 
      }; 
      ~PSAF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMB -- 
   ///@defgroup PSMB_doc 
   ///@class PSMB 
   ///@brief MTB g10 board [TGeoVolume] 
   class PSMB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMB() : AgBlock("PSMB","MTB g10 board [TGeoVolume]"){ 
      }; 
      ~PSMB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMT -- 
   ///@defgroup PSMT_doc 
   ///@class PSMT 
   ///@brief MTB Al support block [TGeoVolume] 
   class PSMT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMT() : AgBlock("PSMT","MTB Al support block [TGeoVolume]"){ 
      }; 
      ~PSMT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSPA -- 
   ///@defgroup PSPA_doc 
   ///@class PSPA 
   ///@brief MTB Cable Park Front [TGeoVolume] 
   class PSPA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSPA() : AgBlock("PSPA","MTB Cable Park Front [TGeoVolume]"){ 
      }; 
      ~PSPA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSPB -- 
   ///@defgroup PSPB_doc 
   ///@class PSPB 
   ///@brief MTB Cable Park Front (2) [TGeoVolume] 
   class PSPB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSPB() : AgBlock("PSPB","MTB Cable Park Front (2) [TGeoVolume]"){ 
      }; 
      ~PSPB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMD -- 
   ///@defgroup PSMD_doc 
   ///@class PSMD 
   ///@brief PSMD MTB support Arm [TGeoVolume] 
   class PSMD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMD() : AgBlock("PSMD","PSMD MTB support Arm [TGeoVolume]"){ 
      }; 
      ~PSMD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMI -- 
   ///@defgroup PSMI_doc 
   ///@class PSMI 
   ///@brief PSMI MTB support Arm hollow [TGeoVolume] 
   class PSMI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMI() : AgBlock("PSMI","PSMI MTB support Arm hollow [TGeoVolume]"){ 
      }; 
      ~PSMI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMJ -- 
   ///@defgroup PSMJ_doc 
   ///@class PSMJ 
   ///@brief MTB Al support Arm piece 1 [TGeoVolume] 
   class PSMJ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMJ() : AgBlock("PSMJ","MTB Al support Arm piece 1 [TGeoVolume]"){ 
      }; 
      ~PSMJ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMK -- 
   ///@defgroup PSMK_doc 
   ///@class PSMK 
   ///@brief PSMK MTB support Plate A [TGeoVolume] 
   class PSMK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMK() : AgBlock("PSMK","PSMK MTB support Plate A [TGeoVolume]"){ 
      }; 
      ~PSMK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSML -- 
   ///@defgroup PSML_doc 
   ///@class PSML 
   ///@brief PSML MTB support Plate B [TGeoVolume] 
   class PSML : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSML() : AgBlock("PSML","PSML MTB support Plate B [TGeoVolume]"){ 
      }; 
      ~PSML(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMM -- 
   ///@defgroup PSMM_doc 
   ///@class PSMM 
   ///@brief PSMM MTB support Plate C [TGeoVolume] 
   class PSMM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMM() : AgBlock("PSMM","PSMM MTB support Plate C [TGeoVolume]"){ 
      }; 
      ~PSMM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMN -- 
   ///@defgroup PSMN_doc 
   ///@class PSMN 
   ///@brief PSMN MTB support Plate D [TGeoVolume] 
   class PSMN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMN() : AgBlock("PSMN","PSMN MTB support Plate D [TGeoVolume]"){ 
      }; 
      ~PSMN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMO -- 
   ///@defgroup PSMO_doc 
   ///@class PSMO 
   ///@brief PSME MTB support Plate E part b [TGeoVolume] 
   class PSMO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMO() : AgBlock("PSMO","PSME MTB support Plate E part b [TGeoVolume]"){ 
      }; 
      ~PSMO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMQ -- 
   ///@defgroup PSMQ_doc 
   ///@class PSMQ 
   ///@brief MTB Al support Arm vertical piece 2  [TGeoVolume] 
   class PSMQ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMQ() : AgBlock("PSMQ","MTB Al support Arm vertical piece 2  [TGeoVolume]"){ 
      }; 
      ~PSMQ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMR -- 
   ///@defgroup PSMR_doc 
   ///@class PSMR 
   ///@brief MTB Al support Arm vertical piece 3 [TGeoVolume] 
   class PSMR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMR() : AgBlock("PSMR","MTB Al support Arm vertical piece 3 [TGeoVolume]"){ 
      }; 
      ~PSMR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSMP -- 
   ///@defgroup PSMP_doc 
   ///@class PSMP 
   ///@brief MTB Al support Arm vertical piece 5  [TGeoVolume] 
   class PSMP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSMP() : AgBlock("PSMP","MTB Al support Arm vertical piece 5  [TGeoVolume]"){ 
      }; 
      ~PSMP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCJ -- 
   ///@defgroup PSCJ_doc 
   ///@class PSCJ 
   ///@brief MTB Connector [TGeoVolume] 
   class PSCJ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCJ() : AgBlock("PSCJ","MTB Connector [TGeoVolume]"){ 
      }; 
      ~PSCJ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCM -- 
   ///@defgroup PSCM_doc 
   ///@class PSCM 
   ///@brief Signal cable [TGeoVolume] 
   class PSCM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCM() : AgBlock("PSCM","Signal cable [TGeoVolume]"){ 
      }; 
      ~PSCM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCN -- 
   ///@defgroup PSCN_doc 
   ///@class PSCN 
   ///@brief MTB cable [TGeoVolume] 
   class PSCN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCN() : AgBlock("PSCN","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSCN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCS -- 
   ///@defgroup PSCS_doc 
   ///@class PSCS 
   ///@brief MTB cable in tray [TGeoVolume] 
   class PSCS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCS() : AgBlock("PSCS","MTB cable in tray [TGeoVolume]"){ 
      }; 
      ~PSCS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCO -- 
   ///@defgroup PSCO_doc 
   ///@class PSCO 
   ///@brief MTB cable [TGeoVolume] 
   class PSCO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCO() : AgBlock("PSCO","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSCO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCT -- 
   ///@defgroup PSCT_doc 
   ///@class PSCT 
   ///@brief MTB cable in tray [TGeoVolume] 
   class PSCT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCT() : AgBlock("PSCT","MTB cable in tray [TGeoVolume]"){ 
      }; 
      ~PSCT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCP -- 
   ///@defgroup PSCP_doc 
   ///@class PSCP 
   ///@brief MTB cable [TGeoVolume] 
   class PSCP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCP() : AgBlock("PSCP","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSCP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCU -- 
   ///@defgroup PSCU_doc 
   ///@class PSCU 
   ///@brief MTB cable in tray [TGeoVolume] 
   class PSCU : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCU() : AgBlock("PSCU","MTB cable in tray [TGeoVolume]"){ 
      }; 
      ~PSCU(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCQ -- 
   ///@defgroup PSCQ_doc 
   ///@class PSCQ 
   ///@brief MTB cable [TGeoVolume] 
   class PSCQ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCQ() : AgBlock("PSCQ","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSCQ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCV -- 
   ///@defgroup PSCV_doc 
   ///@class PSCV 
   ///@brief MTB cable in tray [TGeoVolume] 
   class PSCV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCV() : AgBlock("PSCV","MTB cable in tray [TGeoVolume]"){ 
      }; 
      ~PSCV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCR -- 
   ///@defgroup PSCR_doc 
   ///@class PSCR 
   ///@brief MTB cable [TGeoVolume] 
   class PSCR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCR() : AgBlock("PSCR","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSCR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSCW -- 
   ///@defgroup PSCW_doc 
   ///@class PSCW 
   ///@brief MTB cable in tray [TGeoVolume] 
   class PSCW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSCW() : AgBlock("PSCW","MTB cable in tray [TGeoVolume]"){ 
      }; 
      ~PSCW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSDA -- 
   ///@defgroup PSDA_doc 
   ///@class PSDA 
   ///@brief MTB cable [TGeoVolume] 
   class PSDA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSDA() : AgBlock("PSDA","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSDA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSDB -- 
   ///@defgroup PSDB_doc 
   ///@class PSDB 
   ///@brief MTB cable [TGeoVolume] 
   class PSDB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSDB() : AgBlock("PSDB","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSDB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSDC -- 
   ///@defgroup PSDC_doc 
   ///@class PSDC 
   ///@brief MTB cable [TGeoVolume] 
   class PSDC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSDC() : AgBlock("PSDC","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSDC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSDD -- 
   ///@defgroup PSDD_doc 
   ///@class PSDD 
   ///@brief MTB cable [TGeoVolume] 
   class PSDD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSDD() : AgBlock("PSDD","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSDD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PSDE -- 
   ///@defgroup PSDE_doc 
   ///@class PSDE 
   ///@brief MTB cable [TGeoVolume] 
   class PSDE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PSDE() : AgBlock("PSDE","MTB cable [TGeoVolume]"){ 
      }; 
      ~PSDE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class PsupGeo 
   /// \brief Geometry for Pixel Support and insertion mechanism 
   class PsupGeo : public AgModule 
   { 
      public: 
      PsupGeo(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~PsupGeo(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace PsupGeo 
#endif // __PsupGeo__ 
