#ifndef __UpstGeo__ 
#define __UpstGeo__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace UPSTGEO // $NMSPC 
{ 
   struct pipu_t {
float version;
float zposit;
float dz_upst;
float p1innr;
float p1outr;
float p1leng;
float p2innr;
float p2outr;
float p2leng;
float p3innr;
float p3outr;
float p3leng;
float dxinnr;
float dxoutr;
float dxleng;
float csinnr;
float csoutr;
float ceinnr;
float ceoutr;
float cleng;
float pginnr;
float pgoutr;
float pgleng;
int _index;
};
 
   struct _pipu_docum_ {
string version;
string zposit;
string dz_upst;
string p1innr;
string p1outr;
string p1leng;
string p2innr;
string p2outr;
string p2leng;
string p3innr;
string p3outr;
string p3leng;
string dxinnr;
string dxoutr;
string dxleng;
string csinnr;
string csoutr;
string ceinnr;
string ceoutr;
string cleng;
string pginnr;
string pgoutr;
string pgleng;
string _index;
};
 
    struct _pipu_types_ {
  typedef float version;
  typedef float zposit;
  typedef float dz_upst;
  typedef float p1innr;
  typedef float p1outr;
  typedef float p1leng;
  typedef float p2innr;
  typedef float p2outr;
  typedef float p2leng;
  typedef float p3innr;
  typedef float p3outr;
  typedef float p3leng;
  typedef float dxinnr;
  typedef float dxoutr;
  typedef float dxleng;
  typedef float csinnr;
  typedef float csoutr;
  typedef float ceinnr;
  typedef float ceoutr;
  typedef float cleng;
  typedef float pginnr;
  typedef float pgoutr;
  typedef float pgleng;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pipu_info {
typedef pipu_t Type;
static const char *name(){ return "pipu_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct pipu_t, version ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zposit {
  static const char *name() { return  "zposit"; }
  static int Offset(){ return offsetof( struct pipu_t, zposit ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz_upst {
  static const char *name() { return  "dz_upst"; }
  static int Offset(){ return offsetof( struct pipu_t, dz_upst ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct p1innr {
  static const char *name() { return  "p1innr"; }
  static int Offset(){ return offsetof( struct pipu_t, p1innr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct p1outr {
  static const char *name() { return  "p1outr"; }
  static int Offset(){ return offsetof( struct pipu_t, p1outr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct p1leng {
  static const char *name() { return  "p1leng"; }
  static int Offset(){ return offsetof( struct pipu_t, p1leng ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct p2innr {
  static const char *name() { return  "p2innr"; }
  static int Offset(){ return offsetof( struct pipu_t, p2innr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct p2outr {
  static const char *name() { return  "p2outr"; }
  static int Offset(){ return offsetof( struct pipu_t, p2outr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct p2leng {
  static const char *name() { return  "p2leng"; }
  static int Offset(){ return offsetof( struct pipu_t, p2leng ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct p3innr {
  static const char *name() { return  "p3innr"; }
  static int Offset(){ return offsetof( struct pipu_t, p3innr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct p3outr {
  static const char *name() { return  "p3outr"; }
  static int Offset(){ return offsetof( struct pipu_t, p3outr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct p3leng {
  static const char *name() { return  "p3leng"; }
  static int Offset(){ return offsetof( struct pipu_t, p3leng ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dxinnr {
  static const char *name() { return  "dxinnr"; }
  static int Offset(){ return offsetof( struct pipu_t, dxinnr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dxoutr {
  static const char *name() { return  "dxoutr"; }
  static int Offset(){ return offsetof( struct pipu_t, dxoutr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dxleng {
  static const char *name() { return  "dxleng"; }
  static int Offset(){ return offsetof( struct pipu_t, dxleng ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct csinnr {
  static const char *name() { return  "csinnr"; }
  static int Offset(){ return offsetof( struct pipu_t, csinnr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct csoutr {
  static const char *name() { return  "csoutr"; }
  static int Offset(){ return offsetof( struct pipu_t, csoutr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ceinnr {
  static const char *name() { return  "ceinnr"; }
  static int Offset(){ return offsetof( struct pipu_t, ceinnr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ceoutr {
  static const char *name() { return  "ceoutr"; }
  static int Offset(){ return offsetof( struct pipu_t, ceoutr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cleng {
  static const char *name() { return  "cleng"; }
  static int Offset(){ return offsetof( struct pipu_t, cleng ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pginnr {
  static const char *name() { return  "pginnr"; }
  static int Offset(){ return offsetof( struct pipu_t, pginnr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pgoutr {
  static const char *name() { return  "pgoutr"; }
  static int Offset(){ return offsetof( struct pipu_t, pgoutr ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pgleng {
  static const char *name() { return  "pgleng"; }
  static int Offset(){ return offsetof( struct pipu_t, pgleng ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pipu_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pipu_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- UPST -- 
   ///@defgroup UPST_doc 
   ///@class UPST 
   ///@brief is the upstream mother volume in the STAR cave [TGeoVolume] 
   class UPST : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      UPST() : AgBlock("UPST","is the upstream mother volume in the STAR cave [TGeoVolume]"){ 
      }; 
      ~UPST(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PUPD -- 
   ///@defgroup PUPD_doc 
   ///@class PUPD 
   ///@brief is the Beam PIPe before the DX magnet [TGeoVolume] 
   class PUPD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PUPD() : AgBlock("PUPD","is the Beam PIPe before the DX magnet [TGeoVolume]"){ 
      }; 
      ~PUPD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAD -- 
   ///@defgroup PVAD_doc 
   ///@class PVAD 
   ///@brief is the Vacuum Volume of the PIPe before the DX magnet [TGeoVolume] 
   class PVAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAD() : AgBlock("PVAD","is the Vacuum Volume of the PIPe before the DX magnet [TGeoVolume]"){ 
      }; 
      ~PVAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PUPE -- 
   ///@defgroup PUPE_doc 
   ///@class PUPE 
   ///@brief is the Beam PIPe through the DX mAgnet Volume [TGeoVolume] 
   class PUPE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PUPE() : AgBlock("PUPE","is the Beam PIPe through the DX mAgnet Volume [TGeoVolume]"){ 
      }; 
      ~PUPE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAE -- 
   ///@defgroup PVAE_doc 
   ///@class PVAE 
   ///@brief is the Vacuum Volume of DX mAgnet pipe [TGeoVolume] 
   class PVAE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAE() : AgBlock("PVAE","is the Vacuum Volume of DX mAgnet pipe [TGeoVolume]"){ 
      }; 
      ~PVAE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PUPF -- 
   ///@defgroup PUPF_doc 
   ///@class PUPF 
   ///@brief is the Outer PIPe through the DX mAgnet Volume [TGeoVolume] 
   class PUPF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PUPF() : AgBlock("PUPF","is the Outer PIPe through the DX mAgnet Volume [TGeoVolume]"){ 
      }; 
      ~PUPF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- DXMG -- 
   ///@defgroup DXMG_doc 
   ///@class DXMG 
   ///@brief is the return yoke for the DX mAgnet [TGeoVolume] 
   class DXMG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DXMG() : AgBlock("DXMG","is the return yoke for the DX mAgnet [TGeoVolume]"){ 
      }; 
      ~DXMG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- DCON -- 
   ///@defgroup DCON_doc 
   ///@class DCON 
   ///@brief is the beam pipe Bell section at the end of DX [TGeoVolume] 
   class DCON : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DCON() : AgBlock("DCON","is the beam pipe Bell section at the end of DX [TGeoVolume]"){ 
      }; 
      ~DCON(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- DVAC -- 
   ///@defgroup DVAC_doc 
   ///@class DVAC 
   ///@brief is its cavity [TGeoVolume] 
   class DVAC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DVAC() : AgBlock("DVAC","is its cavity [TGeoVolume]"){ 
      }; 
      ~DVAC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PUPG -- 
   ///@defgroup PUPG_doc 
   ///@class PUPG 
   ///@brief is the Beam PIPe After the DX magnet Volume [TGeoVolume] 
   class PUPG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PUPG() : AgBlock("PUPG","is the Beam PIPe After the DX magnet Volume [TGeoVolume]"){ 
      }; 
      ~PUPG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAG -- 
   ///@defgroup PVAG_doc 
   ///@class PVAG 
   ///@brief is the Vacuum Volume of the pipe after the DX magnet [TGeoVolume] 
   class PVAG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAG() : AgBlock("PVAG","is the Vacuum Volume of the pipe after the DX magnet [TGeoVolume]"){ 
      }; 
      ~PVAG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class UpstGeo 
   /// \brief  is the geometry  of the UPSTREAM AreA.  
   class UpstGeo : public AgModule 
   { 
      public: 
      UpstGeo(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~UpstGeo(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace UpstGeo 
#endif // __UpstGeo__ 
