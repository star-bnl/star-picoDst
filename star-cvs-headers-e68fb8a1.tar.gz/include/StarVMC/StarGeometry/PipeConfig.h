#ifndef __PIPE_CONFIG__ 
#define __PIPE_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PipeGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PipeGeo00.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PipeGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PipeGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PipeGeo3.h" 
namespace PIPE { //
struct PIPEof {
  static const char *name()    { return "PIPEof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "PipeGeo"; }
  static       bool  list();
  typedef PIPEGEO::PipeGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIPE { //
struct PIPEon {
  static const char *name()    { return "PIPEon"; }
  static const char *comment() { return "Default pipe configuration"; }
  static const char *module()  { return "PipeGeo"; }
  static       bool  list();
  typedef PIPEGEO::PipeGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIPE { //
struct PIPE00 {
  static const char *name()    { return "PIPE00"; }
  static const char *comment() { return "Simplest beam pipe"; }
  static const char *module()  { return "PipeGeo00"; }
  static       bool  list();
  typedef PIPEGEO00::PipeGeo00 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIPE { //
struct PIPE12 {
  static const char *name()    { return "PIPE12"; }
  static const char *comment() { return "Default pipe"; }
  static const char *module()  { return "PipeGeo"; }
  static       bool  list();
  typedef PIPEGEO::PipeGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIPE { //
struct PIPE04 {
  static const char *name()    { return "PIPE04"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "PipeGeo"; }
  static       bool  list();
  typedef PIPEGEO::PipeGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIPE { //
struct PIPE14 {
  static const char *name()    { return "PIPE14"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "PipeGeo"; }
  static       bool  list();
  typedef PIPEGEO::PipeGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIPE { //
struct PIPE06 {
  static const char *name()    { return "PIPE06"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "PipeGeo"; }
  static       bool  list();
  typedef PIPEGEO::PipeGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIPE { //
struct PIPEv1 {
  static const char *name()    { return "PIPEv1"; }
  static const char *comment() { return "New beampipe"; }
  static const char *module()  { return "PipeGeo1"; }
  static       bool  list();
  typedef PIPEGEO1::PipeGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIPE { //
struct PIPEv2 {
  static const char *name()    { return "PIPEv2"; }
  static const char *comment() { return "New beampipe"; }
  static const char *module()  { return "PipeGeo2"; }
  static       bool  list();
  typedef PIPEGEO2::PipeGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PIPE { //
struct PIPEv3 {
  static const char *name()    { return "PIPEv3"; }
  static const char *comment() { return "HFT beampipe"; }
  static const char *module()  { return "PipeGeo3"; }
  static       bool  list();
  typedef PIPEGEO3::PipeGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
