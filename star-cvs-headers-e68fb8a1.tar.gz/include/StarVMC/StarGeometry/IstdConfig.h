#ifndef __ISTD_CONFIG__ 
#define __ISTD_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/IstdGeo0.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/IstdGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/IstdGeo1a.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/IstdGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/IstdGeo2a.h" 
namespace ISTD { //
struct ISTDof {
  static const char *name()    { return "ISTDof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "IstdGeo0"; }
  static       bool  list();
  typedef ISTDGEO0::IstdGeo0 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ISTD { //
struct ISTD01 {
  static const char *name()    { return "ISTD01"; }
  static const char *comment() { return "Intermediate Silicon Detector"; }
  static const char *module()  { return "IstdGeo0"; }
  static       bool  list();
  typedef ISTDGEO0::IstdGeo0 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ISTD { //
struct ISTD02 {
  static const char *name()    { return "ISTD02"; }
  static const char *comment() { return "Intermediate Silicon Detector"; }
  static const char *module()  { return "IstdGeo1a"; }
  static       bool  list();
  typedef ISTDGEO1A::IstdGeo1a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ISTD { //
struct ISTD02a {
  static const char *name()    { return "ISTD02a"; }
  static const char *comment() { return "Intermediate Silicon Detector"; }
  static const char *module()  { return "IstdGeo1a"; }
  static       bool  list();
  typedef ISTDGEO1A::IstdGeo1a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ISTD { //
struct ISTD03 {
  static const char *name()    { return "ISTD03"; }
  static const char *comment() { return "Intermediate Silicon Detector"; }
  static const char *module()  { return "IstdGeo2a"; }
  static       bool  list();
  typedef ISTDGEO2A::IstdGeo2a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ISTD { //
struct ISTD03a {
  static const char *name()    { return "ISTD03a"; }
  static const char *comment() { return "Intermediate Silicon Detector"; }
  static const char *module()  { return "IstdGeo2a"; }
  static       bool  list();
  typedef ISTDGEO2A::IstdGeo2a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
