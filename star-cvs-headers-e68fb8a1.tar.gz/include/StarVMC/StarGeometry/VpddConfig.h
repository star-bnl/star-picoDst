#ifndef __VPDD_CONFIG__ 
#define __VPDD_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/VpddGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/VpddGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/VpddGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/VpddGeo3.h" 
namespace VPDD { //
struct VPDDof {
  static const char *name()    { return "VPDDof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "VpddGeo"; }
  static       bool  list();
  typedef VPDDGEO::VpddGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace VPDD { //
struct VPDDon {
  static const char *name()    { return "VPDDon"; }
  static const char *comment() { return "Default configuration for the Beam Beam counter"; }
  static const char *module()  { return "VpddGeo"; }
  static       bool  list();
  typedef VPDDGEO::VpddGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace VPDD { //
struct VPDD02 {
  static const char *name()    { return "VPDD02"; }
  static const char *comment() { return "Default configuration for the Beam Beam counter"; }
  static const char *module()  { return "VpddGeo"; }
  static       bool  list();
  typedef VPDDGEO::VpddGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace VPDD { //
struct VPDD03 {
  static const char *name()    { return "VPDD03"; }
  static const char *comment() { return "Default configuration for the Beam Beam counter"; }
  static const char *module()  { return "VpddGeo"; }
  static       bool  list();
  typedef VPDDGEO::VpddGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace VPDD { //
struct VPDD04 {
  static const char *name()    { return "VPDD04"; }
  static const char *comment() { return "Default configuration for the Beam Beam counter"; }
  static const char *module()  { return "VpddGeo"; }
  static       bool  list();
  typedef VPDDGEO::VpddGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace VPDD { //
struct VPDD07 {
  static const char *name()    { return "VPDD07"; }
  static const char *comment() { return "Default configuration for the Beam Beam counter"; }
  static const char *module()  { return "VpddGeo2"; }
  static       bool  list();
  typedef VPDDGEO2::VpddGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace VPDD { //
struct VPDD08 {
  static const char *name()    { return "VPDD08"; }
  static const char *comment() { return "Default configuration for the Beam Beam counter"; }
  static const char *module()  { return "VpddGeo3"; }
  static       bool  list();
  typedef VPDDGEO3::VpddGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
