#ifndef __SupoGeo1__ 
#define __SupoGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace SUPOGEO1 // $NMSPC 
{ 
   struct smai_t {
float version;
float rinner;
float router;
float zmin;
float zmax;
float phimid;
float fixhei;
float fixwid;
float fixthk;
int _index;
};
 
   struct _smai_docum_ {
string version;
string rinner;
string router;
string zmin;
string zmax;
string phimid;
string fixhei;
string fixwid;
string fixthk;
string _index;
};
 
    struct _smai_types_ {
  typedef float version;
  typedef float rinner;
  typedef float router;
  typedef float zmin;
  typedef float zmax;
  typedef float phimid;
  typedef float fixhei;
  typedef float fixwid;
  typedef float fixthk;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct smai_info {
typedef smai_t Type;
static const char *name(){ return "smai_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct smai_t, version ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rinner {
  static const char *name() { return  "rinner"; }
  static int Offset(){ return offsetof( struct smai_t, rinner ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct router {
  static const char *name() { return  "router"; }
  static int Offset(){ return offsetof( struct smai_t, router ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zmin {
  static const char *name() { return  "zmin"; }
  static int Offset(){ return offsetof( struct smai_t, zmin ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zmax {
  static const char *name() { return  "zmax"; }
  static int Offset(){ return offsetof( struct smai_t, zmax ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phimid {
  static const char *name() { return  "phimid"; }
  static int Offset(){ return offsetof( struct smai_t, phimid ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fixhei {
  static const char *name() { return  "fixhei"; }
  static int Offset(){ return offsetof( struct smai_t, fixhei ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fixwid {
  static const char *name() { return  "fixwid"; }
  static int Offset(){ return offsetof( struct smai_t, fixwid ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fixthk {
  static const char *name() { return  "fixthk"; }
  static int Offset(){ return offsetof( struct smai_t, fixthk ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct smai_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)smai_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct sslo_t {
float version;
float phimin;
float phimax;
float raillen;
float railwin;
float railwout;
float railhei;
float wallwid;
float wallhei;
float headthk;
float headhei;
float xwalthk;
float xwal1pos;
float xwal2pos;
float endthk;
float endhei;
float boltpos;
float boltoff;
float boltrad;
int _index;
};
 
   struct _sslo_docum_ {
string version;
string phimin;
string phimax;
string raillen;
string railwin;
string railwout;
string railhei;
string wallwid;
string wallhei;
string headthk;
string headhei;
string xwalthk;
string xwal1pos;
string xwal2pos;
string endthk;
string endhei;
string boltpos;
string boltoff;
string boltrad;
string _index;
};
 
    struct _sslo_types_ {
  typedef float version;
  typedef float phimin;
  typedef float phimax;
  typedef float raillen;
  typedef float railwin;
  typedef float railwout;
  typedef float railhei;
  typedef float wallwid;
  typedef float wallhei;
  typedef float headthk;
  typedef float headhei;
  typedef float xwalthk;
  typedef float xwal1pos;
  typedef float xwal2pos;
  typedef float endthk;
  typedef float endhei;
  typedef float boltpos;
  typedef float boltoff;
  typedef float boltrad;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct sslo_info {
typedef sslo_t Type;
static const char *name(){ return "sslo_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct sslo_t, version ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phimin {
  static const char *name() { return  "phimin"; }
  static int Offset(){ return offsetof( struct sslo_t, phimin ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phimax {
  static const char *name() { return  "phimax"; }
  static int Offset(){ return offsetof( struct sslo_t, phimax ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct raillen {
  static const char *name() { return  "raillen"; }
  static int Offset(){ return offsetof( struct sslo_t, raillen ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct railwin {
  static const char *name() { return  "railwin"; }
  static int Offset(){ return offsetof( struct sslo_t, railwin ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct railwout {
  static const char *name() { return  "railwout"; }
  static int Offset(){ return offsetof( struct sslo_t, railwout ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct railhei {
  static const char *name() { return  "railhei"; }
  static int Offset(){ return offsetof( struct sslo_t, railhei ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wallwid {
  static const char *name() { return  "wallwid"; }
  static int Offset(){ return offsetof( struct sslo_t, wallwid ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wallhei {
  static const char *name() { return  "wallhei"; }
  static int Offset(){ return offsetof( struct sslo_t, wallhei ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct headthk {
  static const char *name() { return  "headthk"; }
  static int Offset(){ return offsetof( struct sslo_t, headthk ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct headhei {
  static const char *name() { return  "headhei"; }
  static int Offset(){ return offsetof( struct sslo_t, headhei ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xwalthk {
  static const char *name() { return  "xwalthk"; }
  static int Offset(){ return offsetof( struct sslo_t, xwalthk ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xwal1pos {
  static const char *name() { return  "xwal1pos"; }
  static int Offset(){ return offsetof( struct sslo_t, xwal1pos ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xwal2pos {
  static const char *name() { return  "xwal2pos"; }
  static int Offset(){ return offsetof( struct sslo_t, xwal2pos ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct endthk {
  static const char *name() { return  "endthk"; }
  static int Offset(){ return offsetof( struct sslo_t, endthk ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct endhei {
  static const char *name() { return  "endhei"; }
  static int Offset(){ return offsetof( struct sslo_t, endhei ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct boltpos {
  static const char *name() { return  "boltpos"; }
  static int Offset(){ return offsetof( struct sslo_t, boltpos ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct boltoff {
  static const char *name() { return  "boltoff"; }
  static int Offset(){ return offsetof( struct sslo_t, boltoff ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct boltrad {
  static const char *name() { return  "boltrad"; }
  static int Offset(){ return offsetof( struct sslo_t, boltrad ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct sslo_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)sslo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct sshi_t {
float version;
float phimin;
float phimax;
float xdist;
float ydist;
float railwid;
float railhei;
float platthk;
float plathei;
float barlen;
float baroffz;
float barhei;
float topwid;
float blochei;
float bloclen;
float boltoff;
float stabwid;
float stabthk;
float stab1z;
float stab2z;
int _index;
};
 
   struct _sshi_docum_ {
string version;
string phimin;
string phimax;
string xdist;
string ydist;
string railwid;
string railhei;
string platthk;
string plathei;
string barlen;
string baroffz;
string barhei;
string topwid;
string blochei;
string bloclen;
string boltoff;
string stabwid;
string stabthk;
string stab1z;
string stab2z;
string _index;
};
 
    struct _sshi_types_ {
  typedef float version;
  typedef float phimin;
  typedef float phimax;
  typedef float xdist;
  typedef float ydist;
  typedef float railwid;
  typedef float railhei;
  typedef float platthk;
  typedef float plathei;
  typedef float barlen;
  typedef float baroffz;
  typedef float barhei;
  typedef float topwid;
  typedef float blochei;
  typedef float bloclen;
  typedef float boltoff;
  typedef float stabwid;
  typedef float stabthk;
  typedef float stab1z;
  typedef float stab2z;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct sshi_info {
typedef sshi_t Type;
static const char *name(){ return "sshi_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct sshi_t, version ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phimin {
  static const char *name() { return  "phimin"; }
  static int Offset(){ return offsetof( struct sshi_t, phimin ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phimax {
  static const char *name() { return  "phimax"; }
  static int Offset(){ return offsetof( struct sshi_t, phimax ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xdist {
  static const char *name() { return  "xdist"; }
  static int Offset(){ return offsetof( struct sshi_t, xdist ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ydist {
  static const char *name() { return  "ydist"; }
  static int Offset(){ return offsetof( struct sshi_t, ydist ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct railwid {
  static const char *name() { return  "railwid"; }
  static int Offset(){ return offsetof( struct sshi_t, railwid ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct railhei {
  static const char *name() { return  "railhei"; }
  static int Offset(){ return offsetof( struct sshi_t, railhei ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct platthk {
  static const char *name() { return  "platthk"; }
  static int Offset(){ return offsetof( struct sshi_t, platthk ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct plathei {
  static const char *name() { return  "plathei"; }
  static int Offset(){ return offsetof( struct sshi_t, plathei ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct barlen {
  static const char *name() { return  "barlen"; }
  static int Offset(){ return offsetof( struct sshi_t, barlen ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct baroffz {
  static const char *name() { return  "baroffz"; }
  static int Offset(){ return offsetof( struct sshi_t, baroffz ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct barhei {
  static const char *name() { return  "barhei"; }
  static int Offset(){ return offsetof( struct sshi_t, barhei ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct topwid {
  static const char *name() { return  "topwid"; }
  static int Offset(){ return offsetof( struct sshi_t, topwid ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct blochei {
  static const char *name() { return  "blochei"; }
  static int Offset(){ return offsetof( struct sshi_t, blochei ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bloclen {
  static const char *name() { return  "bloclen"; }
  static int Offset(){ return offsetof( struct sshi_t, bloclen ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct boltoff {
  static const char *name() { return  "boltoff"; }
  static int Offset(){ return offsetof( struct sshi_t, boltoff ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stabwid {
  static const char *name() { return  "stabwid"; }
  static int Offset(){ return offsetof( struct sshi_t, stabwid ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stabthk {
  static const char *name() { return  "stabthk"; }
  static int Offset(){ return offsetof( struct sshi_t, stabthk ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stab1z {
  static const char *name() { return  "stab1z"; }
  static int Offset(){ return offsetof( struct sshi_t, stab1z ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stab2z {
  static const char *name() { return  "stab2z"; }
  static int Offset(){ return offsetof( struct sshi_t, stab2z ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct sshi_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)sshi_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- SUPO -- 
   ///@defgroup SUPO_doc 
   ///@class SUPO 
   ///@brief is the FTPC support mother volume [TGeoVolume] 
   class SUPO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SUPO() : AgBlock("SUPO","is the FTPC support mother volume [TGeoVolume]"){ 
      }; 
      ~SUPO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SUPL -- 
   ///@defgroup SUPL_doc 
   ///@class SUPL 
   ///@brief is the lower FTPC support mother volume [TGeoVolume] 
   class SUPL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SUPL() : AgBlock("SUPL","is the lower FTPC support mother volume [TGeoVolume]"){ 
      }; 
      ~SUPL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SLRL -- 
   ///@defgroup SLRL_doc 
   ///@class SLRL 
   ///@brief is the lower FTPC support rail [TGeoVolume] 
   class SLRL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SLRL() : AgBlock("SLRL","is the lower FTPC support rail [TGeoVolume]"){ 
      }; 
      ~SLRL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SLWL -- 
   ///@defgroup SLWL_doc 
   ///@class SLWL 
   ///@brief is the lower FTPC support side wall [TGeoVolume] 
   class SLWL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SLWL() : AgBlock("SLWL","is the lower FTPC support side wall [TGeoVolume]"){ 
      }; 
      ~SLWL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SLHD -- 
   ///@defgroup SLHD_doc 
   ///@class SLHD 
   ///@brief is the lower FTPC support head plate (mounted to TPC) [TGeoVolume] 
   class SLHD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SLHD() : AgBlock("SLHD","is the lower FTPC support head plate (mounted to TPC) [TGeoVolume]"){ 
      }; 
      ~SLHD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SLXW -- 
   ///@defgroup SLXW_doc 
   ///@class SLXW 
   ///@brief is the lower FTPC support cross wall [TGeoVolume] 
   class SLXW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SLXW() : AgBlock("SLXW","is the lower FTPC support cross wall [TGeoVolume]"){ 
      }; 
      ~SLXW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SLEN -- 
   ///@defgroup SLEN_doc 
   ///@class SLEN 
   ///@brief is the lower FTPC support end block [TGeoVolume] 
   class SLEN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SLEN() : AgBlock("SLEN","is the lower FTPC support end block [TGeoVolume]"){ 
      }; 
      ~SLEN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SLFX -- 
   ///@defgroup SLFX_doc 
   ///@class SLFX 
   ///@brief is the lower FTPC support fixture plate [TGeoVolume] 
   class SLFX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SLFX() : AgBlock("SLFX","is the lower FTPC support fixture plate [TGeoVolume]"){ 
      }; 
      ~SLFX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SLBL -- 
   ///@defgroup SLBL_doc 
   ///@class SLBL 
   ///@brief is the lower FTPC support bolt [TGeoVolume] 
   class SLBL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SLBL() : AgBlock("SLBL","is the lower FTPC support bolt [TGeoVolume]"){ 
      }; 
      ~SLBL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SUPH -- 
   ///@defgroup SUPH_doc 
   ///@class SUPH 
   ///@brief is the upper FTPC support mother volume [TGeoVolume] 
   class SUPH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SUPH() : AgBlock("SUPH","is the upper FTPC support mother volume [TGeoVolume]"){ 
      }; 
      ~SUPH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SHRL -- 
   ///@defgroup SHRL_doc 
   ///@class SHRL 
   ///@brief is the upper FTPC support rail [TGeoVolume] 
   class SHRL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SHRL() : AgBlock("SHRL","is the upper FTPC support rail [TGeoVolume]"){ 
      }; 
      ~SHRL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SHPT -- 
   ///@defgroup SHPT_doc 
   ///@class SHPT 
   ///@brief is the upper FTPC support main plate [TGeoVolume] 
   class SHPT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SHPT() : AgBlock("SHPT","is the upper FTPC support main plate [TGeoVolume]"){ 
      }; 
      ~SHPT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SHBR -- 
   ///@defgroup SHBR_doc 
   ///@class SHBR 
   ///@brief is the upper FTPC support top bar [TGeoVolume] 
   class SHBR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SHBR() : AgBlock("SHBR","is the upper FTPC support top bar [TGeoVolume]"){ 
      }; 
      ~SHBR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SHBK -- 
   ///@defgroup SHBK_doc 
   ///@class SHBK 
   ///@brief is the upper FTPC support top block [TGeoVolume] 
   class SHBK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SHBK() : AgBlock("SHBK","is the upper FTPC support top block [TGeoVolume]"){ 
      }; 
      ~SHBK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SHFX -- 
   ///@defgroup SHFX_doc 
   ///@class SHFX 
   ///@brief is the upper FTPC support fixture plate [TGeoVolume] 
   class SHFX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SHFX() : AgBlock("SHFX","is the upper FTPC support fixture plate [TGeoVolume]"){ 
      }; 
      ~SHFX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SHST -- 
   ///@defgroup SHST_doc 
   ///@class SHST 
   ///@brief are the upper FTPC support stabilizers [TGeoVolume] 
   class SHST : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SHST() : AgBlock("SHST","are the upper FTPC support stabilizers [TGeoVolume]"){ 
      }; 
      ~SHST(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class SupoGeo1 
   /// \brief   is the geometry of the Forward TPC supports in STAR  
   class SupoGeo1 : public AgModule 
   { 
      public: 
      SupoGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~SupoGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace SupoGeo1 
#endif // __SupoGeo1__ 
