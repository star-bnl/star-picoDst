#ifndef __PixlGeo4__ 
#define __PixlGeo4__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace PIXLGEO4 // $NMSPC 
{ 
   struct pixl_t {
float version;
int sector;
float phinum[10];
int _index;
};
 
   struct _pixl_docum_ {
string version;
string sector;
string phinum;
string _index;
};
 
    struct _pixl_types_ {
  typedef float version;
  typedef int sector;
  typedef float phinum[10];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pixl_info {
typedef pixl_t Type;
static const char *name(){ return "pixl_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct pixl_t, version ); }
  static void* address(){ 
         long long iadd = (long long)pixl_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sector {
  static const char *name() { return  "sector"; }
  static int Offset(){ return offsetof( struct pixl_t, sector ); }
  static void* address(){ 
         long long iadd = (long long)pixl_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct phinum {
  static const char *name() { return  "phinum"; }
  static int Offset(){ return offsetof( struct pixl_t, phinum ); }
  static void* address(){ 
         long long iadd = (long long)pixl_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[10];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pixl_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pixl_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct paro_t {
int version;
float dx;
float dy;
float dz;
float mult;
int sec[10];
int _index;
};
 
   struct _paro_docum_ {
string version;
string dx;
string dy;
string dz;
string mult;
string sec;
string _index;
};
 
    struct _paro_types_ {
  typedef int version;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef float mult;
  typedef int sec[10];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct paro_info {
typedef paro_t Type;
static const char *name(){ return "paro_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct paro_t, version ); }
  static void* address(){ 
         long long iadd = (long long)paro_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct paro_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)paro_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct paro_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)paro_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct paro_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)paro_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mult {
  static const char *name() { return  "mult"; }
  static int Offset(){ return offsetof( struct paro_t, mult ); }
  static void* address(){ 
         long long iadd = (long long)paro_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sec {
  static const char *name() { return  "sec"; }
  static int Offset(){ return offsetof( struct paro_t, sec ); }
  static void* address(){ 
         long long iadd = (long long)paro_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type[10];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct paro_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)paro_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct para_t {
int version;
float da;
float db;
float dg;
float mult;
int sec[10];
int _index;
};
 
   struct _para_docum_ {
string version;
string da;
string db;
string dg;
string mult;
string sec;
string _index;
};
 
    struct _para_types_ {
  typedef int version;
  typedef float da;
  typedef float db;
  typedef float dg;
  typedef float mult;
  typedef int sec[10];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct para_info {
typedef para_t Type;
static const char *name(){ return "para_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct para_t, version ); }
  static void* address(){ 
         long long iadd = (long long)para_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct da {
  static const char *name() { return  "da"; }
  static int Offset(){ return offsetof( struct para_t, da ); }
  static void* address(){ 
         long long iadd = (long long)para_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct db {
  static const char *name() { return  "db"; }
  static int Offset(){ return offsetof( struct para_t, db ); }
  static void* address(){ 
         long long iadd = (long long)para_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dg {
  static const char *name() { return  "dg"; }
  static int Offset(){ return offsetof( struct para_t, dg ); }
  static void* address(){ 
         long long iadd = (long long)para_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mult {
  static const char *name() { return  "mult"; }
  static int Offset(){ return offsetof( struct para_t, mult ); }
  static void* address(){ 
         long long iadd = (long long)para_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sec {
  static const char *name() { return  "sec"; }
  static int Offset(){ return offsetof( struct para_t, sec ); }
  static void* address(){ 
         long long iadd = (long long)para_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type[10];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct para_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)para_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- PXMO -- 
   ///@defgroup PXMO_doc 
   ///@class PXMO 
   ///@brief Main volume in the AGML tutorial geometry [TGeoVolume] 
   class PXMO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXMO() : AgBlock("PXMO","Main volume in the AGML tutorial geometry [TGeoVolume]"){ 
      }; 
      ~PXMO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXLA -- 
   ///@defgroup PXLA_doc 
   ///@class PXLA 
   ///@brief pixel sector [TGeoVolume] 
   class PXLA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXLA() : AgBlock("PXLA","pixel sector [TGeoVolume]"){ 
      }; 
      ~PXLA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXRB -- 
   ///@defgroup PXRB_doc 
   ///@class PXRB 
   ///@brief sector right side [TGeoVolume] 
   class PXRB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXRB() : AgBlock("PXRB","sector right side [TGeoVolume]"){ 
      }; 
      ~PXRB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXLB -- 
   ///@defgroup PXLB_doc 
   ///@class PXLB 
   ///@brief sector left side [TGeoVolume] 
   class PXLB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXLB() : AgBlock("PXLB","sector left side [TGeoVolume]"){ 
      }; 
      ~PXLB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXIB -- 
   ///@defgroup PXIB_doc 
   ///@class PXIB 
   ///@brief sector bottom side [TGeoVolume] 
   class PXIB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXIB() : AgBlock("PXIB","sector bottom side [TGeoVolume]"){ 
      }; 
      ~PXIB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXTR -- 
   ///@defgroup PXTR_doc 
   ///@class PXTR 
   ///@brief part of sector right [TGeoVolume] 
   class PXTR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXTR() : AgBlock("PXTR","part of sector right [TGeoVolume]"){ 
      }; 
      ~PXTR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXTM -- 
   ///@defgroup PXTM_doc 
   ///@class PXTM 
   ///@brief part of sector middle [TGeoVolume] 
   class PXTM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXTM() : AgBlock("PXTM","part of sector middle [TGeoVolume]"){ 
      }; 
      ~PXTM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXTL -- 
   ///@defgroup PXTL_doc 
   ///@class PXTL 
   ///@brief part of sector right [TGeoVolume] 
   class PXTL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXTL() : AgBlock("PXTL","part of sector right [TGeoVolume]"){ 
      }; 
      ~PXTL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXTJ -- 
   ///@defgroup PXTJ_doc 
   ///@class PXTJ 
   ///@brief part joining 2 parts of top sector [TGeoVolume] 
   class PXTJ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXTJ() : AgBlock("PXTJ","part joining 2 parts of top sector [TGeoVolume]"){ 
      }; 
      ~PXTJ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXCA -- 
   ///@defgroup PXCA_doc 
   ///@class PXCA 
   ///@brief arc bottom right [TGeoVolume] 
   class PXCA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXCA() : AgBlock("PXCA","arc bottom right [TGeoVolume]"){ 
      }; 
      ~PXCA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXCC -- 
   ///@defgroup PXCC_doc 
   ///@class PXCC 
   ///@brief arc top right [TGeoVolume] 
   class PXCC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXCC() : AgBlock("PXCC","arc top right [TGeoVolume]"){ 
      }; 
      ~PXCC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXCD -- 
   ///@defgroup PXCD_doc 
   ///@class PXCD 
   ///@brief arc top 23 [TGeoVolume] 
   class PXCD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXCD() : AgBlock("PXCD","arc top 23 [TGeoVolume]"){ 
      }; 
      ~PXCD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXCE -- 
   ///@defgroup PXCE_doc 
   ///@class PXCE 
   ///@brief arc bottom 23 [TGeoVolume] 
   class PXCE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXCE() : AgBlock("PXCE","arc bottom 23 [TGeoVolume]"){ 
      }; 
      ~PXCE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXCF -- 
   ///@defgroup PXCF_doc 
   ///@class PXCF 
   ///@brief arc top 12 [TGeoVolume] 
   class PXCF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXCF() : AgBlock("PXCF","arc top 12 [TGeoVolume]"){ 
      }; 
      ~PXCF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXCG -- 
   ///@defgroup PXCG_doc 
   ///@class PXCG 
   ///@brief arc bottom 12 [TGeoVolume] 
   class PXCG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXCG() : AgBlock("PXCG","arc bottom 12 [TGeoVolume]"){ 
      }; 
      ~PXCG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXCH -- 
   ///@defgroup PXCH_doc 
   ///@class PXCH 
   ///@brief arc top left [TGeoVolume] 
   class PXCH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXCH() : AgBlock("PXCH","arc top left [TGeoVolume]"){ 
      }; 
      ~PXCH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PXCB -- 
   ///@defgroup PXCB_doc 
   ///@class PXCB 
   ///@brief arc bottom left [TGeoVolume] 
   class PXCB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PXCB() : AgBlock("PXCB","arc bottom left [TGeoVolume]"){ 
      }; 
      ~PXCB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LADR -- 
   ///@defgroup LADR_doc 
   ///@class LADR 
   ///@brief first ladder prototype [TGeoVolume] 
   class LADR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LADR() : AgBlock("LADR","first ladder prototype [TGeoVolume]"){ 
      }; 
      ~LADR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SIFL -- 
   ///@defgroup SIFL_doc 
   ///@class SIFL 
   ///@brief passive silicon layer [TGeoVolume] 
   class SIFL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SIFL() : AgBlock("SIFL","passive silicon layer [TGeoVolume]"){ 
      }; 
      ~SIFL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SIFR -- 
   ///@defgroup SIFR_doc 
   ///@class SIFR 
   ///@brief passive silicon layer [TGeoVolume] 
   class SIFR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SIFR() : AgBlock("SIFR","passive silicon layer [TGeoVolume]"){ 
      }; 
      ~SIFR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ALCA -- 
   ///@defgroup ALCA_doc 
   ///@class ALCA 
   ///@brief aluminium cable [TGeoVolume] 
   class ALCA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ALCA() : AgBlock("ALCA","aluminium cable [TGeoVolume]"){ 
      }; 
      ~ALCA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- GLUA -- 
   ///@defgroup GLUA_doc 
   ///@class GLUA 
   ///@brief glue Layer A [TGeoVolume] 
   class GLUA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      GLUA() : AgBlock("GLUA","glue Layer A [TGeoVolume]"){ 
      }; 
      ~GLUA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- GLUB -- 
   ///@defgroup GLUB_doc 
   ///@class GLUB 
   ///@brief glue Layer B [TGeoVolume] 
   class GLUB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      GLUB() : AgBlock("GLUB","glue Layer B [TGeoVolume]"){ 
      }; 
      ~GLUB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CFBK -- 
   ///@defgroup CFBK_doc 
   ///@class CFBK 
   ///@brief Carbon Fiber Backing [TGeoVolume] 
   class CFBK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CFBK() : AgBlock("CFBK","Carbon Fiber Backing [TGeoVolume]"){ 
      }; 
      ~CFBK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- GLUC -- 
   ///@defgroup GLUC_doc 
   ///@class GLUC 
   ///@brief glue Layer C [TGeoVolume] 
   class GLUC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      GLUC() : AgBlock("GLUC","glue Layer C [TGeoVolume]"){ 
      }; 
      ~GLUC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PLAC -- 
   ///@defgroup PLAC_doc 
   ///@class PLAC 
   ///@brief active silicon top sector [TGeoVolume] 
   class PLAC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PLAC() : AgBlock("PLAC","active silicon top sector [TGeoVolume]"){ 
      }; 
      ~PLAC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class PixlGeo4 
   /// \brief Pixel Detector Geometry   
   class PixlGeo4 : public AgModule 
   { 
      public: 
      PixlGeo4(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~PixlGeo4(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace PixlGeo4 
#endif // __PixlGeo4__ 
