#ifndef __BtofGeo1__ 
#define __BtofGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace BTOFGEO1 // $NMSPC 
{ 
   struct btog_t {
float version;
float rmin;
float rmax;
float dz;
float choice;
float posit1;
float posit2;
int _index;
};
 
   struct _btog_docum_ {
string version;
string rmin;
string rmax;
string dz;
string choice;
string posit1;
string posit2;
string _index;
};
 
    struct _btog_types_ {
  typedef float version;
  typedef float rmin;
  typedef float rmax;
  typedef float dz;
  typedef float choice;
  typedef float posit1;
  typedef float posit2;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct btog_info {
typedef btog_t Type;
static const char *name(){ return "btog_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct btog_t, version ); }
  static void* address(){ 
         long long iadd = (long long)btog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct btog_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)btog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct btog_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)btog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct btog_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)btog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct choice {
  static const char *name() { return  "choice"; }
  static int Offset(){ return offsetof( struct btog_t, choice ); }
  static void* address(){ 
         long long iadd = (long long)btog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct posit1 {
  static const char *name() { return  "posit1"; }
  static int Offset(){ return offsetof( struct btog_t, posit1 ); }
  static void* address(){ 
         long long iadd = (long long)btog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct posit2 {
  static const char *name() { return  "posit2"; }
  static int Offset(){ return offsetof( struct btog_t, posit2 ); }
  static void* address(){ 
         long long iadd = (long long)btog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct btog_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)btog_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct tray_t {
float height;
float width;
float length;
float wallthk;
float supfullh;
float supfullw;
float suplen;
float supbaset;
float supbasew;
float suparmt;
float cooloutr;
float coolinnr;
float stript;
float footinse;
float footthk;
float foot1len;
float foot2thk;
float foot3len;
int _index;
};
 
   struct _tray_docum_ {
string height;
string width;
string length;
string wallthk;
string supfullh;
string supfullw;
string suplen;
string supbaset;
string supbasew;
string suparmt;
string cooloutr;
string coolinnr;
string stript;
string footinse;
string footthk;
string foot1len;
string foot2thk;
string foot3len;
string _index;
};
 
    struct _tray_types_ {
  typedef float height;
  typedef float width;
  typedef float length;
  typedef float wallthk;
  typedef float supfullh;
  typedef float supfullw;
  typedef float suplen;
  typedef float supbaset;
  typedef float supbasew;
  typedef float suparmt;
  typedef float cooloutr;
  typedef float coolinnr;
  typedef float stript;
  typedef float footinse;
  typedef float footthk;
  typedef float foot1len;
  typedef float foot2thk;
  typedef float foot3len;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct tray_info {
typedef tray_t Type;
static const char *name(){ return "tray_t"; }
struct height {
  static const char *name() { return  "height"; }
  static int Offset(){ return offsetof( struct tray_t, height ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct width {
  static const char *name() { return  "width"; }
  static int Offset(){ return offsetof( struct tray_t, width ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct length {
  static const char *name() { return  "length"; }
  static int Offset(){ return offsetof( struct tray_t, length ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wallthk {
  static const char *name() { return  "wallthk"; }
  static int Offset(){ return offsetof( struct tray_t, wallthk ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct supfullh {
  static const char *name() { return  "supfullh"; }
  static int Offset(){ return offsetof( struct tray_t, supfullh ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct supfullw {
  static const char *name() { return  "supfullw"; }
  static int Offset(){ return offsetof( struct tray_t, supfullw ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct suplen {
  static const char *name() { return  "suplen"; }
  static int Offset(){ return offsetof( struct tray_t, suplen ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct supbaset {
  static const char *name() { return  "supbaset"; }
  static int Offset(){ return offsetof( struct tray_t, supbaset ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct supbasew {
  static const char *name() { return  "supbasew"; }
  static int Offset(){ return offsetof( struct tray_t, supbasew ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct suparmt {
  static const char *name() { return  "suparmt"; }
  static int Offset(){ return offsetof( struct tray_t, suparmt ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cooloutr {
  static const char *name() { return  "cooloutr"; }
  static int Offset(){ return offsetof( struct tray_t, cooloutr ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct coolinnr {
  static const char *name() { return  "coolinnr"; }
  static int Offset(){ return offsetof( struct tray_t, coolinnr ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stript {
  static const char *name() { return  "stript"; }
  static int Offset(){ return offsetof( struct tray_t, stript ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct footinse {
  static const char *name() { return  "footinse"; }
  static int Offset(){ return offsetof( struct tray_t, footinse ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct footthk {
  static const char *name() { return  "footthk"; }
  static int Offset(){ return offsetof( struct tray_t, footthk ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct foot1len {
  static const char *name() { return  "foot1len"; }
  static int Offset(){ return offsetof( struct tray_t, foot1len ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct foot2thk {
  static const char *name() { return  "foot2thk"; }
  static int Offset(){ return offsetof( struct tray_t, foot2thk ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct foot3len {
  static const char *name() { return  "foot3len"; }
  static int Offset(){ return offsetof( struct tray_t, foot3len ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct tray_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)tray_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct ctbb_t {
float slab1len;
float slab2len;
float slab1x;
float slab2x;
float slabthck;
float slabwid;
float convlen;
float convwidm;
float convthck;
float pmtlen;
float pmtmaxr;
float pmtminr;
float baselen;
float basemaxr;
float baseminr;
float electhck;
float wrap;
float shim;
int _index;
};
 
   struct _ctbb_docum_ {
string slab1len;
string slab2len;
string slab1x;
string slab2x;
string slabthck;
string slabwid;
string convlen;
string convwidm;
string convthck;
string pmtlen;
string pmtmaxr;
string pmtminr;
string baselen;
string basemaxr;
string baseminr;
string electhck;
string wrap;
string shim;
string _index;
};
 
    struct _ctbb_types_ {
  typedef float slab1len;
  typedef float slab2len;
  typedef float slab1x;
  typedef float slab2x;
  typedef float slabthck;
  typedef float slabwid;
  typedef float convlen;
  typedef float convwidm;
  typedef float convthck;
  typedef float pmtlen;
  typedef float pmtmaxr;
  typedef float pmtminr;
  typedef float baselen;
  typedef float basemaxr;
  typedef float baseminr;
  typedef float electhck;
  typedef float wrap;
  typedef float shim;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct ctbb_info {
typedef ctbb_t Type;
static const char *name(){ return "ctbb_t"; }
struct slab1len {
  static const char *name() { return  "slab1len"; }
  static int Offset(){ return offsetof( struct ctbb_t, slab1len ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slab2len {
  static const char *name() { return  "slab2len"; }
  static int Offset(){ return offsetof( struct ctbb_t, slab2len ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slab1x {
  static const char *name() { return  "slab1x"; }
  static int Offset(){ return offsetof( struct ctbb_t, slab1x ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slab2x {
  static const char *name() { return  "slab2x"; }
  static int Offset(){ return offsetof( struct ctbb_t, slab2x ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slabthck {
  static const char *name() { return  "slabthck"; }
  static int Offset(){ return offsetof( struct ctbb_t, slabthck ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slabwid {
  static const char *name() { return  "slabwid"; }
  static int Offset(){ return offsetof( struct ctbb_t, slabwid ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct convlen {
  static const char *name() { return  "convlen"; }
  static int Offset(){ return offsetof( struct ctbb_t, convlen ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct convwidm {
  static const char *name() { return  "convwidm"; }
  static int Offset(){ return offsetof( struct ctbb_t, convwidm ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct convthck {
  static const char *name() { return  "convthck"; }
  static int Offset(){ return offsetof( struct ctbb_t, convthck ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtlen {
  static const char *name() { return  "pmtlen"; }
  static int Offset(){ return offsetof( struct ctbb_t, pmtlen ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtmaxr {
  static const char *name() { return  "pmtmaxr"; }
  static int Offset(){ return offsetof( struct ctbb_t, pmtmaxr ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtminr {
  static const char *name() { return  "pmtminr"; }
  static int Offset(){ return offsetof( struct ctbb_t, pmtminr ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct baselen {
  static const char *name() { return  "baselen"; }
  static int Offset(){ return offsetof( struct ctbb_t, baselen ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct basemaxr {
  static const char *name() { return  "basemaxr"; }
  static int Offset(){ return offsetof( struct ctbb_t, basemaxr ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct baseminr {
  static const char *name() { return  "baseminr"; }
  static int Offset(){ return offsetof( struct ctbb_t, baseminr ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct electhck {
  static const char *name() { return  "electhck"; }
  static int Offset(){ return offsetof( struct ctbb_t, electhck ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wrap {
  static const char *name() { return  "wrap"; }
  static int Offset(){ return offsetof( struct ctbb_t, wrap ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct shim {
  static const char *name() { return  "shim"; }
  static int Offset(){ return offsetof( struct ctbb_t, shim ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct ctbb_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)ctbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct toff_t {
float slat1len;
float slat1z;
float slatdz;
float slatthck;
float slatwid;
float slatang;
float pmtlen;
float pmtmaxr;
float pmtminr;
float baselen;
float basemaxr;
float baseminr;
float elecx;
float elec1z;
float elecdz;
float electhck;
float elecwid;
float eleclen;
float railthck;
float railwid;
float coolinnr;
float cooloutr;
int _index;
};
 
   struct _toff_docum_ {
string slat1len;
string slat1z;
string slatdz;
string slatthck;
string slatwid;
string slatang;
string pmtlen;
string pmtmaxr;
string pmtminr;
string baselen;
string basemaxr;
string baseminr;
string elecx;
string elec1z;
string elecdz;
string electhck;
string elecwid;
string eleclen;
string railthck;
string railwid;
string coolinnr;
string cooloutr;
string _index;
};
 
    struct _toff_types_ {
  typedef float slat1len;
  typedef float slat1z;
  typedef float slatdz;
  typedef float slatthck;
  typedef float slatwid;
  typedef float slatang;
  typedef float pmtlen;
  typedef float pmtmaxr;
  typedef float pmtminr;
  typedef float baselen;
  typedef float basemaxr;
  typedef float baseminr;
  typedef float elecx;
  typedef float elec1z;
  typedef float elecdz;
  typedef float electhck;
  typedef float elecwid;
  typedef float eleclen;
  typedef float railthck;
  typedef float railwid;
  typedef float coolinnr;
  typedef float cooloutr;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct toff_info {
typedef toff_t Type;
static const char *name(){ return "toff_t"; }
struct slat1len {
  static const char *name() { return  "slat1len"; }
  static int Offset(){ return offsetof( struct toff_t, slat1len ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat1z {
  static const char *name() { return  "slat1z"; }
  static int Offset(){ return offsetof( struct toff_t, slat1z ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slatdz {
  static const char *name() { return  "slatdz"; }
  static int Offset(){ return offsetof( struct toff_t, slatdz ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slatthck {
  static const char *name() { return  "slatthck"; }
  static int Offset(){ return offsetof( struct toff_t, slatthck ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slatwid {
  static const char *name() { return  "slatwid"; }
  static int Offset(){ return offsetof( struct toff_t, slatwid ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slatang {
  static const char *name() { return  "slatang"; }
  static int Offset(){ return offsetof( struct toff_t, slatang ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtlen {
  static const char *name() { return  "pmtlen"; }
  static int Offset(){ return offsetof( struct toff_t, pmtlen ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtmaxr {
  static const char *name() { return  "pmtmaxr"; }
  static int Offset(){ return offsetof( struct toff_t, pmtmaxr ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtminr {
  static const char *name() { return  "pmtminr"; }
  static int Offset(){ return offsetof( struct toff_t, pmtminr ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct baselen {
  static const char *name() { return  "baselen"; }
  static int Offset(){ return offsetof( struct toff_t, baselen ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct basemaxr {
  static const char *name() { return  "basemaxr"; }
  static int Offset(){ return offsetof( struct toff_t, basemaxr ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct baseminr {
  static const char *name() { return  "baseminr"; }
  static int Offset(){ return offsetof( struct toff_t, baseminr ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elecx {
  static const char *name() { return  "elecx"; }
  static int Offset(){ return offsetof( struct toff_t, elecx ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec1z {
  static const char *name() { return  "elec1z"; }
  static int Offset(){ return offsetof( struct toff_t, elec1z ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elecdz {
  static const char *name() { return  "elecdz"; }
  static int Offset(){ return offsetof( struct toff_t, elecdz ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct electhck {
  static const char *name() { return  "electhck"; }
  static int Offset(){ return offsetof( struct toff_t, electhck ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elecwid {
  static const char *name() { return  "elecwid"; }
  static int Offset(){ return offsetof( struct toff_t, elecwid ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eleclen {
  static const char *name() { return  "eleclen"; }
  static int Offset(){ return offsetof( struct toff_t, eleclen ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct railthck {
  static const char *name() { return  "railthck"; }
  static int Offset(){ return offsetof( struct toff_t, railthck ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct railwid {
  static const char *name() { return  "railwid"; }
  static int Offset(){ return offsetof( struct toff_t, railwid ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct coolinnr {
  static const char *name() { return  "coolinnr"; }
  static int Offset(){ return offsetof( struct toff_t, coolinnr ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cooloutr {
  static const char *name() { return  "cooloutr"; }
  static int Offset(){ return offsetof( struct toff_t, cooloutr ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct toff_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)toff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- BTOF -- 
   ///@defgroup BTOF_doc 
   ///@class BTOF 
   ///@brief is the whole CTF system envelope [TGeoVolume] 
   class BTOF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BTOF() : AgBlock("BTOF","is the whole CTF system envelope [TGeoVolume]"){ 
      }; 
      ~BTOF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BTOH -- 
   ///@defgroup BTOH_doc 
   ///@class BTOH 
   ///@brief is a half of trigger system (west-east) [TGeoVolume] 
   class BTOH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BTOH() : AgBlock("BTOH","is a half of trigger system (west-east) [TGeoVolume]"){ 
      }; 
      ~BTOH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BSEC -- 
   ///@defgroup BSEC_doc 
   ///@class BSEC 
   ///@brief is a sector of CTB/TOF Trigger Barrel Scintillators [TGeoVolume] 
   class BSEC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BSEC() : AgBlock("BSEC","is a sector of CTB/TOF Trigger Barrel Scintillators [TGeoVolume]"){ 
      }; 
      ~BSEC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BTRA -- 
   ///@defgroup BTRA_doc 
   ///@class BTRA 
   ///@brief is one full tray plus supporting structure for CTB/TOF [TGeoVolume] 
   class BTRA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BTRA() : AgBlock("BTRA","is one full tray plus supporting structure for CTB/TOF [TGeoVolume]"){ 
      }; 
      ~BTRA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BXTR -- 
   ///@defgroup BXTR_doc 
   ///@class BXTR 
   ///@brief is a Main TRay covering box for CTB [TGeoVolume] 
   class BXTR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BXTR() : AgBlock("BXTR","is a Main TRay covering box for CTB [TGeoVolume]"){ 
      }; 
      ~BXTR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BMTC -- 
   ///@defgroup BMTC_doc 
   ///@class BMTC 
   ///@brief is the Main Tray Cavity filled with MANY details for CTB [TGeoVolume] 
   class BMTC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BMTC() : AgBlock("BMTC","is the Main Tray Cavity filled with MANY details for CTB [TGeoVolume]"){ 
      }; 
      ~BMTC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BTTC -- 
   ///@defgroup BTTC_doc 
   ///@class BTTC 
   ///@brief is the Main Tray Cavity filled with MANY details for TOF [TGeoVolume] 
   class BTTC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BTTC() : AgBlock("BTTC","is the Main Tray Cavity filled with MANY details for TOF [TGeoVolume]"){ 
      }; 
      ~BTTC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BMTM -- 
   ///@defgroup BMTM_doc 
   ///@class BMTM 
   ///@brief is the Main Tray cavity divisions Mother volume for TOF [TGeoVolume] 
   class BMTM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BMTM() : AgBlock("BMTM","is the Main Tray cavity divisions Mother volume for TOF [TGeoVolume]"){ 
      }; 
      ~BMTM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BMTD -- 
   ///@defgroup BMTD_doc 
   ///@class BMTD 
   ///@brief is a phi column of TOF Scintillators [TGeoVolume] 
   class BMTD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BMTD() : AgBlock("BMTD","is a phi column of TOF Scintillators [TGeoVolume]"){ 
      }; 
      ~BMTD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BASS -- 
   ///@defgroup BASS_doc 
   ///@class BASS 
   ///@brief is a single TOF Slat Assembly (slat+PMT+base) [TGeoVolume] 
   class BASS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BASS() : AgBlock("BASS","is a single TOF Slat Assembly (slat+PMT+base) [TGeoVolume]"){ 
      }; 
      ~BASS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BXSA -- 
   ///@defgroup BXSA_doc 
   ///@class BXSA 
   ///@brief is the active trigger scintillator SLAB for ctb [TGeoVolume] 
   class BXSA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BXSA() : AgBlock("BXSA","is the active trigger scintillator SLAB for ctb [TGeoVolume]"){ 
      }; 
      ~BXSA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BCSB -- 
   ///@defgroup BCSB_doc 
   ///@class BCSB 
   ///@brief is the active trigger scintillator SLAB for tof [TGeoVolume] 
   class BCSB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BCSB() : AgBlock("BCSB","is the active trigger scintillator SLAB for tof [TGeoVolume]"){ 
      }; 
      ~BCSB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BCCV -- 
   ///@defgroup BCCV_doc 
   ///@class BCCV 
   ///@brief is a Ctb optical ConVerter [TGeoVolume] 
   class BCCV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BCCV() : AgBlock("BCCV","is a Ctb optical ConVerter [TGeoVolume]"){ 
      }; 
      ~BCCV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BCPM -- 
   ///@defgroup BCPM_doc 
   ///@class BCPM 
   ///@brief is a PhotoMultiplier Tube (same for CTB and TOF) [TGeoVolume] 
   class BCPM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BCPM() : AgBlock("BCPM","is a PhotoMultiplier Tube (same for CTB and TOF) [TGeoVolume]"){ 
      }; 
      ~BCPM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BCSK -- 
   ///@defgroup BCSK_doc 
   ///@class BCSK 
   ///@brief is a CTB Linear Base tube [TGeoVolume] 
   class BCSK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BCSK() : AgBlock("BCSK","is a CTB Linear Base tube [TGeoVolume]"){ 
      }; 
      ~BCSK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BTSK -- 
   ///@defgroup BTSK_doc 
   ///@class BTSK 
   ///@brief is the outer shell of a TOF CW Base [TGeoVolume] 
   class BTSK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BTSK() : AgBlock("BTSK","is the outer shell of a TOF CW Base [TGeoVolume]"){ 
      }; 
      ~BTSK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BZEL -- 
   ///@defgroup BZEL_doc 
   ///@class BZEL 
   ///@brief is a Ctb PM electronics [TGeoVolume] 
   class BZEL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BZEL() : AgBlock("BZEL","is a Ctb PM electronics [TGeoVolume]"){ 
      }; 
      ~BZEL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BCEL -- 
   ///@defgroup BCEL_doc 
   ///@class BCEL 
   ///@brief is a G10 board in the CW Base for TOF [TGeoVolume] 
   class BCEL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BCEL() : AgBlock("BCEL","is a G10 board in the CW Base for TOF [TGeoVolume]"){ 
      }; 
      ~BCEL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BFEE -- 
   ///@defgroup BFEE_doc 
   ///@class BFEE 
   ///@brief is a G10 discriminator/CW control board for TOF [TGeoVolume] 
   class BFEE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BFEE() : AgBlock("BFEE","is a G10 discriminator/CW control board for TOF [TGeoVolume]"){ 
      }; 
      ~BFEE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BCOO -- 
   ///@defgroup BCOO_doc 
   ///@class BCOO 
   ///@brief are the cooling rails/loops [TGeoVolume] 
   class BCOO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BCOO() : AgBlock("BCOO","are the cooling rails/loops [TGeoVolume]"){ 
      }; 
      ~BCOO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BRAI -- 
   ///@defgroup BRAI_doc 
   ///@class BRAI 
   ///@brief is the Rail for the cooling loop [TGeoVolume] 
   class BRAI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BRAI() : AgBlock("BRAI","is the Rail for the cooling loop [TGeoVolume]"){ 
      }; 
      ~BRAI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BPIP -- 
   ///@defgroup BPIP_doc 
   ///@class BPIP 
   ///@brief is the Pipe for the cooling loop [TGeoVolume] 
   class BPIP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BPIP() : AgBlock("BPIP","is the Pipe for the cooling loop [TGeoVolume]"){ 
      }; 
      ~BPIP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BUND -- 
   ///@defgroup BUND_doc 
   ///@class BUND 
   ///@brief is Undercarriage support tray - same both for CTB and TOF [TGeoVolume] 
   class BUND : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BUND() : AgBlock("BUND","is Undercarriage support tray - same both for CTB and TOF [TGeoVolume]"){ 
      }; 
      ~BUND(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BTFT -- 
   ///@defgroup BTFT_doc 
   ///@class BTFT 
   ///@brief is the Foot structure ( Material Aluminium ) [TGeoVolume] 
   class BTFT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BTFT() : AgBlock("BTFT","is the Foot structure ( Material Aluminium ) [TGeoVolume]"){ 
      }; 
      ~BTFT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BARM -- 
   ///@defgroup BARM_doc 
   ///@class BARM 
   ///@brief is a TPC cooling structure arm ( Material Aluminium ) [TGeoVolume] 
   class BARM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BARM() : AgBlock("BARM","is a TPC cooling structure arm ( Material Aluminium ) [TGeoVolume]"){ 
      }; 
      ~BARM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BANG -- 
   ///@defgroup BANG_doc 
   ///@class BANG 
   ///@brief is an angled part of TPC cooling structure ( Aile ) [TGeoVolume] 
   class BANG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BANG() : AgBlock("BANG","is an angled part of TPC cooling structure ( Aile ) [TGeoVolume]"){ 
      }; 
      ~BANG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BASE -- 
   ///@defgroup BASE_doc 
   ///@class BASE 
   ///@brief is a bottom of TPC coolant structure [TGeoVolume] 
   class BASE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BASE() : AgBlock("BASE","is a bottom of TPC coolant structure [TGeoVolume]"){ 
      }; 
      ~BASE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BCOV -- 
   ///@defgroup BCOV_doc 
   ///@class BCOV 
   ///@brief is a whole TPC cooling channel [TGeoVolume] 
   class BCOV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BCOV() : AgBlock("BCOV","is a whole TPC cooling channel [TGeoVolume]"){ 
      }; 
      ~BCOV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BWAT -- 
   ///@defgroup BWAT_doc 
   ///@class BWAT 
   ///@brief is TPC cooling water [TGeoVolume] 
   class BWAT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BWAT() : AgBlock("BWAT","is TPC cooling water [TGeoVolume]"){ 
      }; 
      ~BWAT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class BtofGeo1 
   /// \brief  is the Geometry of Barrel Trigger / Time Of Flight system   
   class BtofGeo1 : public AgModule 
   { 
      public: 
      BtofGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~BtofGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace BtofGeo1 
#endif // __BtofGeo1__ 
