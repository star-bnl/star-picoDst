#ifndef __EcalGeo__ 
#define __EcalGeo__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace ECALGEO // $NMSPC 
{ 
   struct emcg_t {
float version;
int onoff;
int fillmode;
int _index;
};
 
   struct _emcg_docum_ {
string version;
string onoff;
string fillmode;
string _index;
};
 
    struct _emcg_types_ {
  typedef float version;
  typedef int onoff;
  typedef int fillmode;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct emcg_info {
typedef emcg_t Type;
static const char *name(){ return "emcg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct emcg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)emcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct onoff {
  static const char *name() { return  "onoff"; }
  static int Offset(){ return offsetof( struct emcg_t, onoff ); }
  static void* address(){ 
         long long iadd = (long long)emcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct fillmode {
  static const char *name() { return  "fillmode"; }
  static int Offset(){ return offsetof( struct emcg_t, fillmode ); }
  static void* address(){ 
         long long iadd = (long long)emcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct emcg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)emcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct emcs_t {
float type;
float zorig;
float zend;
float etamin;
float etamax;
float phimin;
float phimax;
float offset;
float nsupsec;
float nsector;
float nsection;
float nslices;
float front;
float alincell;
float frplast;
float bkplast;
float pbplate;
float lamplate;
float bckplate;
float hub;
float rmshift;
float smshift;
float gapplt;
float gapcel;
float gapsmd;
float smdcentr;
float tierod[2];
float bckfrnt;
float gaphalf;
float cover;
int _index;
};
 
   struct _emcs_docum_ {
string type;
string zorig;
string zend;
string etamin;
string etamax;
string phimin;
string phimax;
string offset;
string nsupsec;
string nsector;
string nsection;
string nslices;
string front;
string alincell;
string frplast;
string bkplast;
string pbplate;
string lamplate;
string bckplate;
string hub;
string rmshift;
string smshift;
string gapplt;
string gapcel;
string gapsmd;
string smdcentr;
string tierod;
string bckfrnt;
string gaphalf;
string cover;
string _index;
};
 
    struct _emcs_types_ {
  typedef float type;
  typedef float zorig;
  typedef float zend;
  typedef float etamin;
  typedef float etamax;
  typedef float phimin;
  typedef float phimax;
  typedef float offset;
  typedef float nsupsec;
  typedef float nsector;
  typedef float nsection;
  typedef float nslices;
  typedef float front;
  typedef float alincell;
  typedef float frplast;
  typedef float bkplast;
  typedef float pbplate;
  typedef float lamplate;
  typedef float bckplate;
  typedef float hub;
  typedef float rmshift;
  typedef float smshift;
  typedef float gapplt;
  typedef float gapcel;
  typedef float gapsmd;
  typedef float smdcentr;
  typedef float tierod[2];
  typedef float bckfrnt;
  typedef float gaphalf;
  typedef float cover;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct emcs_info {
typedef emcs_t Type;
static const char *name(){ return "emcs_t"; }
struct type {
  static const char *name() { return  "type"; }
  static int Offset(){ return offsetof( struct emcs_t, type ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zorig {
  static const char *name() { return  "zorig"; }
  static int Offset(){ return offsetof( struct emcs_t, zorig ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zend {
  static const char *name() { return  "zend"; }
  static int Offset(){ return offsetof( struct emcs_t, zend ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct etamin {
  static const char *name() { return  "etamin"; }
  static int Offset(){ return offsetof( struct emcs_t, etamin ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct etamax {
  static const char *name() { return  "etamax"; }
  static int Offset(){ return offsetof( struct emcs_t, etamax ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phimin {
  static const char *name() { return  "phimin"; }
  static int Offset(){ return offsetof( struct emcs_t, phimin ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phimax {
  static const char *name() { return  "phimax"; }
  static int Offset(){ return offsetof( struct emcs_t, phimax ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct offset {
  static const char *name() { return  "offset"; }
  static int Offset(){ return offsetof( struct emcs_t, offset ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nsupsec {
  static const char *name() { return  "nsupsec"; }
  static int Offset(){ return offsetof( struct emcs_t, nsupsec ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nsector {
  static const char *name() { return  "nsector"; }
  static int Offset(){ return offsetof( struct emcs_t, nsector ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nsection {
  static const char *name() { return  "nsection"; }
  static int Offset(){ return offsetof( struct emcs_t, nsection ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nslices {
  static const char *name() { return  "nslices"; }
  static int Offset(){ return offsetof( struct emcs_t, nslices ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct front {
  static const char *name() { return  "front"; }
  static int Offset(){ return offsetof( struct emcs_t, front ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct alincell {
  static const char *name() { return  "alincell"; }
  static int Offset(){ return offsetof( struct emcs_t, alincell ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct frplast {
  static const char *name() { return  "frplast"; }
  static int Offset(){ return offsetof( struct emcs_t, frplast ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bkplast {
  static const char *name() { return  "bkplast"; }
  static int Offset(){ return offsetof( struct emcs_t, bkplast ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pbplate {
  static const char *name() { return  "pbplate"; }
  static int Offset(){ return offsetof( struct emcs_t, pbplate ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct lamplate {
  static const char *name() { return  "lamplate"; }
  static int Offset(){ return offsetof( struct emcs_t, lamplate ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bckplate {
  static const char *name() { return  "bckplate"; }
  static int Offset(){ return offsetof( struct emcs_t, bckplate ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct hub {
  static const char *name() { return  "hub"; }
  static int Offset(){ return offsetof( struct emcs_t, hub ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmshift {
  static const char *name() { return  "rmshift"; }
  static int Offset(){ return offsetof( struct emcs_t, rmshift ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smshift {
  static const char *name() { return  "smshift"; }
  static int Offset(){ return offsetof( struct emcs_t, smshift ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gapplt {
  static const char *name() { return  "gapplt"; }
  static int Offset(){ return offsetof( struct emcs_t, gapplt ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gapcel {
  static const char *name() { return  "gapcel"; }
  static int Offset(){ return offsetof( struct emcs_t, gapcel ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gapsmd {
  static const char *name() { return  "gapsmd"; }
  static int Offset(){ return offsetof( struct emcs_t, gapsmd ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smdcentr {
  static const char *name() { return  "smdcentr"; }
  static int Offset(){ return offsetof( struct emcs_t, smdcentr ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tierod {
  static const char *name() { return  "tierod"; }
  static int Offset(){ return offsetof( struct emcs_t, tierod ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[2];
};
struct bckfrnt {
  static const char *name() { return  "bckfrnt"; }
  static int Offset(){ return offsetof( struct emcs_t, bckfrnt ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gaphalf {
  static const char *name() { return  "gaphalf"; }
  static int Offset(){ return offsetof( struct emcs_t, gaphalf ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cover {
  static const char *name() { return  "cover"; }
  static int Offset(){ return offsetof( struct emcs_t, cover ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct emcs_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)emcs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct eetr_t {
float type;
float etagr;
float phigr;
float neta;
float etabin[13];
int _index;
};
 
   struct _eetr_docum_ {
string type;
string etagr;
string phigr;
string neta;
string etabin;
string _index;
};
 
    struct _eetr_types_ {
  typedef float type;
  typedef float etagr;
  typedef float phigr;
  typedef float neta;
  typedef float etabin[13];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct eetr_info {
typedef eetr_t Type;
static const char *name(){ return "eetr_t"; }
struct type {
  static const char *name() { return  "type"; }
  static int Offset(){ return offsetof( struct eetr_t, type ); }
  static void* address(){ 
         long long iadd = (long long)eetr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct etagr {
  static const char *name() { return  "etagr"; }
  static int Offset(){ return offsetof( struct eetr_t, etagr ); }
  static void* address(){ 
         long long iadd = (long long)eetr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phigr {
  static const char *name() { return  "phigr"; }
  static int Offset(){ return offsetof( struct eetr_t, phigr ); }
  static void* address(){ 
         long long iadd = (long long)eetr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct neta {
  static const char *name() { return  "neta"; }
  static int Offset(){ return offsetof( struct eetr_t, neta ); }
  static void* address(){ 
         long long iadd = (long long)eetr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct etabin {
  static const char *name() { return  "etabin"; }
  static int Offset(){ return offsetof( struct eetr_t, etabin ); }
  static void* address(){ 
         long long iadd = (long long)eetr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[13];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct eetr_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)eetr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct esec_t {
float isect;
float fplmat;
float cell;
float scint;
float nlayer;
int _index;
};
 
   struct _esec_docum_ {
string isect;
string fplmat;
string cell;
string scint;
string nlayer;
string _index;
};
 
    struct _esec_types_ {
  typedef float isect;
  typedef float fplmat;
  typedef float cell;
  typedef float scint;
  typedef float nlayer;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct esec_info {
typedef esec_t Type;
static const char *name(){ return "esec_t"; }
struct isect {
  static const char *name() { return  "isect"; }
  static int Offset(){ return offsetof( struct esec_t, isect ); }
  static void* address(){ 
         long long iadd = (long long)esec_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fplmat {
  static const char *name() { return  "fplmat"; }
  static int Offset(){ return offsetof( struct esec_t, fplmat ); }
  static void* address(){ 
         long long iadd = (long long)esec_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cell {
  static const char *name() { return  "cell"; }
  static int Offset(){ return offsetof( struct esec_t, cell ); }
  static void* address(){ 
         long long iadd = (long long)esec_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct scint {
  static const char *name() { return  "scint"; }
  static int Offset(){ return offsetof( struct esec_t, scint ); }
  static void* address(){ 
         long long iadd = (long long)esec_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nlayer {
  static const char *name() { return  "nlayer"; }
  static int Offset(){ return offsetof( struct esec_t, nlayer ); }
  static void* address(){ 
         long long iadd = (long long)esec_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct esec_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)esec_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct emxg_t {
float version;
float sapex;
float sbase;
float rin;
float rout;
float f4;
int _index;
};
 
   struct _emxg_docum_ {
string version;
string sapex;
string sbase;
string rin;
string rout;
string f4;
string _index;
};
 
    struct _emxg_types_ {
  typedef float version;
  typedef float sapex;
  typedef float sbase;
  typedef float rin;
  typedef float rout;
  typedef float f4;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct emxg_info {
typedef emxg_t Type;
static const char *name(){ return "emxg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct emxg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)emxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sapex {
  static const char *name() { return  "sapex"; }
  static int Offset(){ return offsetof( struct emxg_t, sapex ); }
  static void* address(){ 
         long long iadd = (long long)emxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sbase {
  static const char *name() { return  "sbase"; }
  static int Offset(){ return offsetof( struct emxg_t, sbase ); }
  static void* address(){ 
         long long iadd = (long long)emxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rin {
  static const char *name() { return  "rin"; }
  static int Offset(){ return offsetof( struct emxg_t, rin ); }
  static void* address(){ 
         long long iadd = (long long)emxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rout {
  static const char *name() { return  "rout"; }
  static int Offset(){ return offsetof( struct emxg_t, rout ); }
  static void* address(){ 
         long long iadd = (long long)emxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct f4 {
  static const char *name() { return  "f4"; }
  static int Offset(){ return offsetof( struct emxg_t, f4 ); }
  static void* address(){ 
         long long iadd = (long long)emxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct emxg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)emxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct exse_t {
float jsect;
float zshift;
float sectype[6];
int _index;
};
 
   struct _exse_docum_ {
string jsect;
string zshift;
string sectype;
string _index;
};
 
    struct _exse_types_ {
  typedef float jsect;
  typedef float zshift;
  typedef float sectype[6];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct exse_info {
typedef exse_t Type;
static const char *name(){ return "exse_t"; }
struct jsect {
  static const char *name() { return  "jsect"; }
  static int Offset(){ return offsetof( struct exse_t, jsect ); }
  static void* address(){ 
         long long iadd = (long long)exse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zshift {
  static const char *name() { return  "zshift"; }
  static int Offset(){ return offsetof( struct exse_t, zshift ); }
  static void* address(){ 
         long long iadd = (long long)exse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sectype {
  static const char *name() { return  "sectype"; }
  static int Offset(){ return offsetof( struct exse_t, sectype ); }
  static void* address(){ 
         long long iadd = (long long)exse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[6];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct exse_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)exse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- ECAL -- 
   ///@defgroup ECAL_doc 
   ///@class ECAL 
   ///@brief is one EMC EndCap wheel [TGeoVolume] 
   class ECAL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ECAL() : AgBlock("ECAL","is one EMC EndCap wheel [TGeoVolume]"){ 
      }; 
      ~ECAL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EAGA -- 
   ///@defgroup EAGA_doc 
   ///@class EAGA 
   ///@brief is half of wheel air volume for the EndCap module [TGeoVolume] 
   class EAGA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EAGA() : AgBlock("EAGA","is half of wheel air volume for the EndCap module [TGeoVolume]"){ 
      }; 
      ~EAGA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EMSS -- 
   ///@defgroup EMSS_doc 
   ///@class EMSS 
   ///@brief is steel support of the EndCap module [TGeoVolume] 
   class EMSS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EMSS() : AgBlock("EMSS","is steel support of the EndCap module [TGeoVolume]"){ 
      }; 
      ~EMSS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ECVO -- 
   ///@defgroup ECVO_doc 
   ///@class ECVO 
   ///@brief is one of EndCap Volume with megatiles and radiators [TGeoVolume] 
   class ECVO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ECVO() : AgBlock("ECVO","is one of EndCap Volume with megatiles and radiators [TGeoVolume]"){ 
      }; 
      ~ECVO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ESHM -- 
   ///@defgroup ESHM_doc 
   ///@class ESHM 
   ///@brief is the SHower Max section [TGeoVolume] 
   class ESHM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ESHM() : AgBlock("ESHM","is the SHower Max section [TGeoVolume]"){ 
      }; 
      ~ESHM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ECGH -- 
   ///@defgroup ECGH_doc 
   ///@class ECGH 
   ///@brief is air Gap between endcap Half wheels [TGeoVolume] 
   class ECGH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ECGH() : AgBlock("ECGH","is air Gap between endcap Half wheels [TGeoVolume]"){ 
      }; 
      ~ECGH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ECHC -- 
   ///@defgroup ECHC_doc 
   ///@class ECHC 
   ///@brief is steel EndCap Half Cover [TGeoVolume] 
   class ECHC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ECHC() : AgBlock("ECHC","is steel EndCap Half Cover [TGeoVolume]"){ 
      }; 
      ~ECHC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ESSP -- 
   ///@defgroup ESSP_doc 
   ///@class ESSP 
   ///@brief is Stainless Steel back Plate [TGeoVolume] 
   class ESSP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ESSP() : AgBlock("ESSP","is Stainless Steel back Plate [TGeoVolume]"){ 
      }; 
      ~ESSP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EPSB -- 
   ///@defgroup EPSB_doc 
   ///@class EPSB 
   ///@brief is Projectile Stainless steel Bar [TGeoVolume] 
   class EPSB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EPSB() : AgBlock("EPSB","is Projectile Stainless steel Bar [TGeoVolume]"){ 
      }; 
      ~EPSB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ERCM -- 
   ///@defgroup ERCM_doc 
   ///@class ERCM 
   ///@brief is stainless steel tie Rod in CaloriMeter sections [TGeoVolume] 
   class ERCM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ERCM() : AgBlock("ERCM","is stainless steel tie Rod in CaloriMeter sections [TGeoVolume]"){ 
      }; 
      ~ERCM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ERSM -- 
   ///@defgroup ERSM_doc 
   ///@class ERSM 
   ///@brief is stainless steel tie Rod in Shower Max [TGeoVolume] 
   class ERSM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ERSM() : AgBlock("ERSM","is stainless steel tie Rod in Shower Max [TGeoVolume]"){ 
      }; 
      ~ERSM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EMOD -- 
   ///@defgroup EMOD_doc 
   ///@class EMOD 
   ///@brief is one module of the EM EndCap [TGeoVolume] 
   class EMOD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EMOD() : AgBlock("EMOD","is one module of the EM EndCap [TGeoVolume]"){ 
      }; 
      ~EMOD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ESEC -- 
   ///@defgroup ESEC_doc 
   ///@class ESEC 
   ///@brief is a single EM section [TGeoVolume] 
   class ESEC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ESEC() : AgBlock("ESEC","is a single EM section [TGeoVolume]"){ 
      }; 
      ~ESEC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EMGT -- 
   ///@defgroup EMGT_doc 
   ///@class EMGT 
   ///@brief is a megatile EM section [TGeoVolume] 
   class EMGT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EMGT() : AgBlock("EMGT","is a megatile EM section [TGeoVolume]"){ 
      }; 
      ~EMGT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EPER -- 
   ///@defgroup EPER_doc 
   ///@class EPER 
   ///@brief is a EM subsection period (super layer) [TGeoVolume] 
   class EPER : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EPER() : AgBlock("EPER","is a EM subsection period (super layer) [TGeoVolume]"){ 
      }; 
      ~EPER(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ETAR -- 
   ///@defgroup ETAR_doc 
   ///@class ETAR 
   ///@brief is one CELL of scintillator, fiber and plastic [TGeoVolume] 
   class ETAR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ETAR() : AgBlock("ETAR","is one CELL of scintillator, fiber and plastic [TGeoVolume]"){ 
      }; 
      ~ETAR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ESCI -- 
   ///@defgroup ESCI_doc 
   ///@class ESCI 
   ///@brief is the active scintillator (polystyren) layer [TGeoVolume] 
   class ESCI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ESCI() : AgBlock("ESCI","is the active scintillator (polystyren) layer [TGeoVolume]"){ 
      }; 
      ~ESCI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ERAD -- 
   ///@defgroup ERAD_doc 
   ///@class ERAD 
   ///@brief is radiator [TGeoVolume] 
   class ERAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ERAD() : AgBlock("ERAD","is radiator [TGeoVolume]"){ 
      }; 
      ~ERAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ELED -- 
   ///@defgroup ELED_doc 
   ///@class ELED 
   ///@brief is lead absorber Plate [TGeoVolume] 
   class ELED : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ELED() : AgBlock("ELED","is lead absorber Plate [TGeoVolume]"){ 
      }; 
      ~ELED(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EFLP -- 
   ///@defgroup EFLP_doc 
   ///@class EFLP 
   ///@brief is First Aluminium plate [TGeoVolume] 
   class EFLP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EFLP() : AgBlock("EFLP","is First Aluminium plate [TGeoVolume]"){ 
      }; 
      ~EFLP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EALP -- 
   ///@defgroup EALP_doc 
   ///@class EALP 
   ///@brief is ALuminium Plate in calorimeter cell [TGeoVolume] 
   class EALP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EALP() : AgBlock("EALP","is ALuminium Plate in calorimeter cell [TGeoVolume]"){ 
      }; 
      ~EALP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ESPL -- 
   ///@defgroup ESPL_doc 
   ///@class ESPL 
   ///@brief is one of the Shower max PLanes [TGeoVolume] 
   class ESPL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ESPL() : AgBlock("ESPL","is one of the Shower max PLanes [TGeoVolume]"){ 
      }; 
      ~ESPL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EXSG -- 
   ///@defgroup EXSG_doc 
   ///@class EXSG 
   ///@brief is the Shower max Gap for scintillator strips [TGeoVolume] 
   class EXSG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EXSG() : AgBlock("EXSG","is the Shower max Gap for scintillator strips [TGeoVolume]"){ 
      }; 
      ~EXSG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EHMS -- 
   ///@defgroup EHMS_doc 
   ///@class EHMS 
   ///@brief is sHower Max Strip [TGeoVolume] 
   class EHMS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EHMS() : AgBlock("EHMS","is sHower Max Strip [TGeoVolume]"){ 
      }; 
      ~EHMS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EXGT -- 
   ///@defgroup EXGT_doc 
   ///@class EXGT 
   ///@brief is the G10 layer in the Shower Max [TGeoVolume] 
   class EXGT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EXGT() : AgBlock("EXGT","is the G10 layer in the Shower Max [TGeoVolume]"){ 
      }; 
      ~EXGT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class EcalGeo 
   /// \brief  is the EM EndCap Calorimeter GEOmetry  
   class EcalGeo : public AgModule 
   { 
      public: 
      EcalGeo(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~EcalGeo(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace EcalGeo 
#endif // __EcalGeo__ 
