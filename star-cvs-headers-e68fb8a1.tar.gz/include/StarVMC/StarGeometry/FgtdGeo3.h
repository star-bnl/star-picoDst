#ifndef __FgtdGeo3__ 
#define __FgtdGeo3__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace FGTDGEO3 // $NMSPC 
{ 
   struct fggg_t {
float fgstconfig;
int _index;
};
 
   struct _fggg_docum_ {
string fgstconfig;
string _index;
};
 
    struct _fggg_types_ {
  typedef float fgstconfig;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fggg_info {
typedef fggg_t Type;
static const char *name(){ return "fggg_t"; }
struct fgstconfig {
  static const char *name() { return  "fgstconfig"; }
  static int Offset(){ return offsetof( struct fggg_t, fgstconfig ); }
  static void* address(){ 
         long long iadd = (long long)fggg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fggg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fggg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fgst_t {
float config;
int ndisk;
int nquad;
float zdisca[6];
float cool1stshift;
int _index;
};
 
   struct _fgst_docum_ {
string config;
string ndisk;
string nquad;
string zdisca;
string cool1stshift;
string _index;
};
 
    struct _fgst_types_ {
  typedef float config;
  typedef int ndisk;
  typedef int nquad;
  typedef float zdisca[6];
  typedef float cool1stshift;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fgst_info {
typedef fgst_t Type;
static const char *name(){ return "fgst_t"; }
struct config {
  static const char *name() { return  "config"; }
  static int Offset(){ return offsetof( struct fgst_t, config ); }
  static void* address(){ 
         long long iadd = (long long)fgst_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ndisk {
  static const char *name() { return  "ndisk"; }
  static int Offset(){ return offsetof( struct fgst_t, ndisk ); }
  static void* address(){ 
         long long iadd = (long long)fgst_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct nquad {
  static const char *name() { return  "nquad"; }
  static int Offset(){ return offsetof( struct fgst_t, nquad ); }
  static void* address(){ 
         long long iadd = (long long)fgst_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct zdisca {
  static const char *name() { return  "zdisca"; }
  static int Offset(){ return offsetof( struct fgst_t, zdisca ); }
  static void* address(){ 
         long long iadd = (long long)fgst_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[6];
};
struct cool1stshift {
  static const char *name() { return  "cool1stshift"; }
  static int Offset(){ return offsetof( struct fgst_t, cool1stshift ); }
  static void* address(){ 
         long long iadd = (long long)fgst_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fgst_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fgst_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- FGTM -- 
   ///@defgroup FGTM_doc 
   ///@class FGTM 
   ///@brief mother volume for FGT assembly [TGeoVolume] 
   class FGTM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGTM() : AgBlock("FGTM","mother volume for FGT assembly [TGeoVolume]"){ 
      }; 
      ~FGTM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGCT -- 
   ///@defgroup FGCT_doc 
   ///@class FGCT 
   ///@brief inner cooling tube [TGeoVolume] 
   class FGCT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGCT() : AgBlock("FGCT","inner cooling tube [TGeoVolume]"){ 
      }; 
      ~FGCT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGCN -- 
   ///@defgroup FGCN_doc 
   ///@class FGCN 
   ///@brief nylon 1st ring [TGeoVolume] 
   class FGCN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGCN() : AgBlock("FGCN","nylon 1st ring [TGeoVolume]"){ 
      }; 
      ~FGCN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGCM -- 
   ///@defgroup FGCM_doc 
   ///@class FGCM 
   ///@brief nylon and Al ring [TGeoVolume] 
   class FGCM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGCM() : AgBlock("FGCM","nylon and Al ring [TGeoVolume]"){ 
      }; 
      ~FGCM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGTD -- 
   ///@defgroup FGTD_doc 
   ///@class FGTD 
   ///@brief mother volume for FGT disk [TGeoVolume] 
   class FGTD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGTD() : AgBlock("FGTD","mother volume for FGT disk [TGeoVolume]"){ 
      }; 
      ~FGTD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGTH -- 
   ///@defgroup FGTH_doc 
   ///@class FGTH 
   ///@brief mother volume for FGT disk [TGeoVolume] 
   class FGTH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGTH() : AgBlock("FGTH","mother volume for FGT disk [TGeoVolume]"){ 
      }; 
      ~FGTH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGTQ -- 
   ///@defgroup FGTQ_doc 
   ///@class FGTQ 
   ///@brief quadrant  [TGeoVolume] 
   class FGTQ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGTQ() : AgBlock("FGTQ","quadrant  [TGeoVolume]"){ 
      }; 
      ~FGTQ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGVN -- 
   ///@defgroup FGVN_doc 
   ///@class FGVN 
   ///@brief quad nomex mixture volume [TGeoVolume] 
   class FGVN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGVN() : AgBlock("FGVN","quad nomex mixture volume [TGeoVolume]"){ 
      }; 
      ~FGVN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGZC -- 
   ///@defgroup FGZC_doc 
   ///@class FGZC 
   ///@brief sensitive volume [TGeoVolume] 
   class FGZC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGZC() : AgBlock("FGZC","sensitive volume [TGeoVolume]"){ 
      }; 
      ~FGZC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGVG -- 
   ///@defgroup FGVG_doc 
   ///@class FGVG 
   ///@brief quad 3GEM  mixture volume [TGeoVolume] 
   class FGVG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGVG() : AgBlock("FGVG","quad 3GEM  mixture volume [TGeoVolume]"){ 
      }; 
      ~FGVG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGVR -- 
   ///@defgroup FGVR_doc 
   ///@class FGVR 
   ///@brief quad readout mixture volume [TGeoVolume] 
   class FGVR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGVR() : AgBlock("FGVR","quad readout mixture volume [TGeoVolume]"){ 
      }; 
      ~FGVR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGVE -- 
   ///@defgroup FGVE_doc 
   ///@class FGVE 
   ///@brief quad electronics volume  [TGeoVolume] 
   class FGVE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGVE() : AgBlock("FGVE","quad electronics volume  [TGeoVolume]"){ 
      }; 
      ~FGVE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGQA -- 
   ///@defgroup FGQA_doc 
   ///@class FGQA 
   ///@brief A-spacer frame [TGeoVolume] 
   class FGQA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGQA() : AgBlock("FGQA","A-spacer frame [TGeoVolume]"){ 
      }; 
      ~FGQA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGQB -- 
   ///@defgroup FGQB_doc 
   ///@class FGQB 
   ///@brief B-spacer frame, arc [TGeoVolume] 
   class FGQB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGQB() : AgBlock("FGQB","B-spacer frame, arc [TGeoVolume]"){ 
      }; 
      ~FGQB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGQC -- 
   ///@defgroup FGQC_doc 
   ///@class FGQC 
   ///@brief C-spacer frame, bar [TGeoVolume] 
   class FGQC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGQC() : AgBlock("FGQC","C-spacer frame, bar [TGeoVolume]"){ 
      }; 
      ~FGQC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGQD -- 
   ///@defgroup FGQD_doc 
   ///@class FGQD 
   ///@brief D-spacer frame, arc [TGeoVolume] 
   class FGQD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGQD() : AgBlock("FGQD","D-spacer frame, arc [TGeoVolume]"){ 
      }; 
      ~FGQD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGQE -- 
   ///@defgroup FGQE_doc 
   ///@class FGQE 
   ///@brief E-spacer frame, flat [TGeoVolume] 
   class FGQE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGQE() : AgBlock("FGQE","E-spacer frame, flat [TGeoVolume]"){ 
      }; 
      ~FGQE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGQF -- 
   ///@defgroup FGQF_doc 
   ///@class FGQF 
   ///@brief F-spacer frame,  arc [TGeoVolume] 
   class FGQF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGQF() : AgBlock("FGQF","F-spacer frame,  arc [TGeoVolume]"){ 
      }; 
      ~FGQF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGXA -- 
   ///@defgroup FGXA_doc 
   ///@class FGXA 
   ///@brief A-grid, arc [TGeoVolume] 
   class FGXA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGXA() : AgBlock("FGXA","A-grid, arc [TGeoVolume]"){ 
      }; 
      ~FGXA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGXB -- 
   ///@defgroup FGXB_doc 
   ///@class FGXB 
   ///@brief B-grid, arc [TGeoVolume] 
   class FGXB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGXB() : AgBlock("FGXB","B-grid, arc [TGeoVolume]"){ 
      }; 
      ~FGXB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGXC -- 
   ///@defgroup FGXC_doc 
   ///@class FGXC 
   ///@brief C-grid, ray [TGeoVolume] 
   class FGXC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGXC() : AgBlock("FGXC","C-grid, ray [TGeoVolume]"){ 
      }; 
      ~FGXC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGXD -- 
   ///@defgroup FGXD_doc 
   ///@class FGXD 
   ///@brief D-grid, ray [TGeoVolume] 
   class FGXD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGXD() : AgBlock("FGXD","D-grid, ray [TGeoVolume]"){ 
      }; 
      ~FGXD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGWA -- 
   ///@defgroup FGWA_doc 
   ///@class FGWA 
   ///@brief A-elec, bar  [TGeoVolume] 
   class FGWA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGWA() : AgBlock("FGWA","A-elec, bar  [TGeoVolume]"){ 
      }; 
      ~FGWA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGWB -- 
   ///@defgroup FGWB_doc 
   ///@class FGWB 
   ///@brief APV board  [TGeoVolume] 
   class FGWB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGWB() : AgBlock("FGWB","APV board  [TGeoVolume]"){ 
      }; 
      ~FGWB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGWC -- 
   ///@defgroup FGWC_doc 
   ///@class FGWC 
   ///@brief interconnect board wider  [TGeoVolume] 
   class FGWC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGWC() : AgBlock("FGWC","interconnect board wider  [TGeoVolume]"){ 
      }; 
      ~FGWC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGWD -- 
   ///@defgroup FGWD_doc 
   ///@class FGWD 
   ///@brief gas feed connection  [TGeoVolume] 
   class FGWD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGWD() : AgBlock("FGWD","gas feed connection  [TGeoVolume]"){ 
      }; 
      ~FGWD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGWE -- 
   ///@defgroup FGWE_doc 
   ///@class FGWE 
   ///@brief HV board   [TGeoVolume] 
   class FGWE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGWE() : AgBlock("FGWE","HV board   [TGeoVolume]"){ 
      }; 
      ~FGWE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class FgtdGeo3 
   /// \brief  forward GEM tracking detector for 2012 , 2013 
   class FgtdGeo3 : public AgModule 
   { 
      public: 
      FgtdGeo3(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~FgtdGeo3(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace FgtdGeo3 
#endif // __FgtdGeo3__ 
