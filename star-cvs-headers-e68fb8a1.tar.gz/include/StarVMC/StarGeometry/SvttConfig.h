#ifndef __SVTT_CONFIG__ 
#define __SVTT_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo10.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo11.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo3.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo4.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo5.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo6.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo7.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo9.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SvttGeo.h" 
namespace SVTT { //
struct SVTTof {
  static const char *name()    { return "SVTTof"; }
  static const char *comment() { return "SVTT off"; }
  static const char *module()  { return "SvttGeo"; }
  static       bool  list();
  typedef SVTTGEO::SvttGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVtton {
  static const char *name()    { return "SVtton"; }
  static const char *comment() { return "SVTT on"; }
  static const char *module()  { return "SvttGeo"; }
  static       bool  list();
  typedef SVTTGEO::SvttGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT204 {
  static const char *name()    { return "SVT204"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo4"; }
  static       bool  list();
  typedef SVTTGEO4::SvttGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT206 {
  static const char *name()    { return "SVT206"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo6"; }
  static       bool  list();
  typedef SVTTGEO6::SvttGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT306 {
  static const char *name()    { return "SVT306"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo6"; }
  static       bool  list();
  typedef SVTTGEO6::SvttGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT306x {
  static const char *name()    { return "SVT306x"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo6"; }
  static       bool  list();
  typedef SVTTGEO6::SvttGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT310x {
  static const char *name()    { return "SVT310x"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo10"; }
  static       bool  list();
  typedef SVTTGEO10::SvttGeo10 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT312 {
  static const char *name()    { return "SVT312"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo11"; }
  static       bool  list();
  typedef SVTTGEO11::SvttGeo11 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT312x {
  static const char *name()    { return "SVT312x"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo11"; }
  static       bool  list();
  typedef SVTTGEO11::SvttGeo11 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT103 {
  static const char *name()    { return "SVT103"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo3"; }
  static       bool  list();
  typedef SVTTGEO3::SvttGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVTT00 {
  static const char *name()    { return "SVTT00"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo"; }
  static       bool  list();
  typedef SVTTGEO::SvttGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT100 {
  static const char *name()    { return "SVT100"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo"; }
  static       bool  list();
  typedef SVTTGEO::SvttGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT101 {
  static const char *name()    { return "SVT101"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo1"; }
  static       bool  list();
  typedef SVTTGEO1::SvttGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT102 {
  static const char *name()    { return "SVT102"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo2"; }
  static       bool  list();
  typedef SVTTGEO2::SvttGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT106 {
  static const char *name()    { return "SVT106"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo6"; }
  static       bool  list();
  typedef SVTTGEO6::SvttGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT203 {
  static const char *name()    { return "SVT203"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo3"; }
  static       bool  list();
  typedef SVTTGEO3::SvttGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT304 {
  static const char *name()    { return "SVT304"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo4"; }
  static       bool  list();
  typedef SVTTGEO4::SvttGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT211 {
  static const char *name()    { return "SVT211"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo11"; }
  static       bool  list();
  typedef SVTTGEO11::SvttGeo11 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SVTT { //
struct SVT311 {
  static const char *name()    { return "SVT311"; }
  static const char *comment() { return "SVTT version"; }
  static const char *module()  { return "SvttGeo11"; }
  static       bool  list();
  typedef SVTTGEO11::SvttGeo11 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
