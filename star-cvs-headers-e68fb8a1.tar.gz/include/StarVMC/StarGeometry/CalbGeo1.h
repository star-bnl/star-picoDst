#ifndef __CalbGeo1__ 
#define __CalbGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace CALBGEO1 // $NMSPC 
{ 
   struct calg_t {
float version;
float rmin;
float etacut;
float crackwd;
float frontthk;
float compthk;
float airthk;
float backthk;
float spacethk;
float scintthk[2];
float absorthk;
float abpapthk;
float g10sbthk;
float smalfwdh;
float smalfthk;
float smgasthk;
float smgaswdh;
float smgasrad;
float smaffwdh;
float smafbwdh;
float smetawdh;
float seta1wdh;
float netfirst;
float seta2wdh;
float netsecon;
float set12wdh;
float sphiwdh;
float sphidwdh;
float nphistr;
float nsmdalw;
float nsuper;
float nsmd;
float nsublay[2];
float nmodule[2];
float shift[2];
float maxmodule;
float netat;
float nsub;
float netasmdp;
float modmap[60];
int _index;
};
 
   struct _calg_docum_ {
string version;
string rmin;
string etacut;
string crackwd;
string frontthk;
string compthk;
string airthk;
string backthk;
string spacethk;
string scintthk;
string absorthk;
string abpapthk;
string g10sbthk;
string smalfwdh;
string smalfthk;
string smgasthk;
string smgaswdh;
string smgasrad;
string smaffwdh;
string smafbwdh;
string smetawdh;
string seta1wdh;
string netfirst;
string seta2wdh;
string netsecon;
string set12wdh;
string sphiwdh;
string sphidwdh;
string nphistr;
string nsmdalw;
string nsuper;
string nsmd;
string nsublay;
string nmodule;
string shift;
string maxmodule;
string netat;
string nsub;
string netasmdp;
string modmap;
string _index;
};
 
    struct _calg_types_ {
  typedef float version;
  typedef float rmin;
  typedef float etacut;
  typedef float crackwd;
  typedef float frontthk;
  typedef float compthk;
  typedef float airthk;
  typedef float backthk;
  typedef float spacethk;
  typedef float scintthk[2];
  typedef float absorthk;
  typedef float abpapthk;
  typedef float g10sbthk;
  typedef float smalfwdh;
  typedef float smalfthk;
  typedef float smgasthk;
  typedef float smgaswdh;
  typedef float smgasrad;
  typedef float smaffwdh;
  typedef float smafbwdh;
  typedef float smetawdh;
  typedef float seta1wdh;
  typedef float netfirst;
  typedef float seta2wdh;
  typedef float netsecon;
  typedef float set12wdh;
  typedef float sphiwdh;
  typedef float sphidwdh;
  typedef float nphistr;
  typedef float nsmdalw;
  typedef float nsuper;
  typedef float nsmd;
  typedef float nsublay[2];
  typedef float nmodule[2];
  typedef float shift[2];
  typedef float maxmodule;
  typedef float netat;
  typedef float nsub;
  typedef float netasmdp;
  typedef float modmap[60];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct calg_info {
typedef calg_t Type;
static const char *name(){ return "calg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct calg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct calg_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct etacut {
  static const char *name() { return  "etacut"; }
  static int Offset(){ return offsetof( struct calg_t, etacut ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct crackwd {
  static const char *name() { return  "crackwd"; }
  static int Offset(){ return offsetof( struct calg_t, crackwd ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct frontthk {
  static const char *name() { return  "frontthk"; }
  static int Offset(){ return offsetof( struct calg_t, frontthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct compthk {
  static const char *name() { return  "compthk"; }
  static int Offset(){ return offsetof( struct calg_t, compthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct airthk {
  static const char *name() { return  "airthk"; }
  static int Offset(){ return offsetof( struct calg_t, airthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct backthk {
  static const char *name() { return  "backthk"; }
  static int Offset(){ return offsetof( struct calg_t, backthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct spacethk {
  static const char *name() { return  "spacethk"; }
  static int Offset(){ return offsetof( struct calg_t, spacethk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct scintthk {
  static const char *name() { return  "scintthk"; }
  static int Offset(){ return offsetof( struct calg_t, scintthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[2];
};
struct absorthk {
  static const char *name() { return  "absorthk"; }
  static int Offset(){ return offsetof( struct calg_t, absorthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct abpapthk {
  static const char *name() { return  "abpapthk"; }
  static int Offset(){ return offsetof( struct calg_t, abpapthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct g10sbthk {
  static const char *name() { return  "g10sbthk"; }
  static int Offset(){ return offsetof( struct calg_t, g10sbthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smalfwdh {
  static const char *name() { return  "smalfwdh"; }
  static int Offset(){ return offsetof( struct calg_t, smalfwdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smalfthk {
  static const char *name() { return  "smalfthk"; }
  static int Offset(){ return offsetof( struct calg_t, smalfthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smgasthk {
  static const char *name() { return  "smgasthk"; }
  static int Offset(){ return offsetof( struct calg_t, smgasthk ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smgaswdh {
  static const char *name() { return  "smgaswdh"; }
  static int Offset(){ return offsetof( struct calg_t, smgaswdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smgasrad {
  static const char *name() { return  "smgasrad"; }
  static int Offset(){ return offsetof( struct calg_t, smgasrad ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smaffwdh {
  static const char *name() { return  "smaffwdh"; }
  static int Offset(){ return offsetof( struct calg_t, smaffwdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smafbwdh {
  static const char *name() { return  "smafbwdh"; }
  static int Offset(){ return offsetof( struct calg_t, smafbwdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smetawdh {
  static const char *name() { return  "smetawdh"; }
  static int Offset(){ return offsetof( struct calg_t, smetawdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct seta1wdh {
  static const char *name() { return  "seta1wdh"; }
  static int Offset(){ return offsetof( struct calg_t, seta1wdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct netfirst {
  static const char *name() { return  "netfirst"; }
  static int Offset(){ return offsetof( struct calg_t, netfirst ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct seta2wdh {
  static const char *name() { return  "seta2wdh"; }
  static int Offset(){ return offsetof( struct calg_t, seta2wdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct netsecon {
  static const char *name() { return  "netsecon"; }
  static int Offset(){ return offsetof( struct calg_t, netsecon ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct set12wdh {
  static const char *name() { return  "set12wdh"; }
  static int Offset(){ return offsetof( struct calg_t, set12wdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sphiwdh {
  static const char *name() { return  "sphiwdh"; }
  static int Offset(){ return offsetof( struct calg_t, sphiwdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sphidwdh {
  static const char *name() { return  "sphidwdh"; }
  static int Offset(){ return offsetof( struct calg_t, sphidwdh ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nphistr {
  static const char *name() { return  "nphistr"; }
  static int Offset(){ return offsetof( struct calg_t, nphistr ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nsmdalw {
  static const char *name() { return  "nsmdalw"; }
  static int Offset(){ return offsetof( struct calg_t, nsmdalw ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nsuper {
  static const char *name() { return  "nsuper"; }
  static int Offset(){ return offsetof( struct calg_t, nsuper ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nsmd {
  static const char *name() { return  "nsmd"; }
  static int Offset(){ return offsetof( struct calg_t, nsmd ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nsublay {
  static const char *name() { return  "nsublay"; }
  static int Offset(){ return offsetof( struct calg_t, nsublay ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[2];
};
struct nmodule {
  static const char *name() { return  "nmodule"; }
  static int Offset(){ return offsetof( struct calg_t, nmodule ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[2];
};
struct shift {
  static const char *name() { return  "shift"; }
  static int Offset(){ return offsetof( struct calg_t, shift ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[2];
};
struct maxmodule {
  static const char *name() { return  "maxmodule"; }
  static int Offset(){ return offsetof( struct calg_t, maxmodule ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct netat {
  static const char *name() { return  "netat"; }
  static int Offset(){ return offsetof( struct calg_t, netat ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nsub {
  static const char *name() { return  "nsub"; }
  static int Offset(){ return offsetof( struct calg_t, nsub ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct netasmdp {
  static const char *name() { return  "netasmdp"; }
  static int Offset(){ return offsetof( struct calg_t, netasmdp ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct modmap {
  static const char *name() { return  "modmap"; }
  static int Offset(){ return offsetof( struct calg_t, modmap ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[60];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct calg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)calg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct calr_t {
float rmin;
float rprs;
float rsmd1;
float rsmd2;
float rmax;
int _index;
};
 
   struct _calr_docum_ {
string rmin;
string rprs;
string rsmd1;
string rsmd2;
string rmax;
string _index;
};
 
    struct _calr_types_ {
  typedef float rmin;
  typedef float rprs;
  typedef float rsmd1;
  typedef float rsmd2;
  typedef float rmax;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct calr_info {
typedef calr_t Type;
static const char *name(){ return "calr_t"; }
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct calr_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)calr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rprs {
  static const char *name() { return  "rprs"; }
  static int Offset(){ return offsetof( struct calr_t, rprs ); }
  static void* address(){ 
         long long iadd = (long long)calr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rsmd1 {
  static const char *name() { return  "rsmd1"; }
  static int Offset(){ return offsetof( struct calr_t, rsmd1 ); }
  static void* address(){ 
         long long iadd = (long long)calr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rsmd2 {
  static const char *name() { return  "rsmd2"; }
  static int Offset(){ return offsetof( struct calr_t, rsmd2 ); }
  static void* address(){ 
         long long iadd = (long long)calr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct calr_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)calr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct calr_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)calr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- CALB -- 
   ///@defgroup CALB_doc 
   ///@class CALB 
   ///@brief is EMC Barrel envelope [TGeoVolume] 
   class CALB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CALB() : AgBlock("CALB","is EMC Barrel envelope [TGeoVolume]"){ 
      }; 
      ~CALB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CHLV -- 
   ///@defgroup CHLV_doc 
   ///@class CHLV 
   ///@brief corresponds to double modules... [TGeoVolume] 
   class CHLV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CHLV() : AgBlock("CHLV","corresponds to double modules... [TGeoVolume]"){ 
      }; 
      ~CHLV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CPHI -- 
   ///@defgroup CPHI_doc 
   ///@class CPHI 
   ///@brief corresponds to a single module [TGeoVolume] 
   class CPHI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CPHI() : AgBlock("CPHI","corresponds to a single module [TGeoVolume]"){ 
      }; 
      ~CPHI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSUP -- 
   ///@defgroup CSUP_doc 
   ///@class CSUP 
   ///@brief is a super layer with few layers inside [TGeoVolume] 
   class CSUP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSUP() : AgBlock("CSUP","is a super layer with few layers inside [TGeoVolume]"){ 
      }; 
      ~CSUP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CPBP -- 
   ///@defgroup CPBP_doc 
   ///@class CPBP 
   ///@brief is a block that an author failed to adequately document [TGeoVolume] 
   class CPBP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CPBP() : AgBlock("CPBP","is a block that an author failed to adequately document [TGeoVolume]"){ 
      }; 
      ~CPBP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSCI -- 
   ///@defgroup CSCI_doc 
   ///@class CSCI 
   ///@brief a scintillator layer. [TGeoVolume] 
   class CSCI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSCI() : AgBlock("CSCI","a scintillator layer. [TGeoVolume]"){ 
      }; 
      ~CSCI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CBTW -- 
   ///@defgroup CBTW_doc 
   ///@class CBTW 
   ///@brief is the Module Front Back Plate [TGeoVolume] 
   class CBTW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CBTW() : AgBlock("CBTW","is the Module Front Back Plate [TGeoVolume]"){ 
      }; 
      ~CBTW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSMD -- 
   ///@defgroup CSMD_doc 
   ///@class CSMD 
   ///@brief is the shower maximum detector envelope [TGeoVolume] 
   class CSMD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSMD() : AgBlock("CSMD","is the shower maximum detector envelope [TGeoVolume]"){ 
      }; 
      ~CSMD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSMG -- 
   ///@defgroup CSMG_doc 
   ///@class CSMG 
   ///@brief is G10 front back plate [TGeoVolume] 
   class CSMG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSMG() : AgBlock("CSMG","is G10 front back plate [TGeoVolume]"){ 
      }; 
      ~CSMG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSDA -- 
   ///@defgroup CSDA_doc 
   ///@class CSDA 
   ///@brief is Al block with sensitive gas volume [TGeoVolume] 
   class CSDA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSDA() : AgBlock("CSDA","is Al block with sensitive gas volume [TGeoVolume]"){ 
      }; 
      ~CSDA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSMC -- 
   ///@defgroup CSMC_doc 
   ///@class CSMC 
   ///@brief is the front first (last) Al rib [TGeoVolume] 
   class CSMC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSMC() : AgBlock("CSMC","is the front first (last) Al rib [TGeoVolume]"){ 
      }; 
      ~CSMC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSMB -- 
   ///@defgroup CSMB_doc 
   ///@class CSMB 
   ///@brief is the back first (last) Al rib [TGeoVolume] 
   class CSMB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSMB() : AgBlock("CSMB","is the back first (last) Al rib [TGeoVolume]"){ 
      }; 
      ~CSMB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSME -- 
   ///@defgroup CSME_doc 
   ///@class CSME 
   ///@brief is the part of CSDA Al box with Ar/CO2 sensiteve gas [TGeoVolume] 
   class CSME : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSME() : AgBlock("CSME","is the part of CSDA Al box with Ar/CO2 sensiteve gas [TGeoVolume]"){ 
      }; 
      ~CSME(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- CSHI -- 
   ///@defgroup CSHI_doc 
   ///@class CSHI 
   ///@brief is a sensiteve Ar/CO2 box [TGeoVolume] 
   class CSHI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      CSHI() : AgBlock("CSHI","is a sensiteve Ar/CO2 box [TGeoVolume]"){ 
      }; 
      ~CSHI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class CalbGeo1 
   /// \brief  is the geometry of the Barrel EM Calorimeter  
   class CalbGeo1 : public AgModule 
   { 
      public: 
      CalbGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~CalbGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace CalbGeo1 
#endif // __CalbGeo1__ 
