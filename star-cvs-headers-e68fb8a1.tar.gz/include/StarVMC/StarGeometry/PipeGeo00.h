#ifndef __PipeGeo00__ 
#define __PipeGeo00__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace PIPEGEO00 // $NMSPC 
{ 
   struct pipv_t {
float version;
float pipeconfig;
int _index;
};
 
   struct _pipv_docum_ {
string version;
string pipeconfig;
string _index;
};
 
    struct _pipv_types_ {
  typedef float version;
  typedef float pipeconfig;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pipv_info {
typedef pipv_t Type;
static const char *name(){ return "pipv_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct pipv_t, version ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pipeconfig {
  static const char *name() { return  "pipeconfig"; }
  static int Offset(){ return offsetof( struct pipv_t, pipeconfig ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pipv_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct pipg_t {
float config;
float beinnr;
float beoutr;
float beleng;
int _index;
};
 
   struct _pipg_docum_ {
string config;
string beinnr;
string beoutr;
string beleng;
string _index;
};
 
    struct _pipg_types_ {
  typedef float config;
  typedef float beinnr;
  typedef float beoutr;
  typedef float beleng;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pipg_info {
typedef pipg_t Type;
static const char *name(){ return "pipg_t"; }
struct config {
  static const char *name() { return  "config"; }
  static int Offset(){ return offsetof( struct pipg_t, config ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct beinnr {
  static const char *name() { return  "beinnr"; }
  static int Offset(){ return offsetof( struct pipg_t, beinnr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct beoutr {
  static const char *name() { return  "beoutr"; }
  static int Offset(){ return offsetof( struct pipg_t, beoutr ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct beleng {
  static const char *name() { return  "beleng"; }
  static int Offset(){ return offsetof( struct pipg_t, beleng ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pipg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- PIPE -- 
   ///@defgroup PIPE_doc 
   ///@class PIPE 
   ///@brief is the STAR beam pipe mother volume [TGeoVolume] 
   class PIPE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPE() : AgBlock("PIPE","is the STAR beam pipe mother volume [TGeoVolume]"){ 
      }; 
      ~PIPE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PIPC -- 
   ///@defgroup PIPC_doc 
   ///@class PIPC 
   ///@brief is the Central Beam PIPe Volume [TGeoVolume] 
   class PIPC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPC() : AgBlock("PIPC","is the Central Beam PIPe Volume [TGeoVolume]"){ 
      }; 
      ~PIPC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PVAC -- 
   ///@defgroup PVAC_doc 
   ///@class PVAC 
   ///@brief is the Vacuum Volume of Be section of pipe [TGeoVolume] 
   class PVAC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PVAC() : AgBlock("PVAC","is the Vacuum Volume of Be section of pipe [TGeoVolume]"){ 
      }; 
      ~PVAC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class PipeGeo00 
   /// \brief  is the SIMPLIFIED geometry  of the STAR beam pipe.  
   class PipeGeo00 : public AgModule 
   { 
      public: 
      PipeGeo00(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~PipeGeo00(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace PipeGeo00 
#endif // __PipeGeo00__ 
