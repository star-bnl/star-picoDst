#ifndef __ZCAL_CONFIG__ 
#define __ZCAL_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/ZcalGeo.h" 
namespace ZCAL { //
struct ZCALof {
  static const char *name()    { return "ZCALof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "ZcalGeo"; }
  static       bool  list();
  typedef ZCALGEO::ZcalGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace ZCAL { //
struct ZCALon {
  static const char *name()    { return "ZCALon"; }
  static const char *comment() { return "Zcalream"; }
  static const char *module()  { return "ZcalGeo"; }
  static       bool  list();
  typedef ZCALGEO::ZcalGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
