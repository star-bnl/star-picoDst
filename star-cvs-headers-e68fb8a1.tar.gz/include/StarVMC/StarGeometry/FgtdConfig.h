#ifndef __FGTD_CONFIG__ 
#define __FGTD_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/FgtdGeo3.h" 
namespace FGTD { //
struct FGTDof {
  static const char *name()    { return "FGTDof"; }
  static const char *comment() { return "FGT off"; }
  static const char *module()  { return "FgtdGeo3"; }
  static       bool  list();
  typedef FGTDGEO3::FgtdGeo3 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FGTD { //
struct FGTDon {
  static const char *name()    { return "FGTDon"; }
  static const char *comment() { return "Default configuration for the Forward GEM tracker"; }
  static const char *module()  { return "FgtdGeo3"; }
  static       bool  list();
  typedef FGTDGEO3::FgtdGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FGTD { //
struct FGTD31 {
  static const char *name()    { return "FGTD31"; }
  static const char *comment() { return "Default configuration for the Forward GEM tracker"; }
  static const char *module()  { return "FgtdGeo3"; }
  static       bool  list();
  typedef FGTDGEO3::FgtdGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FGTD { //
struct FGTD32 {
  static const char *name()    { return "FGTD32"; }
  static const char *comment() { return "Default configuration for the Forward GEM tracker"; }
  static const char *module()  { return "FgtdGeo3"; }
  static       bool  list();
  typedef FGTDGEO3::FgtdGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
