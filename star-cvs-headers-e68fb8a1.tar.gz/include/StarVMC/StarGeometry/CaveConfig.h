#ifndef __CAVE_CONFIG__ 
#define __CAVE_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/CaveGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/CaveGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/CaveGeo3.h" 
namespace CAVE { //
struct CAVEof {
  static const char *name()    { return "CAVEof"; }
  static const char *comment() { return "No CAVE"; }
  static const char *module()  { return "CaveGeo"; }
  static       bool  list();
  typedef CAVEGEO::CaveGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CAVE { //
struct CAVEon {
  static const char *name()    { return "CAVEon"; }
  static const char *comment() { return "The STAR Wide Angle Hall"; }
  static const char *module()  { return "CaveGeo"; }
  static       bool  list();
  typedef CAVEGEO::CaveGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CAVE { //
struct CAVE03 {
  static const char *name()    { return "CAVE03"; }
  static const char *comment() { return "The STAR Wide Angle Hall"; }
  static const char *module()  { return "CaveGeo"; }
  static       bool  list();
  typedef CAVEGEO::CaveGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CAVE { //
struct CAVE04 {
  static const char *name()    { return "CAVE04"; }
  static const char *comment() { return "The STAR Wide Angle Hall"; }
  static const char *module()  { return "CaveGeo"; }
  static       bool  list();
  typedef CAVEGEO::CaveGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CAVE { //
struct CAVE05 {
  static const char *name()    { return "CAVE05"; }
  static const char *comment() { return "The STAR Wide Angle Hall"; }
  static const char *module()  { return "CaveGeo2"; }
  static       bool  list();
  typedef CAVEGEO2::CaveGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace CAVE { //
struct CAVE06 {
  static const char *name()    { return "CAVE06"; }
  static const char *comment() { return "The STAR Wide Angle Hall"; }
  static const char *module()  { return "CaveGeo3"; }
  static       bool  list();
  typedef CAVEGEO3::CaveGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
