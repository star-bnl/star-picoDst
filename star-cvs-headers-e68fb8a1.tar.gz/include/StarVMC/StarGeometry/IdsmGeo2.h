#ifndef __IdsmGeo2__ 
#define __IdsmGeo2__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace IDSMGEO2 // $NMSPC 
{ 
   struct idsc_t {
float version;
int _index;
};
 
   struct _idsc_docum_ {
string version;
string _index;
};
 
    struct _idsc_types_ {
  typedef float version;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct idsc_info {
typedef idsc_t Type;
static const char *name(){ return "idsc_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct idsc_t, version ); }
  static void* address(){ 
         long long iadd = (long long)idsc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct idsc_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)idsc_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct idsg_t {
float version;
float rf;
float angflat;
float r1res;
float r2res;
float rrres;
float dangres;
float dxres;
float dyres;
float fgtstartz;
float fgtdiskstepz;
int fgtndisk;
float ewcsinnerrad;
float ewcsouterrad;
int _index;
};
 
   struct _idsg_docum_ {
string version;
string rf;
string angflat;
string r1res;
string r2res;
string rrres;
string dangres;
string dxres;
string dyres;
string fgtstartz;
string fgtdiskstepz;
string fgtndisk;
string ewcsinnerrad;
string ewcsouterrad;
string _index;
};
 
    struct _idsg_types_ {
  typedef float version;
  typedef float rf;
  typedef float angflat;
  typedef float r1res;
  typedef float r2res;
  typedef float rrres;
  typedef float dangres;
  typedef float dxres;
  typedef float dyres;
  typedef float fgtstartz;
  typedef float fgtdiskstepz;
  typedef int fgtndisk;
  typedef float ewcsinnerrad;
  typedef float ewcsouterrad;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct idsg_info {
typedef idsg_t Type;
static const char *name(){ return "idsg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct idsg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rf {
  static const char *name() { return  "rf"; }
  static int Offset(){ return offsetof( struct idsg_t, rf ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct angflat {
  static const char *name() { return  "angflat"; }
  static int Offset(){ return offsetof( struct idsg_t, angflat ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct r1res {
  static const char *name() { return  "r1res"; }
  static int Offset(){ return offsetof( struct idsg_t, r1res ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct r2res {
  static const char *name() { return  "r2res"; }
  static int Offset(){ return offsetof( struct idsg_t, r2res ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rrres {
  static const char *name() { return  "rrres"; }
  static int Offset(){ return offsetof( struct idsg_t, rrres ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dangres {
  static const char *name() { return  "dangres"; }
  static int Offset(){ return offsetof( struct idsg_t, dangres ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dxres {
  static const char *name() { return  "dxres"; }
  static int Offset(){ return offsetof( struct idsg_t, dxres ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dyres {
  static const char *name() { return  "dyres"; }
  static int Offset(){ return offsetof( struct idsg_t, dyres ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fgtstartz {
  static const char *name() { return  "fgtstartz"; }
  static int Offset(){ return offsetof( struct idsg_t, fgtstartz ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fgtdiskstepz {
  static const char *name() { return  "fgtdiskstepz"; }
  static int Offset(){ return offsetof( struct idsg_t, fgtdiskstepz ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fgtndisk {
  static const char *name() { return  "fgtndisk"; }
  static int Offset(){ return offsetof( struct idsg_t, fgtndisk ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct ewcsinnerrad {
  static const char *name() { return  "ewcsinnerrad"; }
  static int Offset(){ return offsetof( struct idsg_t, ewcsinnerrad ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ewcsouterrad {
  static const char *name() { return  "ewcsouterrad"; }
  static int Offset(){ return offsetof( struct idsg_t, ewcsouterrad ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct idsg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)idsg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct idsa_t {
float version;
float x;
float y;
float z;
float thetax;
float thetay;
float thetaz;
float phix;
float phiy;
float phiz;
int _index;
};
 
   struct _idsa_docum_ {
string version;
string x;
string y;
string z;
string thetax;
string thetay;
string thetaz;
string phix;
string phiy;
string phiz;
string _index;
};
 
    struct _idsa_types_ {
  typedef float version;
  typedef float x;
  typedef float y;
  typedef float z;
  typedef float thetax;
  typedef float thetay;
  typedef float thetaz;
  typedef float phix;
  typedef float phiy;
  typedef float phiz;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct idsa_info {
typedef idsa_t Type;
static const char *name(){ return "idsa_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct idsa_t, version ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct idsa_t, x ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct idsa_t, y ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct idsa_t, z ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct thetax {
  static const char *name() { return  "thetax"; }
  static int Offset(){ return offsetof( struct idsa_t, thetax ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct thetay {
  static const char *name() { return  "thetay"; }
  static int Offset(){ return offsetof( struct idsa_t, thetay ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct thetaz {
  static const char *name() { return  "thetaz"; }
  static int Offset(){ return offsetof( struct idsa_t, thetaz ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phix {
  static const char *name() { return  "phix"; }
  static int Offset(){ return offsetof( struct idsa_t, phix ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phiy {
  static const char *name() { return  "phiy"; }
  static int Offset(){ return offsetof( struct idsa_t, phiy ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phiz {
  static const char *name() { return  "phiz"; }
  static int Offset(){ return offsetof( struct idsa_t, phiz ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct idsa_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)idsa_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- IDSM -- 
   ///@defgroup IDSM_doc 
   ///@class IDSM 
   ///@brief mother volume for beam support cone [TGeoVolume] 
   class IDSM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      IDSM() : AgBlock("IDSM","mother volume for beam support cone [TGeoVolume]"){ 
      }; 
      ~IDSM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- OSCA -- 
   ///@defgroup OSCA_doc 
   ///@class OSCA 
   ///@brief central CFiber tube  (OSC)  [TGeoVolume] 
   class OSCA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      OSCA() : AgBlock("OSCA","central CFiber tube  (OSC)  [TGeoVolume]"){ 
      }; 
      ~OSCA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SUCB -- 
   ///@defgroup SUCB_doc 
   ///@class SUCB 
   ///@brief small Alu ring at central tube [TGeoVolume] 
   class SUCB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SUCB() : AgBlock("SUCB","small Alu ring at central tube [TGeoVolume]"){ 
      }; 
      ~SUCB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SUCC -- 
   ///@defgroup SUCC_doc 
   ///@class SUCC 
   ///@brief CFiber cone section [TGeoVolume] 
   class SUCC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SUCC() : AgBlock("SUCC","CFiber cone section [TGeoVolume]"){ 
      }; 
      ~SUCC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SUCD -- 
   ///@defgroup SUCD_doc 
   ///@class SUCD 
   ///@brief large Al ring at cone [TGeoVolume] 
   class SUCD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SUCD() : AgBlock("SUCD","large Al ring at cone [TGeoVolume]"){ 
      }; 
      ~SUCD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SUCE -- 
   ///@defgroup SUCE_doc 
   ///@class SUCE 
   ///@brief East or West CFiber tube [TGeoVolume] 
   class SUCE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SUCE() : AgBlock("SUCE","East or West CFiber tube [TGeoVolume]"){ 
      }; 
      ~SUCE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SUCF -- 
   ///@defgroup SUCF_doc 
   ///@class SUCF 
   ///@brief large Alu ring at the end of west cylinder [TGeoVolume] 
   class SUCF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SUCF() : AgBlock("SUCF","large Alu ring at the end of west cylinder [TGeoVolume]"){ 
      }; 
      ~SUCF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- SUCG -- 
   ///@defgroup SUCG_doc 
   ///@class SUCG 
   ///@brief large Alu end disk [TGeoVolume] 
   class SUCG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      SUCG() : AgBlock("SUCG","large Alu end disk [TGeoVolume]"){ 
      }; 
      ~SUCG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- EFSA -- 
   ///@defgroup EFSA_doc 
   ///@class EFSA 
   ///@brief Electrostatic shroud at near end of ESC and WSC [TGeoVolume] 
   class EFSA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      EFSA() : AgBlock("EFSA","Electrostatic shroud at near end of ESC and WSC [TGeoVolume]"){ 
      }; 
      ~EFSA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TPRR -- 
   ///@defgroup TPRR_doc 
   ///@class TPRR 
   ///@brief  TPC resistor [TGeoVolume] 
   class TPRR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPRR() : AgBlock("TPRR"," TPC resistor [TGeoVolume]"){ 
      }; 
      ~TPRR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TPRT -- 
   ///@defgroup TPRT_doc 
   ///@class TPRT 
   ///@brief resistor protection,  carbon fiber [TGeoVolume] 
   class TPRT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPRT() : AgBlock("TPRT","resistor protection,  carbon fiber [TGeoVolume]"){ 
      }; 
      ~TPRT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGRL -- 
   ///@defgroup FGRL_doc 
   ///@class FGRL 
   ///@brief FGT rail  [TGeoVolume] 
   class FGRL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGRL() : AgBlock("FGRL","FGT rail  [TGeoVolume]"){ 
      }; 
      ~FGRL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FGHV -- 
   ///@defgroup FGHV_doc 
   ///@class FGHV 
   ///@brief FGT cables mixture  [TGeoVolume] 
   class FGHV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FGHV() : AgBlock("FGHV","FGT cables mixture  [TGeoVolume]"){ 
      }; 
      ~FGHV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class IdsmGeo2 
   /// \brief  simplified  beam support cone for 2013  
   class IdsmGeo2 : public AgModule 
   { 
      public: 
      IdsmGeo2(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~IdsmGeo2(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace IdsmGeo2 
#endif // __IdsmGeo2__ 
