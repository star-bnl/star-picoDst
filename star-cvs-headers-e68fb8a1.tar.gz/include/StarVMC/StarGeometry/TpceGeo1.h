#ifndef __TpceGeo1__ 
#define __TpceGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace TPCEGEO1 // $NMSPC 
{ 
   struct tpcg_t {
float version;
float rmin;
float rmax;
float length;
float wheelir;
float wheelor;
float wheelthk;
float sengasor;
float tpeathk;
float membthk;
float tiaddr;
float tinxdr;
float tikadr;
float tialdr;
float tocsdr;
float tokadr;
float tonxdr;
float toaddr;
float toigdr;
float toaldr;
float tohadr;
float mwcread;
float gascorr;
int _index;
};
 
   struct _tpcg_docum_ {
string version;
string rmin;
string rmax;
string length;
string wheelir;
string wheelor;
string wheelthk;
string sengasor;
string tpeathk;
string membthk;
string tiaddr;
string tinxdr;
string tikadr;
string tialdr;
string tocsdr;
string tokadr;
string tonxdr;
string toaddr;
string toigdr;
string toaldr;
string tohadr;
string mwcread;
string gascorr;
string _index;
};
 
    struct _tpcg_types_ {
  typedef float version;
  typedef float rmin;
  typedef float rmax;
  typedef float length;
  typedef float wheelir;
  typedef float wheelor;
  typedef float wheelthk;
  typedef float sengasor;
  typedef float tpeathk;
  typedef float membthk;
  typedef float tiaddr;
  typedef float tinxdr;
  typedef float tikadr;
  typedef float tialdr;
  typedef float tocsdr;
  typedef float tokadr;
  typedef float tonxdr;
  typedef float toaddr;
  typedef float toigdr;
  typedef float toaldr;
  typedef float tohadr;
  typedef float mwcread;
  typedef float gascorr;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct tpcg_info {
typedef tpcg_t Type;
static const char *name(){ return "tpcg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct tpcg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct tpcg_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct tpcg_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct length {
  static const char *name() { return  "length"; }
  static int Offset(){ return offsetof( struct tpcg_t, length ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wheelir {
  static const char *name() { return  "wheelir"; }
  static int Offset(){ return offsetof( struct tpcg_t, wheelir ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wheelor {
  static const char *name() { return  "wheelor"; }
  static int Offset(){ return offsetof( struct tpcg_t, wheelor ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wheelthk {
  static const char *name() { return  "wheelthk"; }
  static int Offset(){ return offsetof( struct tpcg_t, wheelthk ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sengasor {
  static const char *name() { return  "sengasor"; }
  static int Offset(){ return offsetof( struct tpcg_t, sengasor ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tpeathk {
  static const char *name() { return  "tpeathk"; }
  static int Offset(){ return offsetof( struct tpcg_t, tpeathk ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct membthk {
  static const char *name() { return  "membthk"; }
  static int Offset(){ return offsetof( struct tpcg_t, membthk ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tiaddr {
  static const char *name() { return  "tiaddr"; }
  static int Offset(){ return offsetof( struct tpcg_t, tiaddr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tinxdr {
  static const char *name() { return  "tinxdr"; }
  static int Offset(){ return offsetof( struct tpcg_t, tinxdr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tikadr {
  static const char *name() { return  "tikadr"; }
  static int Offset(){ return offsetof( struct tpcg_t, tikadr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tialdr {
  static const char *name() { return  "tialdr"; }
  static int Offset(){ return offsetof( struct tpcg_t, tialdr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tocsdr {
  static const char *name() { return  "tocsdr"; }
  static int Offset(){ return offsetof( struct tpcg_t, tocsdr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tokadr {
  static const char *name() { return  "tokadr"; }
  static int Offset(){ return offsetof( struct tpcg_t, tokadr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tonxdr {
  static const char *name() { return  "tonxdr"; }
  static int Offset(){ return offsetof( struct tpcg_t, tonxdr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct toaddr {
  static const char *name() { return  "toaddr"; }
  static int Offset(){ return offsetof( struct tpcg_t, toaddr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct toigdr {
  static const char *name() { return  "toigdr"; }
  static int Offset(){ return offsetof( struct tpcg_t, toigdr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct toaldr {
  static const char *name() { return  "toaldr"; }
  static int Offset(){ return offsetof( struct tpcg_t, toaldr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tohadr {
  static const char *name() { return  "tohadr"; }
  static int Offset(){ return offsetof( struct tpcg_t, tohadr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mwcread {
  static const char *name() { return  "mwcread"; }
  static int Offset(){ return offsetof( struct tpcg_t, mwcread ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gascorr {
  static const char *name() { return  "gascorr"; }
  static int Offset(){ return offsetof( struct tpcg_t, gascorr ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct tpcg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)tpcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct tecw_t {
float sec;
float gaprad;
float gapheit;
float gapwidi;
float gapwido;
float gapshft;
float inwidth;
float ouwidth;
float height;
float ppdepth;
float asdepth;
float ggdepth;
float mwcdepth;
float boundary;
float rcenter;
float mwcinn;
float mwcout;
float mwchei;
float mwccent;
float mwcnwir;
float n;
float nex;
float z[8];
float dz[8];
float xex[5];
float zex[5];
float dxex[5];
float dzex[5];
float nhplane[8];
float cardw;
float cardth;
float coolw;
float coolth;
float cardoff;
float cooloff;
float slotw;
float slotrad;
float pipethk;
float pipeht;
float manithk;
float maniwid;
float tan15;
float clearance;
float whlipthk;
float whlipwid;
float whblklen;
float whblkpos;
float whblkin;
int _index;
};
 
   struct _tecw_docum_ {
string sec;
string gaprad;
string gapheit;
string gapwidi;
string gapwido;
string gapshft;
string inwidth;
string ouwidth;
string height;
string ppdepth;
string asdepth;
string ggdepth;
string mwcdepth;
string boundary;
string rcenter;
string mwcinn;
string mwcout;
string mwchei;
string mwccent;
string mwcnwir;
string n;
string nex;
string z;
string dz;
string xex;
string zex;
string dxex;
string dzex;
string nhplane;
string cardw;
string cardth;
string coolw;
string coolth;
string cardoff;
string cooloff;
string slotw;
string slotrad;
string pipethk;
string pipeht;
string manithk;
string maniwid;
string tan15;
string clearance;
string whlipthk;
string whlipwid;
string whblklen;
string whblkpos;
string whblkin;
string _index;
};
 
    struct _tecw_types_ {
  typedef float sec;
  typedef float gaprad;
  typedef float gapheit;
  typedef float gapwidi;
  typedef float gapwido;
  typedef float gapshft;
  typedef float inwidth;
  typedef float ouwidth;
  typedef float height;
  typedef float ppdepth;
  typedef float asdepth;
  typedef float ggdepth;
  typedef float mwcdepth;
  typedef float boundary;
  typedef float rcenter;
  typedef float mwcinn;
  typedef float mwcout;
  typedef float mwchei;
  typedef float mwccent;
  typedef float mwcnwir;
  typedef float n;
  typedef float nex;
  typedef float z[8];
  typedef float dz[8];
  typedef float xex[5];
  typedef float zex[5];
  typedef float dxex[5];
  typedef float dzex[5];
  typedef float nhplane[8];
  typedef float cardw;
  typedef float cardth;
  typedef float coolw;
  typedef float coolth;
  typedef float cardoff;
  typedef float cooloff;
  typedef float slotw;
  typedef float slotrad;
  typedef float pipethk;
  typedef float pipeht;
  typedef float manithk;
  typedef float maniwid;
  typedef float tan15;
  typedef float clearance;
  typedef float whlipthk;
  typedef float whlipwid;
  typedef float whblklen;
  typedef float whblkpos;
  typedef float whblkin;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct tecw_info {
typedef tecw_t Type;
static const char *name(){ return "tecw_t"; }
struct sec {
  static const char *name() { return  "sec"; }
  static int Offset(){ return offsetof( struct tecw_t, sec ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gaprad {
  static const char *name() { return  "gaprad"; }
  static int Offset(){ return offsetof( struct tecw_t, gaprad ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gapheit {
  static const char *name() { return  "gapheit"; }
  static int Offset(){ return offsetof( struct tecw_t, gapheit ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gapwidi {
  static const char *name() { return  "gapwidi"; }
  static int Offset(){ return offsetof( struct tecw_t, gapwidi ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gapwido {
  static const char *name() { return  "gapwido"; }
  static int Offset(){ return offsetof( struct tecw_t, gapwido ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gapshft {
  static const char *name() { return  "gapshft"; }
  static int Offset(){ return offsetof( struct tecw_t, gapshft ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct inwidth {
  static const char *name() { return  "inwidth"; }
  static int Offset(){ return offsetof( struct tecw_t, inwidth ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ouwidth {
  static const char *name() { return  "ouwidth"; }
  static int Offset(){ return offsetof( struct tecw_t, ouwidth ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct height {
  static const char *name() { return  "height"; }
  static int Offset(){ return offsetof( struct tecw_t, height ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ppdepth {
  static const char *name() { return  "ppdepth"; }
  static int Offset(){ return offsetof( struct tecw_t, ppdepth ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct asdepth {
  static const char *name() { return  "asdepth"; }
  static int Offset(){ return offsetof( struct tecw_t, asdepth ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ggdepth {
  static const char *name() { return  "ggdepth"; }
  static int Offset(){ return offsetof( struct tecw_t, ggdepth ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mwcdepth {
  static const char *name() { return  "mwcdepth"; }
  static int Offset(){ return offsetof( struct tecw_t, mwcdepth ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct boundary {
  static const char *name() { return  "boundary"; }
  static int Offset(){ return offsetof( struct tecw_t, boundary ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rcenter {
  static const char *name() { return  "rcenter"; }
  static int Offset(){ return offsetof( struct tecw_t, rcenter ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mwcinn {
  static const char *name() { return  "mwcinn"; }
  static int Offset(){ return offsetof( struct tecw_t, mwcinn ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mwcout {
  static const char *name() { return  "mwcout"; }
  static int Offset(){ return offsetof( struct tecw_t, mwcout ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mwchei {
  static const char *name() { return  "mwchei"; }
  static int Offset(){ return offsetof( struct tecw_t, mwchei ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mwccent {
  static const char *name() { return  "mwccent"; }
  static int Offset(){ return offsetof( struct tecw_t, mwccent ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mwcnwir {
  static const char *name() { return  "mwcnwir"; }
  static int Offset(){ return offsetof( struct tecw_t, mwcnwir ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct n {
  static const char *name() { return  "n"; }
  static int Offset(){ return offsetof( struct tecw_t, n ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nex {
  static const char *name() { return  "nex"; }
  static int Offset(){ return offsetof( struct tecw_t, nex ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct tecw_t, z ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[8];
};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct tecw_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[8];
};
struct xex {
  static const char *name() { return  "xex"; }
  static int Offset(){ return offsetof( struct tecw_t, xex ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[5];
};
struct zex {
  static const char *name() { return  "zex"; }
  static int Offset(){ return offsetof( struct tecw_t, zex ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[5];
};
struct dxex {
  static const char *name() { return  "dxex"; }
  static int Offset(){ return offsetof( struct tecw_t, dxex ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[5];
};
struct dzex {
  static const char *name() { return  "dzex"; }
  static int Offset(){ return offsetof( struct tecw_t, dzex ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[5];
};
struct nhplane {
  static const char *name() { return  "nhplane"; }
  static int Offset(){ return offsetof( struct tecw_t, nhplane ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[8];
};
struct cardw {
  static const char *name() { return  "cardw"; }
  static int Offset(){ return offsetof( struct tecw_t, cardw ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cardth {
  static const char *name() { return  "cardth"; }
  static int Offset(){ return offsetof( struct tecw_t, cardth ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct coolw {
  static const char *name() { return  "coolw"; }
  static int Offset(){ return offsetof( struct tecw_t, coolw ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct coolth {
  static const char *name() { return  "coolth"; }
  static int Offset(){ return offsetof( struct tecw_t, coolth ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cardoff {
  static const char *name() { return  "cardoff"; }
  static int Offset(){ return offsetof( struct tecw_t, cardoff ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cooloff {
  static const char *name() { return  "cooloff"; }
  static int Offset(){ return offsetof( struct tecw_t, cooloff ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slotw {
  static const char *name() { return  "slotw"; }
  static int Offset(){ return offsetof( struct tecw_t, slotw ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slotrad {
  static const char *name() { return  "slotrad"; }
  static int Offset(){ return offsetof( struct tecw_t, slotrad ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pipethk {
  static const char *name() { return  "pipethk"; }
  static int Offset(){ return offsetof( struct tecw_t, pipethk ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pipeht {
  static const char *name() { return  "pipeht"; }
  static int Offset(){ return offsetof( struct tecw_t, pipeht ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct manithk {
  static const char *name() { return  "manithk"; }
  static int Offset(){ return offsetof( struct tecw_t, manithk ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct maniwid {
  static const char *name() { return  "maniwid"; }
  static int Offset(){ return offsetof( struct tecw_t, maniwid ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct tan15 {
  static const char *name() { return  "tan15"; }
  static int Offset(){ return offsetof( struct tecw_t, tan15 ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct clearance {
  static const char *name() { return  "clearance"; }
  static int Offset(){ return offsetof( struct tecw_t, clearance ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct whlipthk {
  static const char *name() { return  "whlipthk"; }
  static int Offset(){ return offsetof( struct tecw_t, whlipthk ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct whlipwid {
  static const char *name() { return  "whlipwid"; }
  static int Offset(){ return offsetof( struct tecw_t, whlipwid ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct whblklen {
  static const char *name() { return  "whblklen"; }
  static int Offset(){ return offsetof( struct tecw_t, whblklen ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct whblkpos {
  static const char *name() { return  "whblkpos"; }
  static int Offset(){ return offsetof( struct tecw_t, whblkpos ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct whblkin {
  static const char *name() { return  "whblkin"; }
  static int Offset(){ return offsetof( struct tecw_t, whblkin ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct tecw_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)tecw_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct trov_t {
float sec;
float nhp[16];
float hx[16][9];
float offcardinout;
int _index;
};
 
   struct _trov_docum_ {
string sec;
string nhp;
string hx;
string offcardinout;
string _index;
};
 
    struct _trov_types_ {
  typedef float sec;
  typedef float nhp[16];
  typedef float hx[16][9];
  typedef float offcardinout;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct trov_info {
typedef trov_t Type;
static const char *name(){ return "trov_t"; }
struct sec {
  static const char *name() { return  "sec"; }
  static int Offset(){ return offsetof( struct trov_t, sec ); }
  static void* address(){ 
         long long iadd = (long long)trov_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nhp {
  static const char *name() { return  "nhp"; }
  static int Offset(){ return offsetof( struct trov_t, nhp ); }
  static void* address(){ 
         long long iadd = (long long)trov_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[16];
};
struct hx {
  static const char *name() { return  "hx"; }
  static int Offset(){ return offsetof( struct trov_t, hx ); }
  static void* address(){ 
         long long iadd = (long long)trov_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[16][9];
};
struct offcardinout {
  static const char *name() { return  "offcardinout"; }
  static int Offset(){ return offsetof( struct trov_t, offcardinout ); }
  static void* address(){ 
         long long iadd = (long long)trov_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct trov_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)trov_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct tprs_t {
float sec;
float nrow;
float pitch;
float width;
float super;
float rpads[40];
float npads[40];
int _index;
};
 
   struct _tprs_docum_ {
string sec;
string nrow;
string pitch;
string width;
string super;
string rpads;
string npads;
string _index;
};
 
    struct _tprs_types_ {
  typedef float sec;
  typedef float nrow;
  typedef float pitch;
  typedef float width;
  typedef float super;
  typedef float rpads[40];
  typedef float npads[40];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct tprs_info {
typedef tprs_t Type;
static const char *name(){ return "tprs_t"; }
struct sec {
  static const char *name() { return  "sec"; }
  static int Offset(){ return offsetof( struct tprs_t, sec ); }
  static void* address(){ 
         long long iadd = (long long)tprs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nrow {
  static const char *name() { return  "nrow"; }
  static int Offset(){ return offsetof( struct tprs_t, nrow ); }
  static void* address(){ 
         long long iadd = (long long)tprs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pitch {
  static const char *name() { return  "pitch"; }
  static int Offset(){ return offsetof( struct tprs_t, pitch ); }
  static void* address(){ 
         long long iadd = (long long)tprs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct width {
  static const char *name() { return  "width"; }
  static int Offset(){ return offsetof( struct tprs_t, width ); }
  static void* address(){ 
         long long iadd = (long long)tprs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct super {
  static const char *name() { return  "super"; }
  static int Offset(){ return offsetof( struct tprs_t, super ); }
  static void* address(){ 
         long long iadd = (long long)tprs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rpads {
  static const char *name() { return  "rpads"; }
  static int Offset(){ return offsetof( struct tprs_t, rpads ); }
  static void* address(){ 
         long long iadd = (long long)tprs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[40];
};
struct npads {
  static const char *name() { return  "npads"; }
  static int Offset(){ return offsetof( struct tprs_t, npads ); }
  static void* address(){ 
         long long iadd = (long long)tprs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[40];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct tprs_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)tprs_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct trdo_t {
float rdovthk;
float rdothk;
float rdolen;
float nrdobrd;
float rdoht[9];
int _index;
};
 
   struct _trdo_docum_ {
string rdovthk;
string rdothk;
string rdolen;
string nrdobrd;
string rdoht;
string _index;
};
 
    struct _trdo_types_ {
  typedef float rdovthk;
  typedef float rdothk;
  typedef float rdolen;
  typedef float nrdobrd;
  typedef float rdoht[9];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct trdo_info {
typedef trdo_t Type;
static const char *name(){ return "trdo_t"; }
struct rdovthk {
  static const char *name() { return  "rdovthk"; }
  static int Offset(){ return offsetof( struct trdo_t, rdovthk ); }
  static void* address(){ 
         long long iadd = (long long)trdo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rdothk {
  static const char *name() { return  "rdothk"; }
  static int Offset(){ return offsetof( struct trdo_t, rdothk ); }
  static void* address(){ 
         long long iadd = (long long)trdo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rdolen {
  static const char *name() { return  "rdolen"; }
  static int Offset(){ return offsetof( struct trdo_t, rdolen ); }
  static void* address(){ 
         long long iadd = (long long)trdo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nrdobrd {
  static const char *name() { return  "nrdobrd"; }
  static int Offset(){ return offsetof( struct trdo_t, nrdobrd ); }
  static void* address(){ 
         long long iadd = (long long)trdo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rdoht {
  static const char *name() { return  "rdoht"; }
  static int Offset(){ return offsetof( struct trdo_t, rdoht ); }
  static void* address(){ 
         long long iadd = (long long)trdo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[9];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct trdo_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)trdo_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- TPCE -- 
   ///@defgroup TPCE_doc 
   ///@class TPCE 
   ///@brief is the TPC envelope [TGeoVolume] 
   class TPCE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPCE() : AgBlock("TPCE","is the TPC envelope [TGeoVolume]"){ 
      }; 
      ~TPCE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TPGV -- 
   ///@defgroup TPGV_doc 
   ///@class TPGV 
   ///@brief is the Gas Volume placed in TPC [TGeoVolume] 
   class TPGV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPGV() : AgBlock("TPGV","is the Gas Volume placed in TPC [TGeoVolume]"){ 
      }; 
      ~TPGV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TPSS -- 
   ///@defgroup TPSS_doc 
   ///@class TPSS 
   ///@brief is a division of gas volume corresponding to a supersectors [TGeoVolume] 
   class TPSS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPSS() : AgBlock("TPSS","is a division of gas volume corresponding to a supersectors [TGeoVolume]"){ 
      }; 
      ~TPSS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TPAD -- 
   ///@defgroup TPAD_doc 
   ///@class TPAD 
   ///@brief is a real padrow with dimensions defined at positioning time [TGeoVolume] 
   class TPAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPAD() : AgBlock("TPAD","is a real padrow with dimensions defined at positioning time [TGeoVolume]"){ 
      }; 
      ~TPAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TIFC -- 
   ///@defgroup TIFC_doc 
   ///@class TIFC 
   ///@brief defines the Inner Field Cage placed in TPC [TGeoVolume] 
   class TIFC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TIFC() : AgBlock("TIFC","defines the Inner Field Cage placed in TPC [TGeoVolume]"){ 
      }; 
      ~TIFC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TINX -- 
   ///@defgroup TINX_doc 
   ///@class TINX 
   ///@brief is the inner nomex structure [TGeoVolume] 
   class TINX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TINX() : AgBlock("TINX","is the inner nomex structure [TGeoVolume]"){ 
      }; 
      ~TINX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TIKA -- 
   ///@defgroup TIKA_doc 
   ///@class TIKA 
   ///@brief is the kapton film of the inner field cage [TGeoVolume] 
   class TIKA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TIKA() : AgBlock("TIKA","is the kapton film of the inner field cage [TGeoVolume]"){ 
      }; 
      ~TIKA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TIAL -- 
   ///@defgroup TIAL_doc 
   ///@class TIAL 
   ///@brief is the inner Aluminum cylinder [TGeoVolume] 
   class TIAL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TIAL() : AgBlock("TIAL","is the inner Aluminum cylinder [TGeoVolume]"){ 
      }; 
      ~TIAL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TOFC -- 
   ///@defgroup TOFC_doc 
   ///@class TOFC 
   ///@brief defines outer field cage - fill it with insulating gas already [TGeoVolume] 
   class TOFC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TOFC() : AgBlock("TOFC","defines outer field cage - fill it with insulating gas already [TGeoVolume]"){ 
      }; 
      ~TOFC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TOFS -- 
   ///@defgroup TOFS_doc 
   ///@class TOFS 
   ///@brief is the Outer Field Cage structure [TGeoVolume] 
   class TOFS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TOFS() : AgBlock("TOFS","is the Outer Field Cage structure [TGeoVolume]"){ 
      }; 
      ~TOFS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TOKA -- 
   ///@defgroup TOKA_doc 
   ///@class TOKA 
   ///@brief is KAPTON layer [TGeoVolume] 
   class TOKA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TOKA() : AgBlock("TOKA","is KAPTON layer [TGeoVolume]"){ 
      }; 
      ~TOKA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TONX -- 
   ///@defgroup TONX_doc 
   ///@class TONX 
   ///@brief is Nomex support [TGeoVolume] 
   class TONX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TONX() : AgBlock("TONX","is Nomex support [TGeoVolume]"){ 
      }; 
      ~TONX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TOAD -- 
   ///@defgroup TOAD_doc 
   ///@class TOAD 
   ///@brief is Adhesive layer [TGeoVolume] 
   class TOAD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TOAD() : AgBlock("TOAD","is Adhesive layer [TGeoVolume]"){ 
      }; 
      ~TOAD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TOST -- 
   ///@defgroup TOST_doc 
   ///@class TOST 
   ///@brief is the Outer Field Cage Support [TGeoVolume] 
   class TOST : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TOST() : AgBlock("TOST","is the Outer Field Cage Support [TGeoVolume]"){ 
      }; 
      ~TOST(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TOHA -- 
   ///@defgroup TOHA_doc 
   ///@class TOHA 
   ///@brief is Honeycomb/Adhesive mixture [TGeoVolume] 
   class TOHA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TOHA() : AgBlock("TOHA","is Honeycomb/Adhesive mixture [TGeoVolume]"){ 
      }; 
      ~TOHA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TPCM -- 
   ///@defgroup TPCM_doc 
   ///@class TPCM 
   ///@brief is the Central Membrane placed in TPC [TGeoVolume] 
   class TPCM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPCM() : AgBlock("TPCM","is the Central Membrane placed in TPC [TGeoVolume]"){ 
      }; 
      ~TPCM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TPEA -- 
   ///@defgroup TPEA_doc 
   ///@class TPEA 
   ///@brief is one endcap placed in TPC [TGeoVolume] 
   class TPEA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPEA() : AgBlock("TPEA","is one endcap placed in TPC [TGeoVolume]"){ 
      }; 
      ~TPEA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TESS -- 
   ///@defgroup TESS_doc 
   ///@class TESS 
   ///@brief is a division of endcap volume corresponding to one supersector [TGeoVolume] 
   class TESS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TESS() : AgBlock("TESS","is a division of endcap volume corresponding to one supersector [TGeoVolume]"){ 
      }; 
      ~TESS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TSEC -- 
   ///@defgroup TSEC_doc 
   ///@class TSEC 
   ///@brief is a supersector containing Al sector, PCB and MWC volume [TGeoVolume] 
   class TSEC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TSEC() : AgBlock("TSEC","is a supersector containing Al sector, PCB and MWC volume [TGeoVolume]"){ 
      }; 
      ~TSEC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TMWC -- 
   ///@defgroup TMWC_doc 
   ///@class TMWC 
   ///@brief is a wire chamber volume with both gated and sensitive volumes [TGeoVolume] 
   class TMWC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TMWC() : AgBlock("TMWC","is a wire chamber volume with both gated and sensitive volumes [TGeoVolume]"){ 
      }; 
      ~TMWC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TMEA -- 
   ///@defgroup TMEA_doc 
   ///@class TMEA 
   ///@brief is a double sensitive layer around gating grid [TGeoVolume] 
   class TMEA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TMEA() : AgBlock("TMEA","is a double sensitive layer around gating grid [TGeoVolume]"){ 
      }; 
      ~TMEA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TMSE -- 
   ///@defgroup TMSE_doc 
   ///@class TMSE 
   ///@brief is a single sensitive volume [TGeoVolume] 
   class TMSE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TMSE() : AgBlock("TMSE","is a single sensitive volume [TGeoVolume]"){ 
      }; 
      ~TMSE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- THOL -- 
   ///@defgroup THOL_doc 
   ///@class THOL 
   ///@brief is part of a hole for PC boards [TGeoVolume] 
   class THOL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      THOL() : AgBlock("THOL","is part of a hole for PC boards [TGeoVolume]"){ 
      }; 
      ~THOL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- THRA -- 
   ///@defgroup THRA_doc 
   ///@class THRA 
   ///@brief is part of a hole for PC boards [TGeoVolume] 
   class THRA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      THRA() : AgBlock("THRA","is part of a hole for PC boards [TGeoVolume]"){ 
      }; 
      ~THRA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- THLA -- 
   ///@defgroup THLA_doc 
   ///@class THLA 
   ///@brief is part of a hole for PC boards [TGeoVolume] 
   class THLA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      THLA() : AgBlock("THLA","is part of a hole for PC boards [TGeoVolume]"){ 
      }; 
      ~THLA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TIAG -- 
   ///@defgroup TIAG_doc 
   ///@class TIAG 
   ///@brief is an air gap in inner sector aluminum structure [TGeoVolume] 
   class TIAG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TIAG() : AgBlock("TIAG","is an air gap in inner sector aluminum structure [TGeoVolume]"){ 
      }; 
      ~TIAG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TOAE -- 
   ///@defgroup TOAE_doc 
   ///@class TOAE 
   ///@brief is extra aluminum supports in the air opennings [TGeoVolume] 
   class TOAE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TOAE() : AgBlock("TOAE","is extra aluminum supports in the air opennings [TGeoVolume]"){ 
      }; 
      ~TOAE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TCEX -- 
   ///@defgroup TCEX_doc 
   ///@class TCEX 
   ///@brief is part of the G10 for the PC boards [TGeoVolume] 
   class TCEX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TCEX() : AgBlock("TCEX","is part of the G10 for the PC boards [TGeoVolume]"){ 
      }; 
      ~TCEX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TAEC -- 
   ///@defgroup TAEC_doc 
   ///@class TAEC 
   ///@brief is part of the heat shield for the PC boards [TGeoVolume] 
   class TAEC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TAEC() : AgBlock("TAEC","is part of the heat shield for the PC boards [TGeoVolume]"){ 
      }; 
      ~TAEC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TPCW -- 
   ///@defgroup TPCW_doc 
   ///@class TPCW 
   ///@brief is the TPC supporting endcap Wheel [TGeoVolume] 
   class TPCW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPCW() : AgBlock("TPCW","is the TPC supporting endcap Wheel [TGeoVolume]"){ 
      }; 
      ~TPCW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TWSS -- 
   ///@defgroup TWSS_doc 
   ///@class TWSS 
   ///@brief is a division of wheel corresponding to supersectors [TGeoVolume] 
   class TWSS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TWSS() : AgBlock("TWSS","is a division of wheel corresponding to supersectors [TGeoVolume]"){ 
      }; 
      ~TWSS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TWGI -- 
   ///@defgroup TWGI_doc 
   ///@class TWGI 
   ///@brief is the Inner air gap in Wheel [TGeoVolume] 
   class TWGI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TWGI() : AgBlock("TWGI","is the Inner air gap in Wheel [TGeoVolume]"){ 
      }; 
      ~TWGI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TWGC -- 
   ///@defgroup TWGC_doc 
   ///@class TWGC 
   ///@brief is the larger Inner air gap in Wheel [TGeoVolume] 
   class TWGC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TWGC() : AgBlock("TWGC","is the larger Inner air gap in Wheel [TGeoVolume]"){ 
      }; 
      ~TWGC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TWGB -- 
   ///@defgroup TWGB_doc 
   ///@class TWGB 
   ///@brief is added alum blocksin Wheel [TGeoVolume] 
   class TWGB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TWGB() : AgBlock("TWGB","is added alum blocksin Wheel [TGeoVolume]"){ 
      }; 
      ~TWGB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TMAN -- 
   ///@defgroup TMAN_doc 
   ///@class TMAN 
   ///@brief is aluminum water manifold [TGeoVolume] 
   class TMAN : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TMAN() : AgBlock("TMAN","is aluminum water manifold [TGeoVolume]"){ 
      }; 
      ~TMAN(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TPIP -- 
   ///@defgroup TPIP_doc 
   ///@class TPIP 
   ///@brief is a water pipe there are lots per sect [TGeoVolume] 
   class TPIP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TPIP() : AgBlock("TPIP","is a water pipe there are lots per sect [TGeoVolume]"){ 
      }; 
      ~TPIP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TCRX -- 
   ///@defgroup TCRX_doc 
   ///@class TCRX 
   ///@brief is part of the G10 for the PC boards [TGeoVolume] 
   class TCRX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TCRX() : AgBlock("TCRX","is part of the G10 for the PC boards [TGeoVolume]"){ 
      }; 
      ~TCRX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TALC -- 
   ///@defgroup TALC_doc 
   ///@class TALC 
   ///@brief is part of the heat shield for the PC boards [TGeoVolume] 
   class TALC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TALC() : AgBlock("TALC","is part of the heat shield for the PC boards [TGeoVolume]"){ 
      }; 
      ~TALC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TRDV -- 
   ///@defgroup TRDV_doc 
   ///@class TRDV 
   ///@brief is the RDO board volume [TGeoVolume] 
   class TRDV : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TRDV() : AgBlock("TRDV","is the RDO board volume [TGeoVolume]"){ 
      }; 
      ~TRDV(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TRDS -- 
   ///@defgroup TRDS_doc 
   ///@class TRDS 
   ///@brief is a division of rdo board volume corresponding to one supersector [TGeoVolume] 
   class TRDS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TRDS() : AgBlock("TRDS","is a division of rdo board volume corresponding to one supersector [TGeoVolume]"){ 
      }; 
      ~TRDS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- TRDC -- 
   ///@defgroup TRDC_doc 
   ///@class TRDC 
   ///@brief is an RDO Card [TGeoVolume] 
   class TRDC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TRDC() : AgBlock("TRDC","is an RDO Card [TGeoVolume]"){ 
      }; 
      ~TRDC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class TpceGeo1 
   /// \brief   is the TPC system in GSTAR  
   class TpceGeo1 : public AgModule 
   { 
      public: 
      TpceGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~TpceGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace TpceGeo1 
#endif // __TpceGeo1__ 
