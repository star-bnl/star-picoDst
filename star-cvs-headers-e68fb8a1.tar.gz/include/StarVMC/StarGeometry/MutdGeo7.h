#ifndef __MutdGeo7__ 
#define __MutdGeo7__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace MUTDGEO7 // $NMSPC 
{ 
   struct mtdg_t {
float version;
float config;
int _index;
};
 
   struct _mtdg_docum_ {
string version;
string config;
string _index;
};
 
    struct _mtdg_types_ {
  typedef float version;
  typedef float config;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mtdg_info {
typedef mtdg_t Type;
static const char *name(){ return "mtdg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct mtdg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct config {
  static const char *name() { return  "config"; }
  static int Offset(){ return offsetof( struct mtdg_t, config ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mtdg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct mtdd_t {
float version;
float rmin;
float rmax;
float ri[30];
float rirun15[30];
float yshift08;
float yshift24;
float dzmother;
float backlegr;
float bemcelectboxdx;
float bemcelectboxdy;
float bemcelectboxdz3;
float bemcelectboxdz5;
float rgap;
float mtdmotherdx;
float mtdmotherdy;
float mtdmotherdz3;
float mtdmotherdz5;
float mtdtraydx;
float mtdtraydy;
float mtdtraydz;
float mtdbplate;
float mtdtplate;
float mtdigstackdy;
float mtdigstackdz;
float mtdigstackngaps;
float mtdigstackgapthick;
float mtdigstackthinglassthick;
int _index;
};
 
   struct _mtdd_docum_ {
string version;
string rmin;
string rmax;
string ri;
string rirun15;
string yshift08;
string yshift24;
string dzmother;
string backlegr;
string bemcelectboxdx;
string bemcelectboxdy;
string bemcelectboxdz3;
string bemcelectboxdz5;
string rgap;
string mtdmotherdx;
string mtdmotherdy;
string mtdmotherdz3;
string mtdmotherdz5;
string mtdtraydx;
string mtdtraydy;
string mtdtraydz;
string mtdbplate;
string mtdtplate;
string mtdigstackdy;
string mtdigstackdz;
string mtdigstackngaps;
string mtdigstackgapthick;
string mtdigstackthinglassthick;
string _index;
};
 
    struct _mtdd_types_ {
  typedef float version;
  typedef float rmin;
  typedef float rmax;
  typedef float ri[30];
  typedef float rirun15[30];
  typedef float yshift08;
  typedef float yshift24;
  typedef float dzmother;
  typedef float backlegr;
  typedef float bemcelectboxdx;
  typedef float bemcelectboxdy;
  typedef float bemcelectboxdz3;
  typedef float bemcelectboxdz5;
  typedef float rgap;
  typedef float mtdmotherdx;
  typedef float mtdmotherdy;
  typedef float mtdmotherdz3;
  typedef float mtdmotherdz5;
  typedef float mtdtraydx;
  typedef float mtdtraydy;
  typedef float mtdtraydz;
  typedef float mtdbplate;
  typedef float mtdtplate;
  typedef float mtdigstackdy;
  typedef float mtdigstackdz;
  typedef float mtdigstackngaps;
  typedef float mtdigstackgapthick;
  typedef float mtdigstackthinglassthick;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mtdd_info {
typedef mtdd_t Type;
static const char *name(){ return "mtdd_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct mtdd_t, version ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct mtdd_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct mtdd_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ri {
  static const char *name() { return  "ri"; }
  static int Offset(){ return offsetof( struct mtdd_t, ri ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[30];
};
struct rirun15 {
  static const char *name() { return  "rirun15"; }
  static int Offset(){ return offsetof( struct mtdd_t, rirun15 ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[30];
};
struct yshift08 {
  static const char *name() { return  "yshift08"; }
  static int Offset(){ return offsetof( struct mtdd_t, yshift08 ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yshift24 {
  static const char *name() { return  "yshift24"; }
  static int Offset(){ return offsetof( struct mtdd_t, yshift24 ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzmother {
  static const char *name() { return  "dzmother"; }
  static int Offset(){ return offsetof( struct mtdd_t, dzmother ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct backlegr {
  static const char *name() { return  "backlegr"; }
  static int Offset(){ return offsetof( struct mtdd_t, backlegr ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bemcelectboxdx {
  static const char *name() { return  "bemcelectboxdx"; }
  static int Offset(){ return offsetof( struct mtdd_t, bemcelectboxdx ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bemcelectboxdy {
  static const char *name() { return  "bemcelectboxdy"; }
  static int Offset(){ return offsetof( struct mtdd_t, bemcelectboxdy ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bemcelectboxdz3 {
  static const char *name() { return  "bemcelectboxdz3"; }
  static int Offset(){ return offsetof( struct mtdd_t, bemcelectboxdz3 ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct bemcelectboxdz5 {
  static const char *name() { return  "bemcelectboxdz5"; }
  static int Offset(){ return offsetof( struct mtdd_t, bemcelectboxdz5 ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rgap {
  static const char *name() { return  "rgap"; }
  static int Offset(){ return offsetof( struct mtdd_t, rgap ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdmotherdx {
  static const char *name() { return  "mtdmotherdx"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdmotherdx ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdmotherdy {
  static const char *name() { return  "mtdmotherdy"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdmotherdy ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdmotherdz3 {
  static const char *name() { return  "mtdmotherdz3"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdmotherdz3 ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdmotherdz5 {
  static const char *name() { return  "mtdmotherdz5"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdmotherdz5 ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdtraydx {
  static const char *name() { return  "mtdtraydx"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdtraydx ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdtraydy {
  static const char *name() { return  "mtdtraydy"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdtraydy ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdtraydz {
  static const char *name() { return  "mtdtraydz"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdtraydz ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdbplate {
  static const char *name() { return  "mtdbplate"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdbplate ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdtplate {
  static const char *name() { return  "mtdtplate"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdtplate ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdigstackdy {
  static const char *name() { return  "mtdigstackdy"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdigstackdy ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdigstackdz {
  static const char *name() { return  "mtdigstackdz"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdigstackdz ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdigstackngaps {
  static const char *name() { return  "mtdigstackngaps"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdigstackngaps ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdigstackgapthick {
  static const char *name() { return  "mtdigstackgapthick"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdigstackgapthick ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mtdigstackthinglassthick {
  static const char *name() { return  "mtdigstackthinglassthick"; }
  static int Offset(){ return offsetof( struct mtdd_t, mtdigstackthinglassthick ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mtdd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mtdd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- MUTD -- 
   ///@defgroup MUTD_doc 
   ///@class MUTD 
   ///@brief is the muon detector mother [TGeoVolume] 
   class MUTD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MUTD() : AgBlock("MUTD","is the muon detector mother [TGeoVolume]"){ 
      }; 
      ~MUTD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MTTG -- 
   ///@defgroup MTTG_doc 
   ///@class MTTG 
   ///@brief Is the MTD tray group [TGeoVolume] 
   class MTTG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MTTG() : AgBlock("MTTG","Is the MTD tray group [TGeoVolume]"){ 
      }; 
      ~MTTG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MTRA -- 
   ///@defgroup MTRA_doc 
   ///@class MTRA 
   ///@brief is an MTD11-style tray [TGeoVolume] 
   class MTRA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MTRA() : AgBlock("MTRA","is an MTD11-style tray [TGeoVolume]"){ 
      }; 
      ~MTRA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MIGS -- 
   ///@defgroup MIGS_doc 
   ///@class MIGS 
   ///@brief is the inner glass stack [TGeoVolume] 
   class MIGS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MIGS() : AgBlock("MIGS","is the inner glass stack [TGeoVolume]"){ 
      }; 
      ~MIGS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MIGG -- 
   ///@defgroup MIGG_doc 
   ///@class MIGG 
   ///@brief is a single gas gap [TGeoVolume] 
   class MIGG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MIGG() : AgBlock("MIGG","is a single gas gap [TGeoVolume]"){ 
      }; 
      ~MIGG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MTBP -- 
   ///@defgroup MTBP_doc 
   ///@class MTBP 
   ///@brief is the MTD11 bottom plate [TGeoVolume] 
   class MTBP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MTBP() : AgBlock("MTBP","is the MTD11 bottom plate [TGeoVolume]"){ 
      }; 
      ~MTBP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MTTP -- 
   ///@defgroup MTTP_doc 
   ///@class MTTP 
   ///@brief is the MTD11 top plate [TGeoVolume] 
   class MTTP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MTTP() : AgBlock("MTTP","is the MTD11 top plate [TGeoVolume]"){ 
      }; 
      ~MTTP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MCHL -- 
   ///@defgroup MCHL_doc 
   ///@class MCHL 
   ///@brief is the MTD11 architectural channel long side [TGeoVolume] 
   class MCHL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MCHL() : AgBlock("MCHL","is the MTD11 architectural channel long side [TGeoVolume]"){ 
      }; 
      ~MCHL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MCAL -- 
   ///@defgroup MCAL_doc 
   ///@class MCAL 
   ///@brief is the air in the MTD11 architectural channel long side [TGeoVolume] 
   class MCAL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MCAL() : AgBlock("MCAL","is the air in the MTD11 architectural channel long side [TGeoVolume]"){ 
      }; 
      ~MCAL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MCHS -- 
   ///@defgroup MCHS_doc 
   ///@class MCHS 
   ///@brief is the MTD11 architectural channel short side [TGeoVolume] 
   class MCHS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MCHS() : AgBlock("MCHS","is the MTD11 architectural channel short side [TGeoVolume]"){ 
      }; 
      ~MCHS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MCAS -- 
   ///@defgroup MCAS_doc 
   ///@class MCAS 
   ///@brief is the air in the MTD11 architectural channel short side [TGeoVolume] 
   class MCAS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MCAS() : AgBlock("MCAS","is the air in the MTD11 architectural channel short side [TGeoVolume]"){ 
      }; 
      ~MCAS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class MutdGeo7 
   /// \brief  is the geometry of the STAR MTD  
   class MutdGeo7 : public AgModule 
   { 
      public: 
      MutdGeo7(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~MutdGeo7(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace MutdGeo7 
#endif // __MutdGeo7__ 
