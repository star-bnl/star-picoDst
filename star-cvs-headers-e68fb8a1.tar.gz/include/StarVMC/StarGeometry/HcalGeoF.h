#ifndef __HcalGeoF__ 
#define __HcalGeoF__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace HCALGEOF // $NMSPC 
{ 
   struct mcdt_t {
float version;
float x;
float y;
float z;
float dx;
float dy;
float dz;
int _index;
};
 
   struct _mcdt_docum_ {
string version;
string x;
string y;
string z;
string dx;
string dy;
string dz;
string _index;
};
 
    struct _mcdt_types_ {
  typedef float version;
  typedef float x;
  typedef float y;
  typedef float z;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mcdt_info {
typedef mcdt_t Type;
static const char *name(){ return "mcdt_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct mcdt_t, version ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct mcdt_t, x ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct mcdt_t, y ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct mcdt_t, z ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct mcdt_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct mcdt_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct mcdt_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mcdt_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct towr_t {
float version;
float dx;
float dy;
float dz;
float ntowerx;
float ntowery;
int _index;
};
 
   struct _towr_docum_ {
string version;
string dx;
string dy;
string dz;
string ntowerx;
string ntowery;
string _index;
};
 
    struct _towr_types_ {
  typedef float version;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef float ntowerx;
  typedef float ntowery;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct towr_info {
typedef towr_t Type;
static const char *name(){ return "towr_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct towr_t, version ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct towr_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct towr_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct towr_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ntowerx {
  static const char *name() { return  "ntowerx"; }
  static int Offset(){ return offsetof( struct towr_t, ntowerx ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ntowery {
  static const char *name() { return  "ntowery"; }
  static int Offset(){ return offsetof( struct towr_t, ntowery ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct towr_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct cell_t {
float version;
float dx;
float dy;
float dz;
float ncellx;
float ncelly;
float nfiberxl;
float nfiberyl;
float nfiberxs;
float nfiberys;
int _index;
};
 
   struct _cell_docum_ {
string version;
string dx;
string dy;
string dz;
string ncellx;
string ncelly;
string nfiberxl;
string nfiberyl;
string nfiberxs;
string nfiberys;
string _index;
};
 
    struct _cell_types_ {
  typedef float version;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef float ncellx;
  typedef float ncelly;
  typedef float nfiberxl;
  typedef float nfiberyl;
  typedef float nfiberxs;
  typedef float nfiberys;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct cell_info {
typedef cell_t Type;
static const char *name(){ return "cell_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct cell_t, version ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct cell_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct cell_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct cell_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ncellx {
  static const char *name() { return  "ncellx"; }
  static int Offset(){ return offsetof( struct cell_t, ncellx ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ncelly {
  static const char *name() { return  "ncelly"; }
  static int Offset(){ return offsetof( struct cell_t, ncelly ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberxl {
  static const char *name() { return  "nfiberxl"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberxl ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberyl {
  static const char *name() { return  "nfiberyl"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberyl ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberxs {
  static const char *name() { return  "nfiberxs"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberxs ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberys {
  static const char *name() { return  "nfiberys"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberys ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct cell_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fibr_t {
float version;
float rmin;
float rmax;
float dz;
float startx1;
float starty1;
float startx2;
float starty2;
float stepx;
float stepy;
int _index;
};
 
   struct _fibr_docum_ {
string version;
string rmin;
string rmax;
string dz;
string startx1;
string starty1;
string startx2;
string starty2;
string stepx;
string stepy;
string _index;
};
 
    struct _fibr_types_ {
  typedef float version;
  typedef float rmin;
  typedef float rmax;
  typedef float dz;
  typedef float startx1;
  typedef float starty1;
  typedef float startx2;
  typedef float starty2;
  typedef float stepx;
  typedef float stepy;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fibr_info {
typedef fibr_t Type;
static const char *name(){ return "fibr_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct fibr_t, version ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct fibr_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct fibr_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct fibr_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct startx1 {
  static const char *name() { return  "startx1"; }
  static int Offset(){ return offsetof( struct fibr_t, startx1 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct starty1 {
  static const char *name() { return  "starty1"; }
  static int Offset(){ return offsetof( struct fibr_t, starty1 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct startx2 {
  static const char *name() { return  "startx2"; }
  static int Offset(){ return offsetof( struct fibr_t, startx2 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct starty2 {
  static const char *name() { return  "starty2"; }
  static int Offset(){ return offsetof( struct fibr_t, starty2 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stepx {
  static const char *name() { return  "stepx"; }
  static int Offset(){ return offsetof( struct fibr_t, stepx ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stepy {
  static const char *name() { return  "stepy"; }
  static int Offset(){ return offsetof( struct fibr_t, stepy ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fibr_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct lgla_t {
float version;
float x;
float y;
float z;
float dx;
float dy;
float dz;
float density;
float radlen;
float pbcont;
float critene;
float molierer;
int _index;
};
 
   struct _lgla_docum_ {
string version;
string x;
string y;
string z;
string dx;
string dy;
string dz;
string density;
string radlen;
string pbcont;
string critene;
string molierer;
string _index;
};
 
    struct _lgla_types_ {
  typedef float version;
  typedef float x;
  typedef float y;
  typedef float z;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef float density;
  typedef float radlen;
  typedef float pbcont;
  typedef float critene;
  typedef float molierer;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct lgla_info {
typedef lgla_t Type;
static const char *name(){ return "lgla_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct lgla_t, version ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct lgla_t, x ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct lgla_t, y ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct lgla_t, z ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct lgla_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct lgla_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct lgla_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct density {
  static const char *name() { return  "density"; }
  static int Offset(){ return offsetof( struct lgla_t, density ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct radlen {
  static const char *name() { return  "radlen"; }
  static int Offset(){ return offsetof( struct lgla_t, radlen ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pbcont {
  static const char *name() { return  "pbcont"; }
  static int Offset(){ return offsetof( struct lgla_t, pbcont ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct critene {
  static const char *name() { return  "critene"; }
  static int Offset(){ return offsetof( struct lgla_t, critene ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct molierer {
  static const char *name() { return  "molierer"; }
  static int Offset(){ return offsetof( struct lgla_t, molierer ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct lgla_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)lgla_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct trap_t {
float version;
float xf;
float yf;
float zf;
float xb;
float yb;
float zb;
float dx1;
float dx2;
float dy;
float dz;
int _index;
};
 
   struct _trap_docum_ {
string version;
string xf;
string yf;
string zf;
string xb;
string yb;
string zb;
string dx1;
string dx2;
string dy;
string dz;
string _index;
};
 
    struct _trap_types_ {
  typedef float version;
  typedef float xf;
  typedef float yf;
  typedef float zf;
  typedef float xb;
  typedef float yb;
  typedef float zb;
  typedef float dx1;
  typedef float dx2;
  typedef float dy;
  typedef float dz;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct trap_info {
typedef trap_t Type;
static const char *name(){ return "trap_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct trap_t, version ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xf {
  static const char *name() { return  "xf"; }
  static int Offset(){ return offsetof( struct trap_t, xf ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yf {
  static const char *name() { return  "yf"; }
  static int Offset(){ return offsetof( struct trap_t, yf ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zf {
  static const char *name() { return  "zf"; }
  static int Offset(){ return offsetof( struct trap_t, zf ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xb {
  static const char *name() { return  "xb"; }
  static int Offset(){ return offsetof( struct trap_t, xb ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yb {
  static const char *name() { return  "yb"; }
  static int Offset(){ return offsetof( struct trap_t, yb ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zb {
  static const char *name() { return  "zb"; }
  static int Offset(){ return offsetof( struct trap_t, zb ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx1 {
  static const char *name() { return  "dx1"; }
  static int Offset(){ return offsetof( struct trap_t, dx1 ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx2 {
  static const char *name() { return  "dx2"; }
  static int Offset(){ return offsetof( struct trap_t, dx2 ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct trap_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct trap_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct trap_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)trap_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- HCMO -- 
   ///@defgroup HCMO_doc 
   ///@class HCMO 
   ///@brief Mother Calorimeter [TGeoVolume] 
   class HCMO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCMO() : AgBlock("HCMO","Mother Calorimeter [TGeoVolume]"){ 
      }; 
      ~HCMO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HTWR -- 
   ///@defgroup HTWR_doc 
   ///@class HTWR 
   ///@brief Towrs  of Calorimeter [TGeoVolume] 
   class HTWR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HTWR() : AgBlock("HTWR","Towrs  of Calorimeter [TGeoVolume]"){ 
      }; 
      ~HTWR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCES -- 
   ///@defgroup HCES_doc 
   ///@class HCES 
   ///@brief 3*3 cell in tower, HCES has 15*15 fibers [TGeoVolume] 
   class HCES : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCES() : AgBlock("HCES","3*3 cell in tower, HCES has 15*15 fibers [TGeoVolume]"){ 
      }; 
      ~HCES(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCEL -- 
   ///@defgroup HCEL_doc 
   ///@class HCEL 
   ///@brief 3*3 cell in tower, HCES has 16*16 fibers [TGeoVolume] 
   class HCEL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCEL() : AgBlock("HCEL","3*3 cell in tower, HCES has 16*16 fibers [TGeoVolume]"){ 
      }; 
      ~HCEL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCSX -- 
   ///@defgroup HCSX_doc 
   ///@class HCSX 
   ///@brief 3*3 cell in tower x divisions [TGeoVolume] 
   class HCSX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCSX() : AgBlock("HCSX","3*3 cell in tower x divisions [TGeoVolume]"){ 
      }; 
      ~HCSX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCSY -- 
   ///@defgroup HCSY_doc 
   ///@class HCSY 
   ///@brief 3*3 cell in tower y divisions [TGeoVolume] 
   class HCSY : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCSY() : AgBlock("HCSY","3*3 cell in tower y divisions [TGeoVolume]"){ 
      }; 
      ~HCSY(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCLX -- 
   ///@defgroup HCLX_doc 
   ///@class HCLX 
   ///@brief 3*3 cell in tower x divisions [TGeoVolume] 
   class HCLX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCLX() : AgBlock("HCLX","3*3 cell in tower x divisions [TGeoVolume]"){ 
      }; 
      ~HCLX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCLY -- 
   ///@defgroup HCLY_doc 
   ///@class HCLY 
   ///@brief 3*3 cell in tower y divisions [TGeoVolume] 
   class HCLY : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCLY() : AgBlock("HCLY","3*3 cell in tower y divisions [TGeoVolume]"){ 
      }; 
      ~HCLY(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HFIB -- 
   ///@defgroup HFIB_doc 
   ///@class HFIB 
   ///@brief fiber in cells [TGeoVolume] 
   class HFIB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HFIB() : AgBlock("HFIB","fiber in cells [TGeoVolume]"){ 
      }; 
      ~HFIB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HFIC -- 
   ///@defgroup HFIC_doc 
   ///@class HFIC 
   ///@brief fiber in cells [TGeoVolume] 
   class HFIC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HFIC() : AgBlock("HFIC","fiber in cells [TGeoVolume]"){ 
      }; 
      ~HFIC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- LEDG -- 
   ///@defgroup LEDG_doc 
   ///@class LEDG 
   ///@brief Lead glass [TGeoVolume] 
   class LEDG : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      LEDG() : AgBlock("LEDG","Lead glass [TGeoVolume]"){ 
      }; 
      ~LEDG(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BBCF -- 
   ///@defgroup BBCF_doc 
   ///@class BBCF 
   ///@brief Beam Counter front [TGeoVolume] 
   class BBCF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BBCF() : AgBlock("BBCF","Beam Counter front [TGeoVolume]"){ 
      }; 
      ~BBCF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- BBCB -- 
   ///@defgroup BBCB_doc 
   ///@class BBCB 
   ///@brief Beam Counter front [TGeoVolume] 
   class BBCB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      BBCB() : AgBlock("BBCB","Beam Counter front [TGeoVolume]"){ 
      }; 
      ~BBCB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class HcalGeoF 
   /// \brief HCAL at FermiTBF 
   class HcalGeoF : public AgModule 
   { 
      public: 
      HcalGeoF(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~HcalGeoF(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace HcalGeoF 
#endif // __HcalGeoF__ 
