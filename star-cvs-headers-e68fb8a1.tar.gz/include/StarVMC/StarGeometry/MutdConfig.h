#ifndef __MUTD_CONFIG__ 
#define __MUTD_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/MutdGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/MutdGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/MutdGeo3.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/MutdGeo4.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/MutdGeo5.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/MutdGeo7.h" 
namespace MUTD { //
struct MUTDof {
  static const char *name()    { return "MUTDof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "MutdGeo"; }
  static       bool  list();
  typedef MUTDGEO::MutdGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD01 {
  static const char *name()    { return "MUTD01"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo"; }
  static       bool  list();
  typedef MUTDGEO::MutdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD02 {
  static const char *name()    { return "MUTD02"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo2"; }
  static       bool  list();
  typedef MUTDGEO2::MutdGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD03 {
  static const char *name()    { return "MUTD03"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo3"; }
  static       bool  list();
  typedef MUTDGEO3::MutdGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD04 {
  static const char *name()    { return "MUTD04"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo4"; }
  static       bool  list();
  typedef MUTDGEO4::MutdGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD05 {
  static const char *name()    { return "MUTD05"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo4"; }
  static       bool  list();
  typedef MUTDGEO4::MutdGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD12 {
  static const char *name()    { return "MUTD12"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo4"; }
  static       bool  list();
  typedef MUTDGEO4::MutdGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD13 {
  static const char *name()    { return "MUTD13"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo4"; }
  static       bool  list();
  typedef MUTDGEO4::MutdGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD14 {
  static const char *name()    { return "MUTD14"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo5"; }
  static       bool  list();
  typedef MUTDGEO5::MutdGeo5 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD15 {
  static const char *name()    { return "MUTD15"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo7"; }
  static       bool  list();
  typedef MUTDGEO7::MutdGeo7 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace MUTD { //
struct MUTD16 {
  static const char *name()    { return "MUTD16"; }
  static const char *comment() { return "Muon Telescope"; }
  static const char *module()  { return "MutdGeo7"; }
  static       bool  list();
  typedef MUTDGEO7::MutdGeo7 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
