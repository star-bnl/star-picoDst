#ifndef __DTUB_CONFIG__ 
#define __DTUB_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/DtubGeo1.h" 
namespace DTUB { //
struct DTUBof {
  static const char *name()    { return "DTUBof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "DtubGeo1"; }
  static       bool  list();
  typedef DTUBGEO1::DtubGeo1 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace DTUB { //
struct DTUB01 {
  static const char *name()    { return "DTUB01"; }
  static const char *comment() { return "Pixel D-tube"; }
  static const char *module()  { return "DtubGeo1"; }
  static       bool  list();
  typedef DTUBGEO1::DtubGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
