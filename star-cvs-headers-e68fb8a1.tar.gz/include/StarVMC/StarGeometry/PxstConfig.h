#ifndef __PXST_CONFIG__ 
#define __PXST_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/PxstGeo1.h" 
namespace PXST { //
struct PXSTof {
  static const char *name()    { return "PXSTof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "PxstGeo1"; }
  static       bool  list();
  typedef PXSTGEO1::PxstGeo1 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace PXST { //
struct PXST01 {
  static const char *name()    { return "PXST01"; }
  static const char *comment() { return "Pixel D-tube"; }
  static const char *module()  { return "PxstGeo1"; }
  static       bool  list();
  typedef PXSTGEO1::PxstGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
