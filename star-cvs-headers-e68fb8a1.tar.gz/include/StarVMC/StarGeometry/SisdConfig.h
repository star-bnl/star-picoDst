#ifndef __SISD_CONFIG__ 
#define __SISD_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SisdGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SisdGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SisdGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SisdGeo3.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SisdGeo4.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SisdGeo5.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SisdGeo6.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SisdGeo7.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/SisdGeo7a.h" 
namespace SISD { //
struct SISDof {
  static const char *name()    { return "SISDof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "SisdGeo7"; }
  static       bool  list();
  typedef SISDGEO7::SisdGeo7 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD02 {
  static const char *name()    { return "SISD02"; }
  static const char *comment() { return "version 0"; }
  static const char *module()  { return "SisdGeo"; }
  static       bool  list();
  typedef SISDGEO::SisdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD12 {
  static const char *name()    { return "SISD12"; }
  static const char *comment() { return "version 1"; }
  static const char *module()  { return "SisdGeo1"; }
  static       bool  list();
  typedef SISDGEO1::SisdGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD22 {
  static const char *name()    { return "SISD22"; }
  static const char *comment() { return "version 2"; }
  static const char *module()  { return "SisdGeo2"; }
  static       bool  list();
  typedef SISDGEO2::SisdGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD23 {
  static const char *name()    { return "SISD23"; }
  static const char *comment() { return "version 2"; }
  static const char *module()  { return "SisdGeo2"; }
  static       bool  list();
  typedef SISDGEO2::SisdGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD24 {
  static const char *name()    { return "SISD24"; }
  static const char *comment() { return "version 2"; }
  static const char *module()  { return "SisdGeo2"; }
  static       bool  list();
  typedef SISDGEO2::SisdGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD35 {
  static const char *name()    { return "SISD35"; }
  static const char *comment() { return "version 3"; }
  static const char *module()  { return "SisdGeo3"; }
  static       bool  list();
  typedef SISDGEO3::SisdGeo3 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD55 {
  static const char *name()    { return "SISD55"; }
  static const char *comment() { return "default to version 6"; }
  static const char *module()  { return "SisdGeo6"; }
  static       bool  list();
  typedef SISDGEO6::SisdGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD65 {
  static const char *name()    { return "SISD65"; }
  static const char *comment() { return "default to version 6"; }
  static const char *module()  { return "SisdGeo6"; }
  static       bool  list();
  typedef SISDGEO6::SisdGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD75 {
  static const char *name()    { return "SISD75"; }
  static const char *comment() { return "default to version 6"; }
  static const char *module()  { return "SisdGeo6"; }
  static       bool  list();
  typedef SISDGEO6::SisdGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD85 {
  static const char *name()    { return "SISD85"; }
  static const char *comment() { return "y2014 configuration"; }
  static const char *module()  { return "SisdGeo7a"; }
  static       bool  list();
  typedef SISDGEO7A::SisdGeo7a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SISD { //
struct SISD85a {
  static const char *name()    { return "SISD85a"; }
  static const char *comment() { return "y2014 configuration"; }
  static const char *module()  { return "SisdGeo7a"; }
  static       bool  list();
  typedef SISDGEO7A::SisdGeo7a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
