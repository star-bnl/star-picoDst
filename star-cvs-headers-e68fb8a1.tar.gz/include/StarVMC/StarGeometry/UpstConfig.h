#ifndef __UPST_CONFIG__ 
#define __UPST_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/UpstGeo.h" 
namespace UPST { //
struct UPSTof {
  static const char *name()    { return "UPSTof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "UpstGeo"; }
  static       bool  list();
  typedef UPSTGEO::UpstGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace UPST { //
struct UPSTon {
  static const char *name()    { return "UPSTon"; }
  static const char *comment() { return "Upstream"; }
  static const char *module()  { return "UpstGeo"; }
  static       bool  list();
  typedef UPSTGEO::UpstGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
