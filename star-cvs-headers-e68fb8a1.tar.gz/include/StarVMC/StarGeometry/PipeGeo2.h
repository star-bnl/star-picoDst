#ifndef __PipeGeo2__ 
#define __PipeGeo2__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace PIPEGEO2 // $NMSPC 
{ 
   struct pipv_t {
float version;
int config;
int _index;
};
 
   struct _pipv_docum_ {
string version;
string config;
string _index;
};
 
    struct _pipv_types_ {
  typedef float version;
  typedef int config;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pipv_info {
typedef pipv_t Type;
static const char *name(){ return "pipv_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct pipv_t, version ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct config {
  static const char *name() { return  "config"; }
  static int Offset(){ return offsetof( struct pipv_t, config ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pipv_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pipv_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct pipg_t {
float version;
float zoffset;
float yoffset;
float xoffset;
float zoffber;
float vacdens;
int _index;
};
 
   struct _pipg_docum_ {
string version;
string zoffset;
string yoffset;
string xoffset;
string zoffber;
string vacdens;
string _index;
};
 
    struct _pipg_types_ {
  typedef float version;
  typedef float zoffset;
  typedef float yoffset;
  typedef float xoffset;
  typedef float zoffber;
  typedef float vacdens;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pipg_info {
typedef pipg_t Type;
static const char *name(){ return "pipg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct pipg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zoffset {
  static const char *name() { return  "zoffset"; }
  static int Offset(){ return offsetof( struct pipg_t, zoffset ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yoffset {
  static const char *name() { return  "yoffset"; }
  static int Offset(){ return offsetof( struct pipg_t, yoffset ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xoffset {
  static const char *name() { return  "xoffset"; }
  static int Offset(){ return offsetof( struct pipg_t, xoffset ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zoffber {
  static const char *name() { return  "zoffber"; }
  static int Offset(){ return offsetof( struct pipg_t, zoffber ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct vacdens {
  static const char *name() { return  "vacdens"; }
  static int Offset(){ return offsetof( struct pipg_t, vacdens ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pipg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pipg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- PIPE -- 
   ///@defgroup PIPE_doc 
   ///@class PIPE 
   ///@brief Pipe mother volume [TGeoVolume] 
   class PIPE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PIPE() : AgBlock("PIPE","Pipe mother volume [TGeoVolume]"){ 
      }; 
      ~PIPE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PALH -- 
   ///@defgroup PALH_doc 
   ///@class PALH 
   ///@brief The hole inside the beam pipe [TGeoVolume] 
   class PALH : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PALH() : AgBlock("PALH","The hole inside the beam pipe [TGeoVolume]"){ 
      }; 
      ~PALH(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PALQ -- 
   ///@defgroup PALQ_doc 
   ///@class PALQ 
   ///@brief The east end aluminium tube of the beam pipe [TGeoVolume] 
   class PALQ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PALQ() : AgBlock("PALQ","The east end aluminium tube of the beam pipe [TGeoVolume]"){ 
      }; 
      ~PALQ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PALR -- 
   ///@defgroup PALR_doc 
   ///@class PALR 
   ///@brief The east aluminium transition tube of the full beam pipe [TGeoVolume] 
   class PALR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PALR() : AgBlock("PALR","The east aluminium transition tube of the full beam pipe [TGeoVolume]"){ 
      }; 
      ~PALR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PALS -- 
   ///@defgroup PALS_doc 
   ///@class PALS 
   ///@brief The east aluminium section of the beam pipe [TGeoVolume] 
   class PALS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PALS() : AgBlock("PALS","The east aluminium section of the beam pipe [TGeoVolume]"){ 
      }; 
      ~PALS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PBES -- 
   ///@defgroup PBES_doc 
   ///@class PBES 
   ///@brief The berillium section of the beam pipe [TGeoVolume] 
   class PBES : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PBES() : AgBlock("PBES","The berillium section of the beam pipe [TGeoVolume]"){ 
      }; 
      ~PBES(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PALI -- 
   ///@defgroup PALI_doc 
   ///@class PALI 
   ///@brief The west aluminium section of the beam pipe [TGeoVolume] 
   class PALI : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PALI() : AgBlock("PALI","The west aluminium section of the beam pipe [TGeoVolume]"){ 
      }; 
      ~PALI(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PALJ -- 
   ///@defgroup PALJ_doc 
   ///@class PALJ 
   ///@brief The west aluminium section of the beam pipe (west transition tube) [TGeoVolume] 
   class PALJ : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PALJ() : AgBlock("PALJ","The west aluminium section of the beam pipe (west transition tube) [TGeoVolume]"){ 
      }; 
      ~PALJ(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PALK -- 
   ///@defgroup PALK_doc 
   ///@class PALK 
   ///@brief The west end aluminium tube of the beam pipe [TGeoVolume] 
   class PALK : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PALK() : AgBlock("PALK","The west end aluminium tube of the beam pipe [TGeoVolume]"){ 
      }; 
      ~PALK(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class PipeGeo2 
   /// \brief Complete Beam pipe in y2013 and beyond. Using five separated sections. Middle section Al-Be-Al 
   class PipeGeo2 : public AgModule 
   { 
      public: 
      PipeGeo2(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~PipeGeo2(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace PipeGeo2 
#endif // __PipeGeo2__ 
