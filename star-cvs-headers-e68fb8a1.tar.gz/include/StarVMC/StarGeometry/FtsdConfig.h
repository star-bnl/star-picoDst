#ifndef __FTSD_CONFIG__ 
#define __FTSD_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/FtsdGeo.h" 
namespace FTSD { //
struct FTSDof {
  static const char *name()    { return "FTSDof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTSD { //
struct FTSDon {
  static const char *name()    { return "FTSDon"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTSD { //
struct FTSDv0 {
  static const char *name()    { return "FTSDv0"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTSD { //
struct FTSDv1 {
  static const char *name()    { return "FTSDv1"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTSD { //
struct FTSDv2 {
  static const char *name()    { return "FTSDv2"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTSD { //
struct FTSDv3 {
  static const char *name()    { return "FTSDv3"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTSD { //
struct FTSDv4 {
  static const char *name()    { return "FTSDv4"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTSD { //
struct FTSDv5 {
  static const char *name()    { return "FTSDv5"; }
  static const char *comment() { return "Default configuration for the Endcap EMC"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTSD { //
struct FTSDr1 {
  static const char *name()    { return "FTSDr1"; }
  static const char *comment() { return "FTS Geometry Reference 1"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTSD { //
struct FTSDr2 {
  static const char *name()    { return "FTSDr2"; }
  static const char *comment() { return "FTS Geometry Reference 1"; }
  static const char *module()  { return "FtsdGeo"; }
  static       bool  list();
  typedef FTSDGEO::FtsdGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
