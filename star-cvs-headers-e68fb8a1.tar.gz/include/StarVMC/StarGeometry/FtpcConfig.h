#ifndef __FTPC_CONFIG__ 
#define __FTPC_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/FtpcGeo.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/FtpcGeo1.h" 
namespace FTPC { //
struct FTPCof {
  static const char *name()    { return "FTPCof"; }
  static const char *comment() { return "FTPC off"; }
  static const char *module()  { return "FtpcGeo"; }
  static       bool  list();
  typedef FTPCGEO::FtpcGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTPC { //
struct FTPCon {
  static const char *name()    { return "FTPCon"; }
  static const char *comment() { return "Default configuration for the Forward TPC tracker"; }
  static const char *module()  { return "FtpcGeo"; }
  static       bool  list();
  typedef FTPCGEO::FtpcGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTPC { //
struct FTPC00 {
  static const char *name()    { return "FTPC00"; }
  static const char *comment() { return "Default configuration for the Forward TPC tracker"; }
  static const char *module()  { return "FtpcGeo"; }
  static       bool  list();
  typedef FTPCGEO::FtpcGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace FTPC { //
struct FTPC01 {
  static const char *name()    { return "FTPC01"; }
  static const char *comment() { return "Default configuration for the Forward TPC tracker"; }
  static const char *module()  { return "FtpcGeo1"; }
  static       bool  list();
  typedef FTPCGEO1::FtpcGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
