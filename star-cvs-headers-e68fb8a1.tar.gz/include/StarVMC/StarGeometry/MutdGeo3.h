#ifndef __MutdGeo3__ 
#define __MutdGeo3__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace MUTDGEO3 // $NMSPC 
{ 
   struct mtdg_t {
float version;
float rpmtin;
float rpmtout;
float rmrpcin;
float rmrpcout;
float rmin;
float rmax;
float dz;
float length;
float radii[2];
int _index;
};
 
   struct _mtdg_docum_ {
string version;
string rpmtin;
string rpmtout;
string rmrpcin;
string rmrpcout;
string rmin;
string rmax;
string dz;
string length;
string radii;
string _index;
};
 
    struct _mtdg_types_ {
  typedef float version;
  typedef float rpmtin;
  typedef float rpmtout;
  typedef float rmrpcin;
  typedef float rmrpcout;
  typedef float rmin;
  typedef float rmax;
  typedef float dz;
  typedef float length;
  typedef float radii[2];
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mtdg_info {
typedef mtdg_t Type;
static const char *name(){ return "mtdg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct mtdg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rpmtin {
  static const char *name() { return  "rpmtin"; }
  static int Offset(){ return offsetof( struct mtdg_t, rpmtin ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rpmtout {
  static const char *name() { return  "rpmtout"; }
  static int Offset(){ return offsetof( struct mtdg_t, rpmtout ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmrpcin {
  static const char *name() { return  "rmrpcin"; }
  static int Offset(){ return offsetof( struct mtdg_t, rmrpcin ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmrpcout {
  static const char *name() { return  "rmrpcout"; }
  static int Offset(){ return offsetof( struct mtdg_t, rmrpcout ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct mtdg_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct mtdg_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct mtdg_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct length {
  static const char *name() { return  "length"; }
  static int Offset(){ return offsetof( struct mtdg_t, length ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct radii {
  static const char *name() { return  "radii"; }
  static int Offset(){ return offsetof( struct mtdg_t, radii ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type[2];
};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mtdg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mtdg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct mtry_t {
float height;
float width;
float length;
float wallthk;
float supfullh;
float supfullw;
float suplen;
float supbaset;
float supbasew;
float suparmt;
float cooloutr;
float coolinnr;
float stript;
float footinse;
float footthk;
float foot1len;
float foot2thk;
float foot3len;
int _index;
};
 
   struct _mtry_docum_ {
string height;
string width;
string length;
string wallthk;
string supfullh;
string supfullw;
string suplen;
string supbaset;
string supbasew;
string suparmt;
string cooloutr;
string coolinnr;
string stript;
string footinse;
string footthk;
string foot1len;
string foot2thk;
string foot3len;
string _index;
};
 
    struct _mtry_types_ {
  typedef float height;
  typedef float width;
  typedef float length;
  typedef float wallthk;
  typedef float supfullh;
  typedef float supfullw;
  typedef float suplen;
  typedef float supbaset;
  typedef float supbasew;
  typedef float suparmt;
  typedef float cooloutr;
  typedef float coolinnr;
  typedef float stript;
  typedef float footinse;
  typedef float footthk;
  typedef float foot1len;
  typedef float foot2thk;
  typedef float foot3len;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mtry_info {
typedef mtry_t Type;
static const char *name(){ return "mtry_t"; }
struct height {
  static const char *name() { return  "height"; }
  static int Offset(){ return offsetof( struct mtry_t, height ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct width {
  static const char *name() { return  "width"; }
  static int Offset(){ return offsetof( struct mtry_t, width ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct length {
  static const char *name() { return  "length"; }
  static int Offset(){ return offsetof( struct mtry_t, length ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wallthk {
  static const char *name() { return  "wallthk"; }
  static int Offset(){ return offsetof( struct mtry_t, wallthk ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct supfullh {
  static const char *name() { return  "supfullh"; }
  static int Offset(){ return offsetof( struct mtry_t, supfullh ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct supfullw {
  static const char *name() { return  "supfullw"; }
  static int Offset(){ return offsetof( struct mtry_t, supfullw ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct suplen {
  static const char *name() { return  "suplen"; }
  static int Offset(){ return offsetof( struct mtry_t, suplen ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct supbaset {
  static const char *name() { return  "supbaset"; }
  static int Offset(){ return offsetof( struct mtry_t, supbaset ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct supbasew {
  static const char *name() { return  "supbasew"; }
  static int Offset(){ return offsetof( struct mtry_t, supbasew ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct suparmt {
  static const char *name() { return  "suparmt"; }
  static int Offset(){ return offsetof( struct mtry_t, suparmt ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cooloutr {
  static const char *name() { return  "cooloutr"; }
  static int Offset(){ return offsetof( struct mtry_t, cooloutr ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct coolinnr {
  static const char *name() { return  "coolinnr"; }
  static int Offset(){ return offsetof( struct mtry_t, coolinnr ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stript {
  static const char *name() { return  "stript"; }
  static int Offset(){ return offsetof( struct mtry_t, stript ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct footinse {
  static const char *name() { return  "footinse"; }
  static int Offset(){ return offsetof( struct mtry_t, footinse ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct footthk {
  static const char *name() { return  "footthk"; }
  static int Offset(){ return offsetof( struct mtry_t, footthk ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct foot1len {
  static const char *name() { return  "foot1len"; }
  static int Offset(){ return offsetof( struct mtry_t, foot1len ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct foot2thk {
  static const char *name() { return  "foot2thk"; }
  static int Offset(){ return offsetof( struct mtry_t, foot2thk ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct foot3len {
  static const char *name() { return  "foot3len"; }
  static int Offset(){ return offsetof( struct mtry_t, foot3len ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mtry_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mtry_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct mtbb_t {
float slab1len;
float slab2len;
float slab1x;
float slab2x;
float slabthck;
float slabwid;
float convlen;
float convwidm;
float convthck;
float pmtlen;
float pmtmaxr;
float pmtminr;
float baselen;
float basemaxr;
float baseminr;
float electhck;
float wrap;
float shim;
int _index;
};
 
   struct _mtbb_docum_ {
string slab1len;
string slab2len;
string slab1x;
string slab2x;
string slabthck;
string slabwid;
string convlen;
string convwidm;
string convthck;
string pmtlen;
string pmtmaxr;
string pmtminr;
string baselen;
string basemaxr;
string baseminr;
string electhck;
string wrap;
string shim;
string _index;
};
 
    struct _mtbb_types_ {
  typedef float slab1len;
  typedef float slab2len;
  typedef float slab1x;
  typedef float slab2x;
  typedef float slabthck;
  typedef float slabwid;
  typedef float convlen;
  typedef float convwidm;
  typedef float convthck;
  typedef float pmtlen;
  typedef float pmtmaxr;
  typedef float pmtminr;
  typedef float baselen;
  typedef float basemaxr;
  typedef float baseminr;
  typedef float electhck;
  typedef float wrap;
  typedef float shim;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mtbb_info {
typedef mtbb_t Type;
static const char *name(){ return "mtbb_t"; }
struct slab1len {
  static const char *name() { return  "slab1len"; }
  static int Offset(){ return offsetof( struct mtbb_t, slab1len ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slab2len {
  static const char *name() { return  "slab2len"; }
  static int Offset(){ return offsetof( struct mtbb_t, slab2len ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slab1x {
  static const char *name() { return  "slab1x"; }
  static int Offset(){ return offsetof( struct mtbb_t, slab1x ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slab2x {
  static const char *name() { return  "slab2x"; }
  static int Offset(){ return offsetof( struct mtbb_t, slab2x ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slabthck {
  static const char *name() { return  "slabthck"; }
  static int Offset(){ return offsetof( struct mtbb_t, slabthck ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slabwid {
  static const char *name() { return  "slabwid"; }
  static int Offset(){ return offsetof( struct mtbb_t, slabwid ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct convlen {
  static const char *name() { return  "convlen"; }
  static int Offset(){ return offsetof( struct mtbb_t, convlen ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct convwidm {
  static const char *name() { return  "convwidm"; }
  static int Offset(){ return offsetof( struct mtbb_t, convwidm ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct convthck {
  static const char *name() { return  "convthck"; }
  static int Offset(){ return offsetof( struct mtbb_t, convthck ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtlen {
  static const char *name() { return  "pmtlen"; }
  static int Offset(){ return offsetof( struct mtbb_t, pmtlen ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtmaxr {
  static const char *name() { return  "pmtmaxr"; }
  static int Offset(){ return offsetof( struct mtbb_t, pmtmaxr ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtminr {
  static const char *name() { return  "pmtminr"; }
  static int Offset(){ return offsetof( struct mtbb_t, pmtminr ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct baselen {
  static const char *name() { return  "baselen"; }
  static int Offset(){ return offsetof( struct mtbb_t, baselen ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct basemaxr {
  static const char *name() { return  "basemaxr"; }
  static int Offset(){ return offsetof( struct mtbb_t, basemaxr ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct baseminr {
  static const char *name() { return  "baseminr"; }
  static int Offset(){ return offsetof( struct mtbb_t, baseminr ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct electhck {
  static const char *name() { return  "electhck"; }
  static int Offset(){ return offsetof( struct mtbb_t, electhck ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct wrap {
  static const char *name() { return  "wrap"; }
  static int Offset(){ return offsetof( struct mtbb_t, wrap ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct shim {
  static const char *name() { return  "shim"; }
  static int Offset(){ return offsetof( struct mtbb_t, shim ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mtbb_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mtbb_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct moff_t {
float boxwidth;
float slatlen;
float slat01z;
float slat02z;
float slat03z;
float slat04z;
float slat05z;
float slat06z;
float slat07z;
float slat08z;
float slat09z;
float slat10z;
float slatthck;
float slatwid;
float slatang;
float pmtlen;
float pmtmaxr;
float pmtminr;
float baselen;
float basemaxr;
float baseminr;
float socklen;
float cellwid;
float cellhgt;
float elechgt;
float electhck;
float elecwid;
float eleclen;
float elec01z;
float elec02z;
float elec03z;
float elec04z;
float elec05z;
float elec06z;
float elec07z;
float elec08z;
float elec09z;
float elec10z;
float railthck;
float railwid;
float coolinnr;
float cooloutr;
int _index;
};
 
   struct _moff_docum_ {
string boxwidth;
string slatlen;
string slat01z;
string slat02z;
string slat03z;
string slat04z;
string slat05z;
string slat06z;
string slat07z;
string slat08z;
string slat09z;
string slat10z;
string slatthck;
string slatwid;
string slatang;
string pmtlen;
string pmtmaxr;
string pmtminr;
string baselen;
string basemaxr;
string baseminr;
string socklen;
string cellwid;
string cellhgt;
string elechgt;
string electhck;
string elecwid;
string eleclen;
string elec01z;
string elec02z;
string elec03z;
string elec04z;
string elec05z;
string elec06z;
string elec07z;
string elec08z;
string elec09z;
string elec10z;
string railthck;
string railwid;
string coolinnr;
string cooloutr;
string _index;
};
 
    struct _moff_types_ {
  typedef float boxwidth;
  typedef float slatlen;
  typedef float slat01z;
  typedef float slat02z;
  typedef float slat03z;
  typedef float slat04z;
  typedef float slat05z;
  typedef float slat06z;
  typedef float slat07z;
  typedef float slat08z;
  typedef float slat09z;
  typedef float slat10z;
  typedef float slatthck;
  typedef float slatwid;
  typedef float slatang;
  typedef float pmtlen;
  typedef float pmtmaxr;
  typedef float pmtminr;
  typedef float baselen;
  typedef float basemaxr;
  typedef float baseminr;
  typedef float socklen;
  typedef float cellwid;
  typedef float cellhgt;
  typedef float elechgt;
  typedef float electhck;
  typedef float elecwid;
  typedef float eleclen;
  typedef float elec01z;
  typedef float elec02z;
  typedef float elec03z;
  typedef float elec04z;
  typedef float elec05z;
  typedef float elec06z;
  typedef float elec07z;
  typedef float elec08z;
  typedef float elec09z;
  typedef float elec10z;
  typedef float railthck;
  typedef float railwid;
  typedef float coolinnr;
  typedef float cooloutr;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct moff_info {
typedef moff_t Type;
static const char *name(){ return "moff_t"; }
struct boxwidth {
  static const char *name() { return  "boxwidth"; }
  static int Offset(){ return offsetof( struct moff_t, boxwidth ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slatlen {
  static const char *name() { return  "slatlen"; }
  static int Offset(){ return offsetof( struct moff_t, slatlen ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat01z {
  static const char *name() { return  "slat01z"; }
  static int Offset(){ return offsetof( struct moff_t, slat01z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat02z {
  static const char *name() { return  "slat02z"; }
  static int Offset(){ return offsetof( struct moff_t, slat02z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat03z {
  static const char *name() { return  "slat03z"; }
  static int Offset(){ return offsetof( struct moff_t, slat03z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat04z {
  static const char *name() { return  "slat04z"; }
  static int Offset(){ return offsetof( struct moff_t, slat04z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat05z {
  static const char *name() { return  "slat05z"; }
  static int Offset(){ return offsetof( struct moff_t, slat05z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat06z {
  static const char *name() { return  "slat06z"; }
  static int Offset(){ return offsetof( struct moff_t, slat06z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat07z {
  static const char *name() { return  "slat07z"; }
  static int Offset(){ return offsetof( struct moff_t, slat07z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat08z {
  static const char *name() { return  "slat08z"; }
  static int Offset(){ return offsetof( struct moff_t, slat08z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat09z {
  static const char *name() { return  "slat09z"; }
  static int Offset(){ return offsetof( struct moff_t, slat09z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slat10z {
  static const char *name() { return  "slat10z"; }
  static int Offset(){ return offsetof( struct moff_t, slat10z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slatthck {
  static const char *name() { return  "slatthck"; }
  static int Offset(){ return offsetof( struct moff_t, slatthck ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slatwid {
  static const char *name() { return  "slatwid"; }
  static int Offset(){ return offsetof( struct moff_t, slatwid ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct slatang {
  static const char *name() { return  "slatang"; }
  static int Offset(){ return offsetof( struct moff_t, slatang ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtlen {
  static const char *name() { return  "pmtlen"; }
  static int Offset(){ return offsetof( struct moff_t, pmtlen ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtmaxr {
  static const char *name() { return  "pmtmaxr"; }
  static int Offset(){ return offsetof( struct moff_t, pmtmaxr ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pmtminr {
  static const char *name() { return  "pmtminr"; }
  static int Offset(){ return offsetof( struct moff_t, pmtminr ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct baselen {
  static const char *name() { return  "baselen"; }
  static int Offset(){ return offsetof( struct moff_t, baselen ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct basemaxr {
  static const char *name() { return  "basemaxr"; }
  static int Offset(){ return offsetof( struct moff_t, basemaxr ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct baseminr {
  static const char *name() { return  "baseminr"; }
  static int Offset(){ return offsetof( struct moff_t, baseminr ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct socklen {
  static const char *name() { return  "socklen"; }
  static int Offset(){ return offsetof( struct moff_t, socklen ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cellwid {
  static const char *name() { return  "cellwid"; }
  static int Offset(){ return offsetof( struct moff_t, cellwid ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cellhgt {
  static const char *name() { return  "cellhgt"; }
  static int Offset(){ return offsetof( struct moff_t, cellhgt ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elechgt {
  static const char *name() { return  "elechgt"; }
  static int Offset(){ return offsetof( struct moff_t, elechgt ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct electhck {
  static const char *name() { return  "electhck"; }
  static int Offset(){ return offsetof( struct moff_t, electhck ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elecwid {
  static const char *name() { return  "elecwid"; }
  static int Offset(){ return offsetof( struct moff_t, elecwid ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct eleclen {
  static const char *name() { return  "eleclen"; }
  static int Offset(){ return offsetof( struct moff_t, eleclen ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec01z {
  static const char *name() { return  "elec01z"; }
  static int Offset(){ return offsetof( struct moff_t, elec01z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec02z {
  static const char *name() { return  "elec02z"; }
  static int Offset(){ return offsetof( struct moff_t, elec02z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec03z {
  static const char *name() { return  "elec03z"; }
  static int Offset(){ return offsetof( struct moff_t, elec03z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec04z {
  static const char *name() { return  "elec04z"; }
  static int Offset(){ return offsetof( struct moff_t, elec04z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec05z {
  static const char *name() { return  "elec05z"; }
  static int Offset(){ return offsetof( struct moff_t, elec05z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec06z {
  static const char *name() { return  "elec06z"; }
  static int Offset(){ return offsetof( struct moff_t, elec06z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec07z {
  static const char *name() { return  "elec07z"; }
  static int Offset(){ return offsetof( struct moff_t, elec07z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec08z {
  static const char *name() { return  "elec08z"; }
  static int Offset(){ return offsetof( struct moff_t, elec08z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec09z {
  static const char *name() { return  "elec09z"; }
  static int Offset(){ return offsetof( struct moff_t, elec09z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct elec10z {
  static const char *name() { return  "elec10z"; }
  static int Offset(){ return offsetof( struct moff_t, elec10z ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct railthck {
  static const char *name() { return  "railthck"; }
  static int Offset(){ return offsetof( struct moff_t, railthck ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct railwid {
  static const char *name() { return  "railwid"; }
  static int Offset(){ return offsetof( struct moff_t, railwid ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct coolinnr {
  static const char *name() { return  "coolinnr"; }
  static int Offset(){ return offsetof( struct moff_t, coolinnr ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct cooloutr {
  static const char *name() { return  "cooloutr"; }
  static int Offset(){ return offsetof( struct moff_t, cooloutr ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct moff_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)moff_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- MUTD -- 
   ///@defgroup MUTD_doc 
   ///@class MUTD 
   ///@brief is the muon detector mother [TGeoVolume] 
   class MUTD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MUTD() : AgBlock("MUTD","is the muon detector mother [TGeoVolume]"){ 
      }; 
      ~MUTD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MUSC -- 
   ///@defgroup MUSC_doc 
   ///@class MUSC 
   ///@brief is a sector of MUON Trigger Barrel Scintillators [TGeoVolume] 
   class MUSC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MUSC() : AgBlock("MUSC","is a sector of MUON Trigger Barrel Scintillators [TGeoVolume]"){ 
      }; 
      ~MUSC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MTRA -- 
   ///@defgroup MTRA_doc 
   ///@class MTRA 
   ///@brief is one full tray plus supporting structure for CTB/TOF [TGeoVolume] 
   class MTRA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MTRA() : AgBlock("MTRA","is one full tray plus supporting structure for CTB/TOF [TGeoVolume]"){ 
      }; 
      ~MTRA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MXTR -- 
   ///@defgroup MXTR_doc 
   ///@class MXTR 
   ///@brief is a Main TRay covering box for CTB or TOF [TGeoVolume] 
   class MXTR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MXTR() : AgBlock("MXTR","is a Main TRay covering box for CTB or TOF [TGeoVolume]"){ 
      }; 
      ~MXTR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MMTC -- 
   ///@defgroup MMTC_doc 
   ///@class MMTC 
   ///@brief is the Main Tray Cavity filled with the details for CTB [TGeoVolume] 
   class MMTC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MMTC() : AgBlock("MMTC","is the Main Tray Cavity filled with the details for CTB [TGeoVolume]"){ 
      }; 
      ~MMTC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MXSA -- 
   ///@defgroup MXSA_doc 
   ///@class MXSA 
   ///@brief is the active trigger scintillator SLAB for ctb [TGeoVolume] 
   class MXSA : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MXSA() : AgBlock("MXSA","is the active trigger scintillator SLAB for ctb [TGeoVolume]"){ 
      }; 
      ~MXSA(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MPMT -- 
   ///@defgroup MPMT_doc 
   ///@class MPMT 
   ///@brief is a Main TRay covering box for PMT [TGeoVolume] 
   class MPMT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MPMT() : AgBlock("MPMT","is a Main TRay covering box for PMT [TGeoVolume]"){ 
      }; 
      ~MPMT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- MMRP -- 
   ///@defgroup MMRP_doc 
   ///@class MMRP 
   ///@brief is a Main TRay covering box for MRPC [TGeoVolume] 
   class MMRP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MMRP() : AgBlock("MMRP","is a Main TRay covering box for MRPC [TGeoVolume]"){ 
      }; 
      ~MMRP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class MutdGeo3 
   /// \brief  is the geometry of the STAR muon trigger system  
   class MutdGeo3 : public AgModule 
   { 
      public: 
      MutdGeo3(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~MutdGeo3(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace MutdGeo3 
#endif // __MutdGeo3__ 
