#ifndef __FpdmGeo3__ 
#define __FpdmGeo3__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace FPDMGEO3 // $NMSPC 
{ 
   struct fmcg_t {
float version;
float chkvsim;
float pbplate;
float fmsnorthx;
float fmssouthx;
float atten;
int _index;
};
 
   struct _fmcg_docum_ {
string version;
string chkvsim;
string pbplate;
string fmsnorthx;
string fmssouthx;
string atten;
string _index;
};
 
    struct _fmcg_types_ {
  typedef float version;
  typedef float chkvsim;
  typedef float pbplate;
  typedef float fmsnorthx;
  typedef float fmssouthx;
  typedef float atten;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fmcg_info {
typedef fmcg_t Type;
static const char *name(){ return "fmcg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct fmcg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct chkvsim {
  static const char *name() { return  "chkvsim"; }
  static int Offset(){ return offsetof( struct fmcg_t, chkvsim ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pbplate {
  static const char *name() { return  "pbplate"; }
  static int Offset(){ return offsetof( struct fmcg_t, pbplate ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fmsnorthx {
  static const char *name() { return  "fmsnorthx"; }
  static int Offset(){ return offsetof( struct fmcg_t, fmsnorthx ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fmssouthx {
  static const char *name() { return  "fmssouthx"; }
  static int Offset(){ return offsetof( struct fmcg_t, fmssouthx ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct atten {
  static const char *name() { return  "atten"; }
  static int Offset(){ return offsetof( struct fmcg_t, atten ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fmcg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fmcg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fpos_t {
float imod;
float itype;
float x;
float y;
float z;
float ay;
float az;
int _index;
};
 
   struct _fpos_docum_ {
string imod;
string itype;
string x;
string y;
string z;
string ay;
string az;
string _index;
};
 
    struct _fpos_types_ {
  typedef float imod;
  typedef float itype;
  typedef float x;
  typedef float y;
  typedef float z;
  typedef float ay;
  typedef float az;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fpos_info {
typedef fpos_t Type;
static const char *name(){ return "fpos_t"; }
struct imod {
  static const char *name() { return  "imod"; }
  static int Offset(){ return offsetof( struct fpos_t, imod ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct itype {
  static const char *name() { return  "itype"; }
  static int Offset(){ return offsetof( struct fpos_t, itype ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct fpos_t, x ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct fpos_t, y ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct fpos_t, z ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ay {
  static const char *name() { return  "ay"; }
  static int Offset(){ return offsetof( struct fpos_t, ay ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct az {
  static const char *name() { return  "az"; }
  static int Offset(){ return offsetof( struct fpos_t, az ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fpos_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fpos_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fbxd_t {
float type;
float height;
float depth;
float width;
float nx;
float ny;
float nxl;
float nyl;
float xoffset;
float zoffset;
float psoffset;
float smdoff;
int _index;
};
 
   struct _fbxd_docum_ {
string type;
string height;
string depth;
string width;
string nx;
string ny;
string nxl;
string nyl;
string xoffset;
string zoffset;
string psoffset;
string smdoff;
string _index;
};
 
    struct _fbxd_types_ {
  typedef float type;
  typedef float height;
  typedef float depth;
  typedef float width;
  typedef float nx;
  typedef float ny;
  typedef float nxl;
  typedef float nyl;
  typedef float xoffset;
  typedef float zoffset;
  typedef float psoffset;
  typedef float smdoff;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fbxd_info {
typedef fbxd_t Type;
static const char *name(){ return "fbxd_t"; }
struct type {
  static const char *name() { return  "type"; }
  static int Offset(){ return offsetof( struct fbxd_t, type ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct height {
  static const char *name() { return  "height"; }
  static int Offset(){ return offsetof( struct fbxd_t, height ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct depth {
  static const char *name() { return  "depth"; }
  static int Offset(){ return offsetof( struct fbxd_t, depth ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct width {
  static const char *name() { return  "width"; }
  static int Offset(){ return offsetof( struct fbxd_t, width ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nx {
  static const char *name() { return  "nx"; }
  static int Offset(){ return offsetof( struct fbxd_t, nx ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ny {
  static const char *name() { return  "ny"; }
  static int Offset(){ return offsetof( struct fbxd_t, ny ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nxl {
  static const char *name() { return  "nxl"; }
  static int Offset(){ return offsetof( struct fbxd_t, nxl ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nyl {
  static const char *name() { return  "nyl"; }
  static int Offset(){ return offsetof( struct fbxd_t, nyl ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xoffset {
  static const char *name() { return  "xoffset"; }
  static int Offset(){ return offsetof( struct fbxd_t, xoffset ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zoffset {
  static const char *name() { return  "zoffset"; }
  static int Offset(){ return offsetof( struct fbxd_t, zoffset ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct psoffset {
  static const char *name() { return  "psoffset"; }
  static int Offset(){ return offsetof( struct fbxd_t, psoffset ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct smdoff {
  static const char *name() { return  "smdoff"; }
  static int Offset(){ return offsetof( struct fbxd_t, smdoff ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fbxd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fbxd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct flgg_t {
float type;
float width;
float depth;
float dgap;
float althick;
float phcathdz;
float phcathr;
float mumetdz;
float mumetr;
int _index;
};
 
   struct _flgg_docum_ {
string type;
string width;
string depth;
string dgap;
string althick;
string phcathdz;
string phcathr;
string mumetdz;
string mumetr;
string _index;
};
 
    struct _flgg_types_ {
  typedef float type;
  typedef float width;
  typedef float depth;
  typedef float dgap;
  typedef float althick;
  typedef float phcathdz;
  typedef float phcathr;
  typedef float mumetdz;
  typedef float mumetr;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct flgg_info {
typedef flgg_t Type;
static const char *name(){ return "flgg_t"; }
struct type {
  static const char *name() { return  "type"; }
  static int Offset(){ return offsetof( struct flgg_t, type ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct width {
  static const char *name() { return  "width"; }
  static int Offset(){ return offsetof( struct flgg_t, width ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct depth {
  static const char *name() { return  "depth"; }
  static int Offset(){ return offsetof( struct flgg_t, depth ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dgap {
  static const char *name() { return  "dgap"; }
  static int Offset(){ return offsetof( struct flgg_t, dgap ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct althick {
  static const char *name() { return  "althick"; }
  static int Offset(){ return offsetof( struct flgg_t, althick ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phcathdz {
  static const char *name() { return  "phcathdz"; }
  static int Offset(){ return offsetof( struct flgg_t, phcathdz ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct phcathr {
  static const char *name() { return  "phcathr"; }
  static int Offset(){ return offsetof( struct flgg_t, phcathr ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mumetdz {
  static const char *name() { return  "mumetdz"; }
  static int Offset(){ return offsetof( struct flgg_t, mumetdz ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct mumetr {
  static const char *name() { return  "mumetr"; }
  static int Offset(){ return offsetof( struct flgg_t, mumetr ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct flgg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)flgg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct flgm_t {
float type;
float density;
float radlen;
float pbcont;
float critene;
float molierer;
int _index;
};
 
   struct _flgm_docum_ {
string type;
string density;
string radlen;
string pbcont;
string critene;
string molierer;
string _index;
};
 
    struct _flgm_types_ {
  typedef float type;
  typedef float density;
  typedef float radlen;
  typedef float pbcont;
  typedef float critene;
  typedef float molierer;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct flgm_info {
typedef flgm_t Type;
static const char *name(){ return "flgm_t"; }
struct type {
  static const char *name() { return  "type"; }
  static int Offset(){ return offsetof( struct flgm_t, type ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct density {
  static const char *name() { return  "density"; }
  static int Offset(){ return offsetof( struct flgm_t, density ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct radlen {
  static const char *name() { return  "radlen"; }
  static int Offset(){ return offsetof( struct flgm_t, radlen ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct pbcont {
  static const char *name() { return  "pbcont"; }
  static int Offset(){ return offsetof( struct flgm_t, pbcont ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct critene {
  static const char *name() { return  "critene"; }
  static int Offset(){ return offsetof( struct flgm_t, critene ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct molierer {
  static const char *name() { return  "molierer"; }
  static int Offset(){ return offsetof( struct flgm_t, molierer ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct flgm_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)flgm_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct pbpd_t {
float z;
float width;
float height;
float thick;
int _index;
};
 
   struct _pbpd_docum_ {
string z;
string width;
string height;
string thick;
string _index;
};
 
    struct _pbpd_types_ {
  typedef float z;
  typedef float width;
  typedef float height;
  typedef float thick;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pbpd_info {
typedef pbpd_t Type;
static const char *name(){ return "pbpd_t"; }
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct pbpd_t, z ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct width {
  static const char *name() { return  "width"; }
  static int Offset(){ return offsetof( struct pbpd_t, width ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct height {
  static const char *name() { return  "height"; }
  static int Offset(){ return offsetof( struct pbpd_t, height ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct thick {
  static const char *name() { return  "thick"; }
  static int Offset(){ return offsetof( struct pbpd_t, thick ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pbpd_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pbpd_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fmxg_t {
float version;
float sapex;
float sbase;
float sgap;
float nstrip;
float g10width;
float g10hgt;
float g10thick;
int _index;
};
 
   struct _fmxg_docum_ {
string version;
string sapex;
string sbase;
string sgap;
string nstrip;
string g10width;
string g10hgt;
string g10thick;
string _index;
};
 
    struct _fmxg_types_ {
  typedef float version;
  typedef float sapex;
  typedef float sbase;
  typedef float sgap;
  typedef float nstrip;
  typedef float g10width;
  typedef float g10hgt;
  typedef float g10thick;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fmxg_info {
typedef fmxg_t Type;
static const char *name(){ return "fmxg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct fmxg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sapex {
  static const char *name() { return  "sapex"; }
  static int Offset(){ return offsetof( struct fmxg_t, sapex ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sbase {
  static const char *name() { return  "sbase"; }
  static int Offset(){ return offsetof( struct fmxg_t, sbase ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sgap {
  static const char *name() { return  "sgap"; }
  static int Offset(){ return offsetof( struct fmxg_t, sgap ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nstrip {
  static const char *name() { return  "nstrip"; }
  static int Offset(){ return offsetof( struct fmxg_t, nstrip ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct g10width {
  static const char *name() { return  "g10width"; }
  static int Offset(){ return offsetof( struct fmxg_t, g10width ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct g10hgt {
  static const char *name() { return  "g10hgt"; }
  static int Offset(){ return offsetof( struct fmxg_t, g10hgt ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct g10thick {
  static const char *name() { return  "g10thick"; }
  static int Offset(){ return offsetof( struct fmxg_t, g10thick ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fmxg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fmxg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct inse_t {
float width;
float depth;
float height;
float sheetdpt;
float holegap;
float holedepth;
float holeheight;
float gapdepth;
float gapheight;
float gatedepth;
float ra;
float rb;
float diam;
float rmax;
float gategap;
int _index;
};
 
   struct _inse_docum_ {
string width;
string depth;
string height;
string sheetdpt;
string holegap;
string holedepth;
string holeheight;
string gapdepth;
string gapheight;
string gatedepth;
string ra;
string rb;
string diam;
string rmax;
string gategap;
string _index;
};
 
    struct _inse_types_ {
  typedef float width;
  typedef float depth;
  typedef float height;
  typedef float sheetdpt;
  typedef float holegap;
  typedef float holedepth;
  typedef float holeheight;
  typedef float gapdepth;
  typedef float gapheight;
  typedef float gatedepth;
  typedef float ra;
  typedef float rb;
  typedef float diam;
  typedef float rmax;
  typedef float gategap;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct inse_info {
typedef inse_t Type;
static const char *name(){ return "inse_t"; }
struct width {
  static const char *name() { return  "width"; }
  static int Offset(){ return offsetof( struct inse_t, width ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct depth {
  static const char *name() { return  "depth"; }
  static int Offset(){ return offsetof( struct inse_t, depth ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct height {
  static const char *name() { return  "height"; }
  static int Offset(){ return offsetof( struct inse_t, height ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct sheetdpt {
  static const char *name() { return  "sheetdpt"; }
  static int Offset(){ return offsetof( struct inse_t, sheetdpt ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct holegap {
  static const char *name() { return  "holegap"; }
  static int Offset(){ return offsetof( struct inse_t, holegap ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct holedepth {
  static const char *name() { return  "holedepth"; }
  static int Offset(){ return offsetof( struct inse_t, holedepth ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct holeheight {
  static const char *name() { return  "holeheight"; }
  static int Offset(){ return offsetof( struct inse_t, holeheight ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gapdepth {
  static const char *name() { return  "gapdepth"; }
  static int Offset(){ return offsetof( struct inse_t, gapdepth ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gapheight {
  static const char *name() { return  "gapheight"; }
  static int Offset(){ return offsetof( struct inse_t, gapheight ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gatedepth {
  static const char *name() { return  "gatedepth"; }
  static int Offset(){ return offsetof( struct inse_t, gatedepth ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ra {
  static const char *name() { return  "ra"; }
  static int Offset(){ return offsetof( struct inse_t, ra ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rb {
  static const char *name() { return  "rb"; }
  static int Offset(){ return offsetof( struct inse_t, rb ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct diam {
  static const char *name() { return  "diam"; }
  static int Offset(){ return offsetof( struct inse_t, diam ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct inse_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct gategap {
  static const char *name() { return  "gategap"; }
  static int Offset(){ return offsetof( struct inse_t, gategap ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct inse_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)inse_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- FBOX -- 
   ///@defgroup FBOX_doc 
   ///@class FBOX 
   ///@brief is one Pb-Glass fpd detector [TGeoVolume] 
   class FBOX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FBOX() : AgBlock("FBOX","is one Pb-Glass fpd detector [TGeoVolume]"){ 
      }; 
      ~FBOX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FTOW -- 
   ///@defgroup FTOW_doc 
   ///@class FTOW 
   ///@brief is one PbG Tower [TGeoVolume] 
   class FTOW : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FTOW() : AgBlock("FTOW","is one PbG Tower [TGeoVolume]"){ 
      }; 
      ~FTOW(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FWAL -- 
   ///@defgroup FWAL_doc 
   ///@class FWAL 
   ///@brief is almunum wrapper [TGeoVolume] 
   class FWAL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FWAL() : AgBlock("FWAL","is almunum wrapper [TGeoVolume]"){ 
      }; 
      ~FWAL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FLGR -- 
   ///@defgroup FLGR_doc 
   ///@class FLGR 
   ///@brief is Lead Glass detector [TGeoVolume] 
   class FLGR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FLGR() : AgBlock("FLGR","is Lead Glass detector [TGeoVolume]"){ 
      }; 
      ~FLGR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FLXF -- 
   ///@defgroup FLXF_doc 
   ///@class FLXF 
   ///@brief is Lead Glass detector [TGeoVolume] 
   class FLXF : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FLXF() : AgBlock("FLXF","is Lead Glass detector [TGeoVolume]"){ 
      }; 
      ~FLXF(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FALU -- 
   ///@defgroup FALU_doc 
   ///@class FALU 
   ///@brief is Aluminium Base Cell [TGeoVolume] 
   class FALU : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FALU() : AgBlock("FALU","is Aluminium Base Cell [TGeoVolume]"){ 
      }; 
      ~FALU(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FBAS -- 
   ///@defgroup FBAS_doc 
   ///@class FBAS 
   ///@brief is Steel Base Plate [TGeoVolume] 
   class FBAS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FBAS() : AgBlock("FBAS","is Steel Base Plate [TGeoVolume]"){ 
      }; 
      ~FBAS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FENC -- 
   ///@defgroup FENC_doc 
   ///@class FENC 
   ///@brief is Steel Enclosure [TGeoVolume] 
   class FENC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FENC() : AgBlock("FENC","is Steel Enclosure [TGeoVolume]"){ 
      }; 
      ~FENC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FEAC -- 
   ///@defgroup FEAC_doc 
   ///@class FEAC 
   ///@brief is Steel Enclosure [TGeoVolume] 
   class FEAC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FEAC() : AgBlock("FEAC","is Steel Enclosure [TGeoVolume]"){ 
      }; 
      ~FEAC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FEBC -- 
   ///@defgroup FEBC_doc 
   ///@class FEBC 
   ///@brief is Air square hole [TGeoVolume] 
   class FEBC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FEBC() : AgBlock("FEBC","is Air square hole [TGeoVolume]"){ 
      }; 
      ~FEBC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FECC -- 
   ///@defgroup FECC_doc 
   ///@class FECC 
   ///@brief is Steel distancer [TGeoVolume] 
   class FECC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FECC() : AgBlock("FECC","is Steel distancer [TGeoVolume]"){ 
      }; 
      ~FECC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FEDC -- 
   ///@defgroup FEDC_doc 
   ///@class FEDC 
   ///@brief is Steel Enclosure part on south [TGeoVolume] 
   class FEDC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FEDC() : AgBlock("FEDC","is Steel Enclosure part on south [TGeoVolume]"){ 
      }; 
      ~FEDC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FEEC -- 
   ///@defgroup FEEC_doc 
   ///@class FEEC 
   ///@brief is Steel Enclosure part on north [TGeoVolume] 
   class FEEC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FEEC() : AgBlock("FEEC","is Steel Enclosure part on north [TGeoVolume]"){ 
      }; 
      ~FEEC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FETC -- 
   ///@defgroup FETC_doc 
   ///@class FETC 
   ///@brief is Air Enclosure part [TGeoVolume] 
   class FETC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FETC() : AgBlock("FETC","is Air Enclosure part [TGeoVolume]"){ 
      }; 
      ~FETC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FERC -- 
   ///@defgroup FERC_doc 
   ///@class FERC 
   ///@brief is Air Enclosure part [TGeoVolume] 
   class FERC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FERC() : AgBlock("FERC","is Air Enclosure part [TGeoVolume]"){ 
      }; 
      ~FERC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FESC -- 
   ///@defgroup FESC_doc 
   ///@class FESC 
   ///@brief is Air Enclosure part [TGeoVolume] 
   class FESC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FESC() : AgBlock("FESC","is Air Enclosure part [TGeoVolume]"){ 
      }; 
      ~FESC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FPCT -- 
   ///@defgroup FPCT_doc 
   ///@class FPCT 
   ///@brief is Photo Cathode [TGeoVolume] 
   class FPCT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FPCT() : AgBlock("FPCT","is Photo Cathode [TGeoVolume]"){ 
      }; 
      ~FPCT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FUMT -- 
   ///@defgroup FUMT_doc 
   ///@class FUMT 
   ///@brief is mu metal [TGeoVolume] 
   class FUMT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FUMT() : AgBlock("FUMT","is mu metal [TGeoVolume]"){ 
      }; 
      ~FUMT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- PBPT -- 
   ///@defgroup PBPT_doc 
   ///@class PBPT 
   ///@brief is pb plate [TGeoVolume] 
   class PBPT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      PBPT() : AgBlock("PBPT","is pb plate [TGeoVolume]"){ 
      }; 
      ~PBPT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FSHM -- 
   ///@defgroup FSHM_doc 
   ///@class FSHM 
   ///@brief is the SHower Max section [TGeoVolume] 
   class FSHM : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FSHM() : AgBlock("FSHM","is the SHower Max section [TGeoVolume]"){ 
      }; 
      ~FSHM(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FXGT -- 
   ///@defgroup FXGT_doc 
   ///@class FXGT 
   ///@brief is the G10 layer in the SMax [TGeoVolume] 
   class FXGT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FXGT() : AgBlock("FXGT","is the G10 layer in the SMax [TGeoVolume]"){ 
      }; 
      ~FXGT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- FHMS -- 
   ///@defgroup FHMS_doc 
   ///@class FHMS 
   ///@brief is sHower Max Strip [TGeoVolume] 
   class FHMS : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      FHMS() : AgBlock("FHMS","is sHower Max Strip [TGeoVolume]"){ 
      }; 
      ~FHMS(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class FpdmGeo3 
   /// \brief  is the Forward Pion Detector Modules GEOmetry  
   class FpdmGeo3 : public AgModule 
   { 
      public: 
      FpdmGeo3(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~FpdmGeo3(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace FpdmGeo3 
#endif // __FpdmGeo3__ 
