#ifndef __TutrGeo1__ 
#define __TutrGeo1__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace TUTRGEO1 // $NMSPC 
{ 
   // ---------------------------------------------------------------------- TUTR -- 
   ///@defgroup TUTR_doc 
   ///@class TUTR 
   ///@brief Main volume in the AGML tutorial geometry [TGeoVolume] 
   class TUTR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TUTR() : AgBlock("TUTR","Main volume in the AGML tutorial geometry [TGeoVolume]"){ 
      }; 
      ~TUTR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ABOX -- 
   ///@defgroup ABOX_doc 
   ///@class ABOX 
   ///@brief A volume which is a box in the tutorial [TGeoVolume] 
   class ABOX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ABOX() : AgBlock("ABOX","A volume which is a box in the tutorial [TGeoVolume]"){ 
      }; 
      ~ABOX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class TutrGeo1 
   /// \brief Tutorial Geometry 1 
   class TutrGeo1 : public AgModule 
   { 
      public: 
      TutrGeo1(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~TutrGeo1(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace TutrGeo1 
#endif // __TutrGeo1__ 
