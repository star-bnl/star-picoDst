#ifndef __SHLD_CONFIG__ 
#define __SHLD_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/ShldGeo.h" 
namespace SHLD { //
struct SHLDof {
  static const char *name()    { return "SHLDof"; }
  static const char *comment() { return "Shield off"; }
  static const char *module()  { return "ShldGeo"; }
  static       bool  list();
  typedef SHLDGEO::ShldGeo Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace SHLD { //
struct SHLDon {
  static const char *name()    { return "SHLDon"; }
  static const char *comment() { return "Default configuration for the beam tunnel shielding"; }
  static const char *module()  { return "ShldGeo"; }
  static       bool  list();
  typedef SHLDGEO::ShldGeo Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
