#ifndef __BTOF_CONFIG__ 
#define __BTOF_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/BtofGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/BtofGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/BtofGeo3.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/BtofGeo4.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/BtofGeo5.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/BtofGeo6.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/BtofGeo7.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/BtofGeo8.h" 
namespace BTOF { //
struct BTOFof {
  static const char *name()    { return "BTOFof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "BtofGeo1"; }
  static       bool  list();
  typedef BTOFGEO1::BtofGeo1 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOF42 {
  static const char *name()    { return "BTOF42"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo2"; }
  static       bool  list();
  typedef BTOFGEO2::BtofGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOF52 {
  static const char *name()    { return "BTOF52"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo2"; }
  static       bool  list();
  typedef BTOFGEO2::BtofGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOF72 {
  static const char *name()    { return "BTOF72"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo2"; }
  static       bool  list();
  typedef BTOFGEO2::BtofGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOF84 {
  static const char *name()    { return "BTOF84"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo4"; }
  static       bool  list();
  typedef BTOFGEO4::BtofGeo4 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOFa5 {
  static const char *name()    { return "BTOFa5"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo5"; }
  static       bool  list();
  typedef BTOFGEO5::BtofGeo5 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOF16 {
  static const char *name()    { return "BTOF16"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo6"; }
  static       bool  list();
  typedef BTOFGEO6::BtofGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOF66 {
  static const char *name()    { return "BTOF66"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo6"; }
  static       bool  list();
  typedef BTOFGEO6::BtofGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOF67 {
  static const char *name()    { return "BTOF67"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo7"; }
  static       bool  list();
  typedef BTOFGEO7::BtofGeo7 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOFb6 {
  static const char *name()    { return "BTOFb6"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo6"; }
  static       bool  list();
  typedef BTOFGEO6::BtofGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOFb7 {
  static const char *name()    { return "BTOFb7"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo7"; }
  static       bool  list();
  typedef BTOFGEO7::BtofGeo7 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOFc6 {
  static const char *name()    { return "BTOFc6"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo6"; }
  static       bool  list();
  typedef BTOFGEO6::BtofGeo6 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOFc7 {
  static const char *name()    { return "BTOFc7"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo7"; }
  static       bool  list();
  typedef BTOFGEO7::BtofGeo7 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace BTOF { //
struct BTOFv8 {
  static const char *name()    { return "BTOFv8"; }
  static const char *comment() { return ""; }
  static const char *module()  { return "BtofGeo8"; }
  static       bool  list();
  typedef BTOFGEO8::BtofGeo8 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
