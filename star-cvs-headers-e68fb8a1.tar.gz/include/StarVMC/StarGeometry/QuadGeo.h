#ifndef __QuadGeo__ 
#define __QuadGeo__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace QUADGEO // $NMSPC 
{ 
   struct shlq_t {
float version;
float q0;
float motherr;
float motherl;
float xoffset;
float angle;
float dzerol;
float dzerori;
float dzeroro;
float q1;
float ri1;
float ro1;
float dz1;
float q2;
float ri2;
float ro2;
float dz2;
float q3;
float ri3;
float ro3;
float dz3;
int _index;
};
 
   struct _shlq_docum_ {
string version;
string q0;
string motherr;
string motherl;
string xoffset;
string angle;
string dzerol;
string dzerori;
string dzeroro;
string q1;
string ri1;
string ro1;
string dz1;
string q2;
string ri2;
string ro2;
string dz2;
string q3;
string ri3;
string ro3;
string dz3;
string _index;
};
 
    struct _shlq_types_ {
  typedef float version;
  typedef float q0;
  typedef float motherr;
  typedef float motherl;
  typedef float xoffset;
  typedef float angle;
  typedef float dzerol;
  typedef float dzerori;
  typedef float dzeroro;
  typedef float q1;
  typedef float ri1;
  typedef float ro1;
  typedef float dz1;
  typedef float q2;
  typedef float ri2;
  typedef float ro2;
  typedef float dz2;
  typedef float q3;
  typedef float ri3;
  typedef float ro3;
  typedef float dz3;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct shlq_info {
typedef shlq_t Type;
static const char *name(){ return "shlq_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct shlq_t, version ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct q0 {
  static const char *name() { return  "q0"; }
  static int Offset(){ return offsetof( struct shlq_t, q0 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct motherr {
  static const char *name() { return  "motherr"; }
  static int Offset(){ return offsetof( struct shlq_t, motherr ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct motherl {
  static const char *name() { return  "motherl"; }
  static int Offset(){ return offsetof( struct shlq_t, motherl ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xoffset {
  static const char *name() { return  "xoffset"; }
  static int Offset(){ return offsetof( struct shlq_t, xoffset ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct angle {
  static const char *name() { return  "angle"; }
  static int Offset(){ return offsetof( struct shlq_t, angle ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzerol {
  static const char *name() { return  "dzerol"; }
  static int Offset(){ return offsetof( struct shlq_t, dzerol ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzerori {
  static const char *name() { return  "dzerori"; }
  static int Offset(){ return offsetof( struct shlq_t, dzerori ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzeroro {
  static const char *name() { return  "dzeroro"; }
  static int Offset(){ return offsetof( struct shlq_t, dzeroro ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct q1 {
  static const char *name() { return  "q1"; }
  static int Offset(){ return offsetof( struct shlq_t, q1 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ri1 {
  static const char *name() { return  "ri1"; }
  static int Offset(){ return offsetof( struct shlq_t, ri1 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ro1 {
  static const char *name() { return  "ro1"; }
  static int Offset(){ return offsetof( struct shlq_t, ro1 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz1 {
  static const char *name() { return  "dz1"; }
  static int Offset(){ return offsetof( struct shlq_t, dz1 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct q2 {
  static const char *name() { return  "q2"; }
  static int Offset(){ return offsetof( struct shlq_t, q2 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ri2 {
  static const char *name() { return  "ri2"; }
  static int Offset(){ return offsetof( struct shlq_t, ri2 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ro2 {
  static const char *name() { return  "ro2"; }
  static int Offset(){ return offsetof( struct shlq_t, ro2 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz2 {
  static const char *name() { return  "dz2"; }
  static int Offset(){ return offsetof( struct shlq_t, dz2 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct q3 {
  static const char *name() { return  "q3"; }
  static int Offset(){ return offsetof( struct shlq_t, q3 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ri3 {
  static const char *name() { return  "ri3"; }
  static int Offset(){ return offsetof( struct shlq_t, ri3 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ro3 {
  static const char *name() { return  "ro3"; }
  static int Offset(){ return offsetof( struct shlq_t, ro3 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz3 {
  static const char *name() { return  "dz3"; }
  static int Offset(){ return offsetof( struct shlq_t, dz3 ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct shlq_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)shlq_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- MGMT -- 
   ///@defgroup MGMT_doc 
   ///@class MGMT 
   ///@brief is the magnet mother [TGeoVolume] 
   class MGMT : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      MGMT() : AgBlock("MGMT","is the magnet mother [TGeoVolume]"){ 
      }; 
      ~MGMT(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- DZER -- 
   ///@defgroup DZER_doc 
   ///@class DZER 
   ///@brief is the D0 yoke [TGeoVolume] 
   class DZER : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      DZER() : AgBlock("DZER","is the D0 yoke [TGeoVolume]"){ 
      }; 
      ~DZER(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- QONE -- 
   ///@defgroup QONE_doc 
   ///@class QONE 
   ///@brief is the Q1 yoke [TGeoVolume] 
   class QONE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      QONE() : AgBlock("QONE","is the Q1 yoke [TGeoVolume]"){ 
      }; 
      ~QONE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- QTWO -- 
   ///@defgroup QTWO_doc 
   ///@class QTWO 
   ///@brief is the Q2 yoke [TGeoVolume] 
   class QTWO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      QTWO() : AgBlock("QTWO","is the Q2 yoke [TGeoVolume]"){ 
      }; 
      ~QTWO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- QTHR -- 
   ///@defgroup QTHR_doc 
   ///@class QTHR 
   ///@brief is the Q3 yoke [TGeoVolume] 
   class QTHR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      QTHR() : AgBlock("QTHR","is the Q3 yoke [TGeoVolume]"){ 
      }; 
      ~QTHR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class QuadGeo 
   /// \brief  is the description of all the magnets upstream inclusive of D0  
   class QuadGeo : public AgModule 
   { 
      public: 
      QuadGeo(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~QuadGeo(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace QuadGeo 
#endif // __QuadGeo__ 
