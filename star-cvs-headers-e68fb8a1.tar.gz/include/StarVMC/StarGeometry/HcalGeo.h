#ifndef __HcalGeo__ 
#define __HcalGeo__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace HCALGEO // $NMSPC 
{ 
   struct mcdt_t {
float version;
float x;
float y;
float z;
float dx;
float dy;
float dz;
int _index;
};
 
   struct _mcdt_docum_ {
string version;
string x;
string y;
string z;
string dx;
string dy;
string dz;
string _index;
};
 
    struct _mcdt_types_ {
  typedef float version;
  typedef float x;
  typedef float y;
  typedef float z;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct mcdt_info {
typedef mcdt_t Type;
static const char *name(){ return "mcdt_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct mcdt_t, version ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct x {
  static const char *name() { return  "x"; }
  static int Offset(){ return offsetof( struct mcdt_t, x ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct y {
  static const char *name() { return  "y"; }
  static int Offset(){ return offsetof( struct mcdt_t, y ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct z {
  static const char *name() { return  "z"; }
  static int Offset(){ return offsetof( struct mcdt_t, z ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct mcdt_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct mcdt_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct mcdt_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct mcdt_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)mcdt_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct towr_t {
float version;
float dx;
float dy;
float dz;
float ntowerx;
float ntowery;
int _index;
};
 
   struct _towr_docum_ {
string version;
string dx;
string dy;
string dz;
string ntowerx;
string ntowery;
string _index;
};
 
    struct _towr_types_ {
  typedef float version;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef float ntowerx;
  typedef float ntowery;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct towr_info {
typedef towr_t Type;
static const char *name(){ return "towr_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct towr_t, version ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct towr_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct towr_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct towr_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ntowerx {
  static const char *name() { return  "ntowerx"; }
  static int Offset(){ return offsetof( struct towr_t, ntowerx ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ntowery {
  static const char *name() { return  "ntowery"; }
  static int Offset(){ return offsetof( struct towr_t, ntowery ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct towr_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)towr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct cell_t {
float version;
float dx;
float dy;
float dz;
float ncellx;
float ncelly;
float nfiberxl;
float nfiberyl;
float nfiberxs;
float nfiberys;
int _index;
};
 
   struct _cell_docum_ {
string version;
string dx;
string dy;
string dz;
string ncellx;
string ncelly;
string nfiberxl;
string nfiberyl;
string nfiberxs;
string nfiberys;
string _index;
};
 
    struct _cell_types_ {
  typedef float version;
  typedef float dx;
  typedef float dy;
  typedef float dz;
  typedef float ncellx;
  typedef float ncelly;
  typedef float nfiberxl;
  typedef float nfiberyl;
  typedef float nfiberxs;
  typedef float nfiberys;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct cell_info {
typedef cell_t Type;
static const char *name(){ return "cell_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct cell_t, version ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dx {
  static const char *name() { return  "dx"; }
  static int Offset(){ return offsetof( struct cell_t, dx ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dy {
  static const char *name() { return  "dy"; }
  static int Offset(){ return offsetof( struct cell_t, dy ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct cell_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ncellx {
  static const char *name() { return  "ncellx"; }
  static int Offset(){ return offsetof( struct cell_t, ncellx ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct ncelly {
  static const char *name() { return  "ncelly"; }
  static int Offset(){ return offsetof( struct cell_t, ncelly ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberxl {
  static const char *name() { return  "nfiberxl"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberxl ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberyl {
  static const char *name() { return  "nfiberyl"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberyl ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberxs {
  static const char *name() { return  "nfiberxs"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberxs ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct nfiberys {
  static const char *name() { return  "nfiberys"; }
  static int Offset(){ return offsetof( struct cell_t, nfiberys ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct cell_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)cell_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct fibr_t {
float version;
float rmin;
float rmax;
float dz;
float startx1;
float starty1;
float startx2;
float starty2;
float stepx;
float stepy;
int _index;
};
 
   struct _fibr_docum_ {
string version;
string rmin;
string rmax;
string dz;
string startx1;
string starty1;
string startx2;
string starty2;
string stepx;
string stepy;
string _index;
};
 
    struct _fibr_types_ {
  typedef float version;
  typedef float rmin;
  typedef float rmax;
  typedef float dz;
  typedef float startx1;
  typedef float starty1;
  typedef float startx2;
  typedef float starty2;
  typedef float stepx;
  typedef float stepy;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct fibr_info {
typedef fibr_t Type;
static const char *name(){ return "fibr_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct fibr_t, version ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct fibr_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct fibr_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct fibr_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct startx1 {
  static const char *name() { return  "startx1"; }
  static int Offset(){ return offsetof( struct fibr_t, startx1 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct starty1 {
  static const char *name() { return  "starty1"; }
  static int Offset(){ return offsetof( struct fibr_t, starty1 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct startx2 {
  static const char *name() { return  "startx2"; }
  static int Offset(){ return offsetof( struct fibr_t, startx2 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct starty2 {
  static const char *name() { return  "starty2"; }
  static int Offset(){ return offsetof( struct fibr_t, starty2 ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stepx {
  static const char *name() { return  "stepx"; }
  static int Offset(){ return offsetof( struct fibr_t, stepx ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct stepy {
  static const char *name() { return  "stepy"; }
  static int Offset(){ return offsetof( struct fibr_t, stepy ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct fibr_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)fibr_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct shld_t {
float version;
float xd;
float yd;
float zd;
float dxd;
float dyd;
float dzd;
int _index;
};
 
   struct _shld_docum_ {
string version;
string xd;
string yd;
string zd;
string dxd;
string dyd;
string dzd;
string _index;
};
 
    struct _shld_types_ {
  typedef float version;
  typedef float xd;
  typedef float yd;
  typedef float zd;
  typedef float dxd;
  typedef float dyd;
  typedef float dzd;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct shld_info {
typedef shld_t Type;
static const char *name(){ return "shld_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct shld_t, version ); }
  static void* address(){ 
         long long iadd = (long long)shld_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xd {
  static const char *name() { return  "xd"; }
  static int Offset(){ return offsetof( struct shld_t, xd ); }
  static void* address(){ 
         long long iadd = (long long)shld_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yd {
  static const char *name() { return  "yd"; }
  static int Offset(){ return offsetof( struct shld_t, yd ); }
  static void* address(){ 
         long long iadd = (long long)shld_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zd {
  static const char *name() { return  "zd"; }
  static int Offset(){ return offsetof( struct shld_t, zd ); }
  static void* address(){ 
         long long iadd = (long long)shld_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dxd {
  static const char *name() { return  "dxd"; }
  static int Offset(){ return offsetof( struct shld_t, dxd ); }
  static void* address(){ 
         long long iadd = (long long)shld_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dyd {
  static const char *name() { return  "dyd"; }
  static int Offset(){ return offsetof( struct shld_t, dyd ); }
  static void* address(){ 
         long long iadd = (long long)shld_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dzd {
  static const char *name() { return  "dzd"; }
  static int Offset(){ return offsetof( struct shld_t, dzd ); }
  static void* address(){ 
         long long iadd = (long long)shld_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct shld_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)shld_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   struct pres_t {
float version;
float xp1;
float yp1;
float zp1;
float rp1;
float xp2;
float yp2;
float zp2;
float rp2;
float xfe;
float yfe;
float zfe;
float rfe;
float strpxd;
float strpyd;
float strpzd;
float fexd;
float feyd;
float fezd;
float strips;
int _index;
};
 
   struct _pres_docum_ {
string version;
string xp1;
string yp1;
string zp1;
string rp1;
string xp2;
string yp2;
string zp2;
string rp2;
string xfe;
string yfe;
string zfe;
string rfe;
string strpxd;
string strpyd;
string strpzd;
string fexd;
string feyd;
string fezd;
string strips;
string _index;
};
 
    struct _pres_types_ {
  typedef float version;
  typedef float xp1;
  typedef float yp1;
  typedef float zp1;
  typedef float rp1;
  typedef float xp2;
  typedef float yp2;
  typedef float zp2;
  typedef float rp2;
  typedef float xfe;
  typedef float yfe;
  typedef float zfe;
  typedef float rfe;
  typedef float strpxd;
  typedef float strpyd;
  typedef float strpzd;
  typedef float fexd;
  typedef float feyd;
  typedef float fezd;
  typedef float strips;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct pres_info {
typedef pres_t Type;
static const char *name(){ return "pres_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct pres_t, version ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xp1 {
  static const char *name() { return  "xp1"; }
  static int Offset(){ return offsetof( struct pres_t, xp1 ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yp1 {
  static const char *name() { return  "yp1"; }
  static int Offset(){ return offsetof( struct pres_t, yp1 ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zp1 {
  static const char *name() { return  "zp1"; }
  static int Offset(){ return offsetof( struct pres_t, zp1 ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rp1 {
  static const char *name() { return  "rp1"; }
  static int Offset(){ return offsetof( struct pres_t, rp1 ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xp2 {
  static const char *name() { return  "xp2"; }
  static int Offset(){ return offsetof( struct pres_t, xp2 ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yp2 {
  static const char *name() { return  "yp2"; }
  static int Offset(){ return offsetof( struct pres_t, yp2 ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zp2 {
  static const char *name() { return  "zp2"; }
  static int Offset(){ return offsetof( struct pres_t, zp2 ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rp2 {
  static const char *name() { return  "rp2"; }
  static int Offset(){ return offsetof( struct pres_t, rp2 ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct xfe {
  static const char *name() { return  "xfe"; }
  static int Offset(){ return offsetof( struct pres_t, xfe ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct yfe {
  static const char *name() { return  "yfe"; }
  static int Offset(){ return offsetof( struct pres_t, yfe ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct zfe {
  static const char *name() { return  "zfe"; }
  static int Offset(){ return offsetof( struct pres_t, zfe ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rfe {
  static const char *name() { return  "rfe"; }
  static int Offset(){ return offsetof( struct pres_t, rfe ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct strpxd {
  static const char *name() { return  "strpxd"; }
  static int Offset(){ return offsetof( struct pres_t, strpxd ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct strpyd {
  static const char *name() { return  "strpyd"; }
  static int Offset(){ return offsetof( struct pres_t, strpyd ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct strpzd {
  static const char *name() { return  "strpzd"; }
  static int Offset(){ return offsetof( struct pres_t, strpzd ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fexd {
  static const char *name() { return  "fexd"; }
  static int Offset(){ return offsetof( struct pres_t, fexd ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct feyd {
  static const char *name() { return  "feyd"; }
  static int Offset(){ return offsetof( struct pres_t, feyd ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct fezd {
  static const char *name() { return  "fezd"; }
  static int Offset(){ return offsetof( struct pres_t, fezd ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct strips {
  static const char *name() { return  "strips"; }
  static int Offset(){ return offsetof( struct pres_t, strips ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct pres_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)pres_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- HCMO -- 
   ///@defgroup HCMO_doc 
   ///@class HCMO 
   ///@brief Mother Calorimeter [TGeoVolume] 
   class HCMO : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCMO() : AgBlock("HCMO","Mother Calorimeter [TGeoVolume]"){ 
      }; 
      ~HCMO(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HTWR -- 
   ///@defgroup HTWR_doc 
   ///@class HTWR 
   ///@brief Towrs  of Calorimeter [TGeoVolume] 
   class HTWR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HTWR() : AgBlock("HTWR","Towrs  of Calorimeter [TGeoVolume]"){ 
      }; 
      ~HTWR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCES -- 
   ///@defgroup HCES_doc 
   ///@class HCES 
   ///@brief 3*3 cell in tower, HCES has 15*15 fibers [TGeoVolume] 
   class HCES : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCES() : AgBlock("HCES","3*3 cell in tower, HCES has 15*15 fibers [TGeoVolume]"){ 
      }; 
      ~HCES(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCEL -- 
   ///@defgroup HCEL_doc 
   ///@class HCEL 
   ///@brief 3*3 cell in tower, HCES has 16*16 fibers [TGeoVolume] 
   class HCEL : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCEL() : AgBlock("HCEL","3*3 cell in tower, HCES has 16*16 fibers [TGeoVolume]"){ 
      }; 
      ~HCEL(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCSX -- 
   ///@defgroup HCSX_doc 
   ///@class HCSX 
   ///@brief 3*3 cell in tower x divisions [TGeoVolume] 
   class HCSX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCSX() : AgBlock("HCSX","3*3 cell in tower x divisions [TGeoVolume]"){ 
      }; 
      ~HCSX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCSY -- 
   ///@defgroup HCSY_doc 
   ///@class HCSY 
   ///@brief 3*3 cell in tower y divisions [TGeoVolume] 
   class HCSY : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCSY() : AgBlock("HCSY","3*3 cell in tower y divisions [TGeoVolume]"){ 
      }; 
      ~HCSY(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCLX -- 
   ///@defgroup HCLX_doc 
   ///@class HCLX 
   ///@brief 3*3 cell in tower x divisions [TGeoVolume] 
   class HCLX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCLX() : AgBlock("HCLX","3*3 cell in tower x divisions [TGeoVolume]"){ 
      }; 
      ~HCLX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HCLY -- 
   ///@defgroup HCLY_doc 
   ///@class HCLY 
   ///@brief 3*3 cell in tower y divisions [TGeoVolume] 
   class HCLY : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HCLY() : AgBlock("HCLY","3*3 cell in tower y divisions [TGeoVolume]"){ 
      }; 
      ~HCLY(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HFIB -- 
   ///@defgroup HFIB_doc 
   ///@class HFIB 
   ///@brief fiber in cells [TGeoVolume] 
   class HFIB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HFIB() : AgBlock("HFIB","fiber in cells [TGeoVolume]"){ 
      }; 
      ~HFIB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HFIC -- 
   ///@defgroup HFIC_doc 
   ///@class HFIC 
   ///@brief fiber in cells [TGeoVolume] 
   class HFIC : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HFIC() : AgBlock("HFIC","fiber in cells [TGeoVolume]"){ 
      }; 
      ~HFIC(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HSLD -- 
   ///@defgroup HSLD_doc 
   ///@class HSLD 
   ///@brief Base Iron plate [TGeoVolume] 
   class HSLD : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HSLD() : AgBlock("HSLD","Base Iron plate [TGeoVolume]"){ 
      }; 
      ~HSLD(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HSWR -- 
   ///@defgroup HSWR_doc 
   ///@class HSWR 
   ///@brief Mother of pre shower [TGeoVolume] 
   class HSWR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HSWR() : AgBlock("HSWR","Mother of pre shower [TGeoVolume]"){ 
      }; 
      ~HSWR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HSTP -- 
   ///@defgroup HSTP_doc 
   ///@class HSTP 
   ///@brief single strips in pre shower [TGeoVolume] 
   class HSTP : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HSTP() : AgBlock("HSTP","single strips in pre shower [TGeoVolume]"){ 
      }; 
      ~HSTP(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- HSFE -- 
   ///@defgroup HSFE_doc 
   ///@class HSFE 
   ///@brief Fe in between two pre shower [TGeoVolume] 
   class HSFE : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      HSFE() : AgBlock("HSFE","Fe in between two pre shower [TGeoVolume]"){ 
      }; 
      ~HSFE(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class HcalGeo 
   /// \brief  forward hadronic calorimeter, test run, 2014 
   class HcalGeo : public AgModule 
   { 
      public: 
      HcalGeo(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~HcalGeo(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace HcalGeo 
#endif // __HcalGeo__ 
