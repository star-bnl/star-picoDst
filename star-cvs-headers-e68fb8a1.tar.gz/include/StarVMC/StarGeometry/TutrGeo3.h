#ifndef __TutrGeo3__ 
#define __TutrGeo3__ 

/*
 ******************************************************************************
 ******************************************************************************
 **                                                                          **
 ** This is generated code.  Do not alter.  You should instead edit the XML  **
 ** module which corresponds to your detector.  This code will be replaced   **
 ** on the next compilation.                                                 **
 **                                                                          **
 ******************************************************************************
 ******************************************************************************
 */
 
 
#include "StarVMC/StarAgmlLib/AgModule.h" 
#include "StarVMC/StarAgmlLib/AgMLStructure.h" 
#include <stddef.h> 
 
namespace TUTRGEO3 // $NMSPC 
{ 
   struct tubg_t {
int version;
float rmin;
float rmax;
float dz;
int _index;
};
 
   struct _tubg_docum_ {
string version;
string rmin;
string rmax;
string dz;
string _index;
};
 
    struct _tubg_types_ {
  typedef int version;
  typedef float rmin;
  typedef float rmax;
  typedef float dz;
  typedef int _index;
};
 
   
#ifndef __CINT__

struct tubg_info {
typedef tubg_t Type;
static const char *name(){ return "tubg_t"; }
struct version {
  static const char *name() { return  "version"; }
  static int Offset(){ return offsetof( struct tubg_t, version ); }
  static void* address(){ 
         long long iadd = (long long)tubg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
struct rmin {
  static const char *name() { return  "rmin"; }
  static int Offset(){ return offsetof( struct tubg_t, rmin ); }
  static void* address(){ 
         long long iadd = (long long)tubg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct rmax {
  static const char *name() { return  "rmax"; }
  static int Offset(){ return offsetof( struct tubg_t, rmax ); }
  static void* address(){ 
         long long iadd = (long long)tubg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct dz {
  static const char *name() { return  "dz"; }
  static int Offset(){ return offsetof( struct tubg_t, dz ); }
  static void* address(){ 
         long long iadd = (long long)tubg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef float Type;
  static const int rank = 0;};
struct _index {
  static const char *name() { return  "_index"; }
  static int Offset(){ return offsetof( struct tubg_t, _index ); }
  static void* address(){ 
         long long iadd = (long long)tubg_info::address;
         iadd += Offset();
         return (void *)iadd;}
  typedef int Type;
  static const int rank = 0;};
static void              *address;
static AgMLStructureBase *structure;
};
#endif
 
   // ---------------------------------------------------------------------- TUTR -- 
   ///@defgroup TUTR_doc 
   ///@class TUTR 
   ///@brief Main volume in the AGML tutorial geometry [TGeoVolume] 
   class TUTR : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      TUTR() : AgBlock("TUTR","Main volume in the AGML tutorial geometry [TGeoVolume]"){ 
      }; 
      ~TUTR(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ABOX -- 
   ///@defgroup ABOX_doc 
   ///@class ABOX 
   ///@brief A volume which is a box in the tutorial [TGeoVolume] 
   class ABOX : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ABOX() : AgBlock("ABOX","A volume which is a box in the tutorial [TGeoVolume]"){ 
      }; 
      ~ABOX(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   // ---------------------------------------------------------------------- ATUB -- 
   ///@defgroup ATUB_doc 
   ///@class ATUB 
   ///@brief A volume which is a tube in the tutorial [TGeoVolume] 
   class ATUB : public AgBlock 
   {  public: 
         static AgBlock *Instance(); 
      ATUB() : AgBlock("ATUB","A volume which is a tube in the tutorial [TGeoVolume]"){ 
      }; 
      ~ATUB(){ }; 
      virtual void Block( AgCreate c ); 
      virtual void End(){ }; 
      protected: 
        static AgBlock *mInstance; 
   }; 
   /// \class TutrGeo3 
   /// \brief Tutorial Geometry 1 
   class TutrGeo3 : public AgModule 
   { 
      public: 
      TutrGeo3(); 
      virtual void ConstructGeometry( const Char_t *dummy="" ); 
      ~TutrGeo3(){ }; 
      public: 
   }; 
   // endElement in class Module 
}; // namespace TutrGeo3 
#endif // __TutrGeo3__ 
