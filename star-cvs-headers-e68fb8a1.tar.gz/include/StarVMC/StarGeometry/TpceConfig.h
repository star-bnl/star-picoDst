#ifndef __TPCE_CONFIG__ 
#define __TPCE_CONFIG__ 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/TpceGeo2.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/TpceGeo3a.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/TpceGeo4.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/TpceGeo1.h" 
# include "/home/smirnovd/sb/build-star-cvs-debug/StarVMC/StarGeometry/TpceGeo5.h" 
namespace TPCE { //
struct TPCEof {
  static const char *name()    { return "TPCEof"; }
  static const char *comment() { return "OFF"; }
  static const char *module()  { return "TpceGeo4"; }
  static       bool  list();
  typedef TPCEGEO4::TpceGeo4 Module;
  static const bool onoff = false;
  static       AgModule* New(){ return NULL; }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCE00 {
  static const char *name()    { return "TPCE00"; }
  static const char *comment() { return "New version of the TPC backplane "; }
  static const char *module()  { return "TpceGeo1"; }
  static       bool  list();
  typedef TPCEGEO1::TpceGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCE01 {
  static const char *name()    { return "TPCE01"; }
  static const char *comment() { return "New version of the TPC backplane;gas density correction"; }
  static const char *module()  { return "TpceGeo1"; }
  static       bool  list();
  typedef TPCEGEO1::TpceGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCE02 {
  static const char *name()    { return "TPCE02"; }
  static const char *comment() { return "New version of the TPC backplane;gas density correction"; }
  static const char *module()  { return "TpceGeo1"; }
  static       bool  list();
  typedef TPCEGEO1::TpceGeo1 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCE03 {
  static const char *name()    { return "TPCE03"; }
  static const char *comment() { return "New version of the TPC backplane;gas density correction"; }
  static const char *module()  { return "TpceGeo2"; }
  static       bool  list();
  typedef TPCEGEO2::TpceGeo2 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCE04 {
  static const char *name()    { return "TPCE04"; }
  static const char *comment() { return "New version of the TPC backplane;gas density correction"; }
  static const char *module()  { return "TpceGeo3a"; }
  static       bool  list();
  typedef TPCEGEO3A::TpceGeo3a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCE04r {
  static const char *name()    { return "TPCE04r"; }
  static const char *comment() { return "New version of the TPC backplane;gas density correction;radius correction"; }
  static const char *module()  { return "TpceGeo3a"; }
  static       bool  list();
  typedef TPCEGEO3A::TpceGeo3a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCE30 {
  static const char *name()    { return "TPCE30"; }
  static const char *comment() { return "New version of the TPC backplane;gas density correction;radius correction;same as TPCE04r"; }
  static const char *module()  { return "TpceGeo3a"; }
  static       bool  list();
  typedef TPCEGEO3A::TpceGeo3a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCE31 {
  static const char *name()    { return "TPCE31"; }
  static const char *comment() { return "New version of the TPC backplane;gas density correction;radius correction;same as TPCE04r"; }
  static const char *module()  { return "TpceGeo3a"; }
  static       bool  list();
  typedef TPCEGEO3A::TpceGeo3a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCE31a {
  static const char *name()    { return "TPCE31a"; }
  static const char *comment() { return "New version of the TPC backplane;gas density correction;radius correction;same as TPCE04r"; }
  static const char *module()  { return "TpceGeo3a"; }
  static       bool  list();
  typedef TPCEGEO3A::TpceGeo3a Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
namespace TPCE { //
struct TPCEv5 {
  static const char *name()    { return "TPCEv5"; }
  static const char *comment() { return "Version 5: implements full sensitivity for TPC gas volume"; }
  static const char *module()  { return "TpceGeo5"; }
  static       bool  list();
  typedef TPCEGEO5::TpceGeo5 Module;
  static const bool onoff = true;
  static       AgModule* New(){ return new Module(); }
  static       void  setup();
  static       AgModule* construct();
};
};
 
#endif 
