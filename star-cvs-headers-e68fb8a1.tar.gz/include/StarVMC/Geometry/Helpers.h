#define CALBPAR(x,y) /* == BEMC Geometries should be refactored so that media are set explicitly == */
#define AgDETPnew(x) { /* AgDetpNew not yet supported */ }
#define AgDETPadd(x,y,z) {/* AgDetpAdd not yet supported */ }
