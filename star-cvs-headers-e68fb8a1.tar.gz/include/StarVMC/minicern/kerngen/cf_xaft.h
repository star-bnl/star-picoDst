/*
* $Id: cf_xaft.h,v 1.1 2004/07/17 20:01:57 perev Exp $
*
* $Log: cf_xaft.h,v $
* Revision 1.1  2004/07/17 20:01:57  perev
* Initial revision
*
* Revision 1.1.1.1  2002/07/24 15:56:28  rdm
* initial import into CVS
*
* Revision 1.1.1.1  2002/06/16 15:18:46  hristov
* Separate distribution  of Geant3
*
* Revision 1.1.1.1  1999/05/18 15:55:29  fca
* AliRoot sources
*
* Revision 1.1.1.1  1996/02/15 17:49:17  mclareni
* Kernlib
*
*
*
* cf#xaft.inc
*/
#if defined(CERNLIB_PROJSHIFT)
#include <shift.h>
#endif
