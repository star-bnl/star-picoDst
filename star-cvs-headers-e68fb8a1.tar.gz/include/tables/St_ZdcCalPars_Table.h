
#ifndef STAF_St_ZdcCalPars_Table
#define STAF_St_ZdcCalPars_Table

#include "TTable.h"

#include "ZdcCalPars.h"

/*!
 * \class  St_ZdcCalPars
 * \brief  C++ wrapper for <ZdcCalPars> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:59 2018
 *
 * This was generated for version 'DEV'
 */
class St_ZdcCalPars : public TTable
{
 public:
   ClassDefTable(St_ZdcCalPars,ZdcCalPars_st)
   ClassDef(St_ZdcCalPars,2) //C++ wrapper for <ZdcCalPars> StAF table
};
#endif
