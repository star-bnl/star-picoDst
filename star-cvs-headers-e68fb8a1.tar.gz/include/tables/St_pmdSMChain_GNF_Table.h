
#ifndef STAF_St_pmdSMChain_GNF_Table
#define STAF_St_pmdSMChain_GNF_Table

#include "TTable.h"

#include "pmdSMChain_GNF.h"

/*!
 * \class  St_pmdSMChain_GNF
 * \brief  C++ wrapper for <pmdSMChain_GNF> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:18 2018
 *
 * This was generated for version 'DEV'
 */
class St_pmdSMChain_GNF : public TTable
{
 public:
   ClassDefTable(St_pmdSMChain_GNF,pmdSMChain_GNF_st)
   ClassDef(St_pmdSMChain_GNF,2) //C++ wrapper for <pmdSMChain_GNF> StAF table
};
#endif
