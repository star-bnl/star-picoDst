
#ifndef STAF_St_istGain_Table
#define STAF_St_istGain_Table

#include "TTable.h"

#include "istGain.h"

/*!
 * \class  St_istGain
 * \brief  C++ wrapper for <istGain> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:14 2018
 *
 * This was generated for version 'DEV'
 */
class St_istGain : public TTable
{
 public:
   ClassDefTable(St_istGain,istGain_st)
   ClassDef(St_istGain,2) //C++ wrapper for <istGain> StAF table
};
#endif
