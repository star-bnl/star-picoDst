
#ifndef STAF_St_mtdQTSlewingCorrPart2_Table
#define STAF_St_mtdQTSlewingCorrPart2_Table

#include "TTable.h"

#include "mtdQTSlewingCorrPart2.h"

/*!
 * \class  St_mtdQTSlewingCorrPart2
 * \brief  C++ wrapper for <mtdQTSlewingCorrPart2> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:16 2018
 *
 * This was generated for version 'DEV'
 */
class St_mtdQTSlewingCorrPart2 : public TTable
{
 public:
   ClassDefTable(St_mtdQTSlewingCorrPart2,mtdQTSlewingCorrPart2_st)
   ClassDef(St_mtdQTSlewingCorrPart2,2) //C++ wrapper for <mtdQTSlewingCorrPart2> StAF table
};
#endif
