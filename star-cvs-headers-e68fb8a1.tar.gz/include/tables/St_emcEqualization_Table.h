
#ifndef STAF_St_emcEqualization_Table
#define STAF_St_emcEqualization_Table

#include "TTable.h"

#include "emcEqualization.h"

/*!
 * \class  St_emcEqualization
 * \brief  C++ wrapper for <emcEqualization> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:04 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcEqualization : public TTable
{
 public:
   ClassDefTable(St_emcEqualization,emcEqualization_st)
   ClassDef(St_emcEqualization,2) //C++ wrapper for <emcEqualization> StAF table
};
#endif
