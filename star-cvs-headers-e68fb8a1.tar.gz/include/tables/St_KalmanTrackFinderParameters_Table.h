
#ifndef STAF_St_KalmanTrackFinderParameters_Table
#define STAF_St_KalmanTrackFinderParameters_Table

#include "TTable.h"

#include "KalmanTrackFinderParameters.h"

/*!
 * \class  St_KalmanTrackFinderParameters
 * \brief  C++ wrapper for <KalmanTrackFinderParameters> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:28 2018
 *
 * This was generated for version 'DEV'
 */
class St_KalmanTrackFinderParameters : public TTable
{
 public:
   ClassDefTable(St_KalmanTrackFinderParameters,KalmanTrackFinderParameters_st)
   ClassDef(St_KalmanTrackFinderParameters,2) //C++ wrapper for <KalmanTrackFinderParameters> StAF table
};
#endif
