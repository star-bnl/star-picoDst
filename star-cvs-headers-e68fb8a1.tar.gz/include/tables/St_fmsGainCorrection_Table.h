
#ifndef STAF_St_fmsGainCorrection_Table
#define STAF_St_fmsGainCorrection_Table

#include "TTable.h"

#include "fmsGainCorrection.h"

/*!
 * \class  St_fmsGainCorrection
 * \brief  C++ wrapper for <fmsGainCorrection> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:08 2018
 *
 * This was generated for version 'DEV'
 */
class St_fmsGainCorrection : public TTable
{
 public:
   ClassDefTable(St_fmsGainCorrection,fmsGainCorrection_st)
   ClassDef(St_fmsGainCorrection,2) //C++ wrapper for <fmsGainCorrection> StAF table
};
#endif
