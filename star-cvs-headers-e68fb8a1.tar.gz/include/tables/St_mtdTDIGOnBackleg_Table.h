
#ifndef STAF_St_mtdTDIGOnBackleg_Table
#define STAF_St_mtdTDIGOnBackleg_Table

#include "TTable.h"

#include "mtdTDIGOnBackleg.h"

/*!
 * \class  St_mtdTDIGOnBackleg
 * \brief  C++ wrapper for <mtdTDIGOnBackleg> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:16 2018
 *
 * This was generated for version 'DEV'
 */
class St_mtdTDIGOnBackleg : public TTable
{
 public:
   ClassDefTable(St_mtdTDIGOnBackleg,mtdTDIGOnBackleg_st)
   ClassDef(St_mtdTDIGOnBackleg,2) //C++ wrapper for <mtdTDIGOnBackleg> StAF table
};
#endif
