
#ifndef STAF_St_svg_shape_Table
#define STAF_St_svg_shape_Table

#include "TTable.h"

#include "svg_shape.h"

/*!
 * \class  St_svg_shape
 * \brief  C++ wrapper for <svg_shape> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:27 2018
 *
 * This was generated for version 'DEV'
 */
class St_svg_shape : public TTable
{
 public:
   ClassDefTable(St_svg_shape,svg_shape_st)
   ClassDef(St_svg_shape,2) //C++ wrapper for <svg_shape> StAF table
};
#endif
