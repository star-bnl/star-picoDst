
#ifndef STAF_St_pp2ppAcceleratorParameters_Table
#define STAF_St_pp2ppAcceleratorParameters_Table

#include "TTable.h"

#include "pp2ppAcceleratorParameters.h"

/*!
 * \class  St_pp2ppAcceleratorParameters
 * \brief  C++ wrapper for <pp2ppAcceleratorParameters> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:19 2018
 *
 * This was generated for version 'DEV'
 */
class St_pp2ppAcceleratorParameters : public TTable
{
 public:
   ClassDefTable(St_pp2ppAcceleratorParameters,pp2ppAcceleratorParameters_st)
   ClassDef(St_pp2ppAcceleratorParameters,2) //C++ wrapper for <pp2ppAcceleratorParameters> StAF table
};
#endif
