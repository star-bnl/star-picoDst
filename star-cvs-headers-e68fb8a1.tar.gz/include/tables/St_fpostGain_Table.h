
#ifndef STAF_St_fpostGain_Table
#define STAF_St_fpostGain_Table

#include "TTable.h"

#include "fpostGain.h"

/*!
 * \class  St_fpostGain
 * \brief  C++ wrapper for <fpostGain> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:10 2018
 *
 * This was generated for version 'DEV'
 */
class St_fpostGain : public TTable
{
 public:
   ClassDefTable(St_fpostGain,fpostGain_st)
   ClassDef(St_fpostGain,2) //C++ wrapper for <fpostGain> StAF table
};
#endif
