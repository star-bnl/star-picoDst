
#ifndef STAF_St_daqEventTag_Table
#define STAF_St_daqEventTag_Table

#include "TTable.h"

#include "daqEventTag.h"

/*!
 * \class  St_daqEventTag
 * \brief  C++ wrapper for <daqEventTag> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:02 2018
 *
 * This was generated for version 'DEV'
 */
class St_daqEventTag : public TTable
{
 public:
   ClassDefTable(St_daqEventTag,daqEventTag_st)
   ClassDef(St_daqEventTag,2) //C++ wrapper for <daqEventTag> StAF table
};
#endif
