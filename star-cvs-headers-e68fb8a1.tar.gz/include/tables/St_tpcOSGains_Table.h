
#ifndef STAF_St_tpcOSGains_Table
#define STAF_St_tpcOSGains_Table

#include "TTable.h"

#include "tpcOSGains.h"

/*!
 * \class  St_tpcOSGains
 * \brief  C++ wrapper for <tpcOSGains> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:32 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcOSGains : public TTable
{
 public:
   ClassDefTable(St_tpcOSGains,tpcOSGains_st)
   ClassDef(St_tpcOSGains,2) //C++ wrapper for <tpcOSGains> StAF table
};
#endif
