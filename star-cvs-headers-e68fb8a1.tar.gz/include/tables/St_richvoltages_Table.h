
#ifndef STAF_St_richvoltages_Table
#define STAF_St_richvoltages_Table

#include "TTable.h"

#include "richvoltages.h"

/*!
 * \class  St_richvoltages
 * \brief  C++ wrapper for <richvoltages> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:20 2018
 *
 * This was generated for version 'DEV'
 */
class St_richvoltages : public TTable
{
 public:
   ClassDefTable(St_richvoltages,richvoltages_st)
   ClassDef(St_richvoltages,2) //C++ wrapper for <richvoltages> StAF table
};
#endif
