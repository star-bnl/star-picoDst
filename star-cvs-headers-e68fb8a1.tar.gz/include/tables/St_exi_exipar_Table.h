
#ifndef STAF_St_exi_exipar_Table
#define STAF_St_exi_exipar_Table

#include "TTable.h"

#include "exi_exipar.h"

/*!
 * \class  St_exi_exipar
 * \brief  C++ wrapper for <exi_exipar> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:18:32 2018
 *
 * This was generated for version 'DEV'
 */
class St_exi_exipar : public TTable
{
 public:
   ClassDefTable(St_exi_exipar,exi_exipar_st)
   ClassDef(St_exi_exipar,2) //C++ wrapper for <exi_exipar> StAF table
};
#endif
