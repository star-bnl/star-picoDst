
#ifndef STAF_St_ems_hits_Table
#define STAF_St_ems_hits_Table

#include "TTable.h"

#include "ems_hits.h"

/*!
 * \class  St_ems_hits
 * \brief  C++ wrapper for <ems_hits> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:39 2018
 *
 * This was generated for version 'DEV'
 */
class St_ems_hits : public TTable
{
 public:
   ClassDefTable(St_ems_hits,ems_hits_st)
   ClassDef(St_ems_hits,2) //C++ wrapper for <ems_hits> StAF table
};
#endif
