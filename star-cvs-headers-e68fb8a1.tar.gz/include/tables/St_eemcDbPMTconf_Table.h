
#ifndef STAF_St_eemcDbPMTconf_Table
#define STAF_St_eemcDbPMTconf_Table

#include "TTable.h"

#include "eemcDbPMTconf.h"

/*!
 * \class  St_eemcDbPMTconf
 * \brief  C++ wrapper for <eemcDbPMTconf> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:03 2018
 *
 * This was generated for version 'DEV'
 */
class St_eemcDbPMTconf : public TTable
{
 public:
   ClassDefTable(St_eemcDbPMTconf,eemcDbPMTconf_st)
   ClassDef(St_eemcDbPMTconf,2) //C++ wrapper for <eemcDbPMTconf> StAF table
};
#endif
