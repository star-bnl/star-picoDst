
#ifndef STAF_St_fgtAlignment_Table
#define STAF_St_fgtAlignment_Table

#include "TTable.h"

#include "fgtAlignment.h"

/*!
 * \class  St_fgtAlignment
 * \brief  C++ wrapper for <fgtAlignment> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:06 2018
 *
 * This was generated for version 'DEV'
 */
class St_fgtAlignment : public TTable
{
 public:
   ClassDefTable(St_fgtAlignment,fgtAlignment_st)
   ClassDef(St_fgtAlignment,2) //C++ wrapper for <fgtAlignment> StAF table
};
#endif
