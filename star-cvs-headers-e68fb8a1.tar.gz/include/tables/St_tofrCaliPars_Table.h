
#ifndef STAF_St_tofrCaliPars_Table
#define STAF_St_tofrCaliPars_Table

#include "TTable.h"

#include "tofrCaliPars.h"

/*!
 * \class  St_tofrCaliPars
 * \brief  C++ wrapper for <tofrCaliPars> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:29 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofrCaliPars : public TTable
{
 public:
   ClassDefTable(St_tofrCaliPars,tofrCaliPars_st)
   ClassDef(St_tofrCaliPars,2) //C++ wrapper for <tofrCaliPars> StAF table
};
#endif
