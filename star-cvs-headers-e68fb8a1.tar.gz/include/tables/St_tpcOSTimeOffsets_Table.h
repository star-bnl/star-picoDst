
#ifndef STAF_St_tpcOSTimeOffsets_Table
#define STAF_St_tpcOSTimeOffsets_Table

#include "TTable.h"

#include "tpcOSTimeOffsets.h"

/*!
 * \class  St_tpcOSTimeOffsets
 * \brief  C++ wrapper for <tpcOSTimeOffsets> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:32 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcOSTimeOffsets : public TTable
{
 public:
   ClassDefTable(St_tpcOSTimeOffsets,tpcOSTimeOffsets_st)
   ClassDef(St_tpcOSTimeOffsets,2) //C++ wrapper for <tpcOSTimeOffsets> StAF table
};
#endif
