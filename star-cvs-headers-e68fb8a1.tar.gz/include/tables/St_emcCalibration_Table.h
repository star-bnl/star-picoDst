
#ifndef STAF_St_emcCalibration_Table
#define STAF_St_emcCalibration_Table

#include "TTable.h"

#include "emcCalibration.h"

/*!
 * \class  St_emcCalibration
 * \brief  C++ wrapper for <emcCalibration> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:04 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcCalibration : public TTable
{
 public:
   ClassDefTable(St_emcCalibration,emcCalibration_st)
   ClassDef(St_emcCalibration,2) //C++ wrapper for <emcCalibration> StAF table
};
#endif
