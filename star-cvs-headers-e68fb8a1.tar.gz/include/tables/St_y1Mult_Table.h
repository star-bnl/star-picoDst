
#ifndef STAF_St_y1Mult_Table
#define STAF_St_y1Mult_Table

#include "TTable.h"

#include "y1Mult.h"

/*!
 * \class  St_y1Mult
 * \brief  C++ wrapper for <y1Mult> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:36 2018
 *
 * This was generated for version 'DEV'
 */
class St_y1Mult : public TTable
{
 public:
   ClassDefTable(St_y1Mult,y1Mult_st)
   ClassDef(St_y1Mult,2) //C++ wrapper for <y1Mult> StAF table
};
#endif
