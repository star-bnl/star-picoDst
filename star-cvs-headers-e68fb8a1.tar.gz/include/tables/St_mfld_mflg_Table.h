
#ifndef STAF_St_mfld_mflg_Table
#define STAF_St_mfld_mflg_Table

#include "TTable.h"

#include "mfld_mflg.h"

/*!
 * \class  St_mfld_mflg
 * \brief  C++ wrapper for <mfld_mflg> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:26 2018
 *
 * This was generated for version 'DEV'
 */
class St_mfld_mflg : public TTable
{
 public:
   ClassDefTable(St_mfld_mflg,mfld_mflg_st)
   ClassDef(St_mfld_mflg,2) //C++ wrapper for <mfld_mflg> StAF table
};
#endif
