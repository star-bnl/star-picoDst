
#ifndef STAF_St_dst_TrgDet_Table
#define STAF_St_dst_TrgDet_Table

#include "TTable.h"

#include "dst_TrgDet.h"

/*!
 * \class  St_dst_TrgDet
 * \brief  C++ wrapper for <dst_TrgDet> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:18:32 2018
 *
 * This was generated for version 'DEV'
 */
class St_dst_TrgDet : public TTable
{
 public:
   ClassDefTable(St_dst_TrgDet,dst_TrgDet_st)
   ClassDef(St_dst_TrgDet,2) //C++ wrapper for <dst_TrgDet> StAF table
};
#endif
