#ifndef STAF_St_g2t_particle_Module
#define STAF_St_g2t_particle_Module

#include "St_Module.h"

#ifdef __CINT__
 class table_head_st;
 class particle_st;
 class St_particle;
#else
#include "tables/St_particle_Table.h"
#endif


class St_g2t_particle : public St_Module
{
public:
  St_g2t_particle() : St_Module(){}

// Passing the "simple" structures

 typedef enum { 
    kParticle0
 } Eg2t_particle;

// Passing the C++ objects

  St_g2t_particle(
     St_particle *o0
  );
  Int_t operator()(
     St_particle *o0
  );

// Calling the wrapped STAF module

 Int_t ExecuteModule();

  const Char_t *GetName(){return "g2t_particle";}
 ClassDef(St_g2t_particle,0) // class-wrapper to cal g2t_particle module 
};


R__EXTERN St_g2t_particle &g2t_particle; 

#endif
