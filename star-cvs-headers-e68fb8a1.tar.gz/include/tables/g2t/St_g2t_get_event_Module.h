#ifndef STAF_St_g2t_get_event_Module
#define STAF_St_g2t_get_event_Module

#include "St_Module.h"

#ifdef __CINT__
 class table_head_st;
 class g2t_event_st;
 class St_g2t_event;
#else
#include "tables/St_g2t_event_Table.h"
#endif


class St_g2t_get_event : public St_Module
{
public:
  St_g2t_get_event() : St_Module(){}

// Passing the "simple" structures

 typedef enum { 
    kG2t_event0
 } Eg2t_get_event;

// Passing the C++ objects

  St_g2t_get_event(
     St_g2t_event *o0
  );
  Int_t operator()(
     St_g2t_event *o0
  );

// Calling the wrapped STAF module

 Int_t ExecuteModule();

  const Char_t *GetName(){return "g2t_get_event";}
 ClassDef(St_g2t_get_event,0) // class-wrapper to cal g2t_get_event module 
};


R__EXTERN St_g2t_get_event &g2t_get_event; 

#endif
