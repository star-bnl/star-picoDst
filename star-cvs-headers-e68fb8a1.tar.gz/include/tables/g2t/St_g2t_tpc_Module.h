#ifndef STAF_St_g2t_tpc_Module
#define STAF_St_g2t_tpc_Module

#include "St_Module.h"

#ifdef __CINT__
 class table_head_st;
 class g2t_track_st;
 class g2t_tpc_hit_st;
 class St_g2t_track;
 class St_g2t_tpc_hit;
#else
#include "tables/St_g2t_track_Table.h"
#include "tables/St_g2t_tpc_hit_Table.h"
#endif


class St_g2t_tpc : public St_Module
{
public:
  St_g2t_tpc() : St_Module(){}

// Passing the "simple" structures

 typedef enum { 
    kG2t_track0,
    kG2t_tpc_hit1
 } Eg2t_tpc;

// Passing the C++ objects

  St_g2t_tpc(
     St_g2t_track *o0,
     St_g2t_tpc_hit *o1
  );
  Int_t operator()(
     St_g2t_track *o0,
     St_g2t_tpc_hit *o1
  );

// Calling the wrapped STAF module

 Int_t ExecuteModule();

  const Char_t *GetName(){return "g2t_tpc";}
 ClassDef(St_g2t_tpc,0) // class-wrapper to cal g2t_tpc module 
};


R__EXTERN St_g2t_tpc &g2t_tpc; 

#endif
