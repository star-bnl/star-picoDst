#ifndef STAF_St_g2t_get_kine_Module
#define STAF_St_g2t_get_kine_Module

#include "St_Module.h"

#ifdef __CINT__
 class table_head_st;
 class g2t_vertex_st;
 class g2t_track_st;
 class St_g2t_vertex;
 class St_g2t_track;
#else
#include "tables/St_g2t_vertex_Table.h"
#include "tables/St_g2t_track_Table.h"
#endif


class St_g2t_get_kine : public St_Module
{
public:
  St_g2t_get_kine() : St_Module(){}

// Passing the "simple" structures

 typedef enum { 
    kG2t_vertex0,
    kG2t_track1
 } Eg2t_get_kine;

// Passing the C++ objects

  St_g2t_get_kine(
     St_g2t_vertex *o0,
     St_g2t_track *o1
  );
  Int_t operator()(
     St_g2t_vertex *o0,
     St_g2t_track *o1
  );

// Calling the wrapped STAF module

 Int_t ExecuteModule();

  const Char_t *GetName(){return "g2t_get_kine";}
 ClassDef(St_g2t_get_kine,0) // class-wrapper to cal g2t_get_kine module 
};


R__EXTERN St_g2t_get_kine &g2t_get_kine; 

#endif
