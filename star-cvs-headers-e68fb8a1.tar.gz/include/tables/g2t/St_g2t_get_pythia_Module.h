#ifndef STAF_St_g2t_get_pythia_Module
#define STAF_St_g2t_get_pythia_Module

#include "St_Module.h"

#ifdef __CINT__
 class table_head_st;
 class g2t_pythia_st;
 class St_g2t_pythia;
#else
#include "tables/St_g2t_pythia_Table.h"
#endif


class St_g2t_get_pythia : public St_Module
{
public:
  St_g2t_get_pythia() : St_Module(){}

// Passing the "simple" structures

 typedef enum { 
    kG2t_pythia0
 } Eg2t_get_pythia;

// Passing the C++ objects

  St_g2t_get_pythia(
     St_g2t_pythia *o0
  );
  Int_t operator()(
     St_g2t_pythia *o0
  );

// Calling the wrapped STAF module

 Int_t ExecuteModule();

  const Char_t *GetName(){return "g2t_get_pythia";}
 ClassDef(St_g2t_get_pythia,0) // class-wrapper to cal g2t_get_pythia module 
};


R__EXTERN St_g2t_get_pythia &g2t_get_pythia; 

#endif
