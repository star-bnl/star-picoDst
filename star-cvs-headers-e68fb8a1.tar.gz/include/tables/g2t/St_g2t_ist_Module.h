#ifndef STAF_St_g2t_ist_Module
#define STAF_St_g2t_ist_Module

#include "St_Module.h"

#ifdef __CINT__
 class table_head_st;
 class g2t_track_st;
 class g2t_ist_hit_st;
 class St_g2t_track;
 class St_g2t_ist_hit;
#else
#include "tables/St_g2t_track_Table.h"
#include "tables/St_g2t_ist_hit_Table.h"
#endif


class St_g2t_ist : public St_Module
{
public:
  St_g2t_ist() : St_Module(){}

// Passing the "simple" structures

 typedef enum { 
    kG2t_track0,
    kG2t_ist_hit1
 } Eg2t_ist;

// Passing the C++ objects

  St_g2t_ist(
     St_g2t_track *o0,
     St_g2t_ist_hit *o1
  );
  Int_t operator()(
     St_g2t_track *o0,
     St_g2t_ist_hit *o1
  );

// Calling the wrapped STAF module

 Int_t ExecuteModule();

  const Char_t *GetName(){return "g2t_ist";}
 ClassDef(St_g2t_ist,0) // class-wrapper to cal g2t_ist module 
};


R__EXTERN St_g2t_ist &g2t_ist; 

#endif
