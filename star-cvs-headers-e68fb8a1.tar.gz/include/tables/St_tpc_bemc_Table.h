
#ifndef STAF_St_tpc_bemc_Table
#define STAF_St_tpc_bemc_Table

#include "TTable.h"

#include "tpc_bemc.h"

/*!
 * \class  St_tpc_bemc
 * \brief  C++ wrapper for <tpc_bemc> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:41 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpc_bemc : public TTable
{
 public:
   ClassDefTable(St_tpc_bemc,tpc_bemc_st)
   ClassDef(St_tpc_bemc,2) //C++ wrapper for <tpc_bemc> StAF table
};
#endif
