
#ifndef STAF_St_tofTzero_Table
#define STAF_St_tofTzero_Table

#include "TTable.h"

#include "tofTzero.h"

/*!
 * \class  St_tofTzero
 * \brief  C++ wrapper for <tofTzero> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:28 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofTzero : public TTable
{
 public:
   ClassDefTable(St_tofTzero,tofTzero_st)
   ClassDef(St_tofTzero,2) //C++ wrapper for <tofTzero> StAF table
};
#endif
