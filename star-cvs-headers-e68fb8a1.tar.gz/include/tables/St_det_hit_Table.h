
#ifndef STAF_St_det_hit_Table
#define STAF_St_det_hit_Table

#include "TTable.h"

#include "det_hit.h"

/*!
 * \class  St_det_hit
 * \brief  C++ wrapper for <det_hit> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:08 2018
 *
 * This was generated for version 'DEV'
 */
class St_det_hit : public TTable
{
 public:
   ClassDefTable(St_det_hit,det_hit_st)
   ClassDef(St_det_hit,2) //C++ wrapper for <det_hit> StAF table
};
#endif
