
#ifndef STAF_St_bemcTowers_Table
#define STAF_St_bemcTowers_Table

#include "TTable.h"

#include "bemcTowers.h"

/*!
 * \class  St_bemcTowers
 * \brief  C++ wrapper for <bemcTowers> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:00 2018
 *
 * This was generated for version 'DEV'
 */
class St_bemcTowers : public TTable
{
 public:
   ClassDefTable(St_bemcTowers,bemcTowers_st)
   ClassDef(St_bemcTowers,2) //C++ wrapper for <bemcTowers> StAF table
};
#endif
