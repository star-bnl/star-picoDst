
#ifndef STAF_St_vpdDelay_Table
#define STAF_St_vpdDelay_Table

#include "TTable.h"

#include "vpdDelay.h"

/*!
 * \class  St_vpdDelay
 * \brief  C++ wrapper for <vpdDelay> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:36 2018
 *
 * This was generated for version 'DEV'
 */
class St_vpdDelay : public TTable
{
 public:
   ClassDefTable(St_vpdDelay,vpdDelay_st)
   ClassDef(St_vpdDelay,2) //C++ wrapper for <vpdDelay> StAF table
};
#endif
