
#ifndef STAF_St_beamOrbitInfo_Table
#define STAF_St_beamOrbitInfo_Table

#include "TTable.h"

#include "beamOrbitInfo.h"

/*!
 * \class  St_beamOrbitInfo
 * \brief  C++ wrapper for <beamOrbitInfo> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:00 2018
 *
 * This was generated for version 'DEV'
 */
class St_beamOrbitInfo : public TTable
{
 public:
   ClassDefTable(St_beamOrbitInfo,beamOrbitInfo_st)
   ClassDef(St_beamOrbitInfo,2) //C++ wrapper for <beamOrbitInfo> StAF table
};
#endif
