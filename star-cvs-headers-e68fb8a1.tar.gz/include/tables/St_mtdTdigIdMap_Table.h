
#ifndef STAF_St_mtdTdigIdMap_Table
#define STAF_St_mtdTdigIdMap_Table

#include "TTable.h"

#include "mtdTdigIdMap.h"

/*!
 * \class  St_mtdTdigIdMap
 * \brief  C++ wrapper for <mtdTdigIdMap> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:17 2018
 *
 * This was generated for version 'DEV'
 */
class St_mtdTdigIdMap : public TTable
{
 public:
   ClassDefTable(St_mtdTdigIdMap,mtdTdigIdMap_st)
   ClassDef(St_mtdTdigIdMap,2) //C++ wrapper for <mtdTdigIdMap> StAF table
};
#endif
