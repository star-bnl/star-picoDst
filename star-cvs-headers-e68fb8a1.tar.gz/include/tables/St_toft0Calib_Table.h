
#ifndef STAF_St_toft0Calib_Table
#define STAF_St_toft0Calib_Table

#include "TTable.h"

#include "toft0Calib.h"

/*!
 * \class  St_toft0Calib
 * \brief  C++ wrapper for <toft0Calib> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:29 2018
 *
 * This was generated for version 'DEV'
 */
class St_toft0Calib : public TTable
{
 public:
   ClassDefTable(St_toft0Calib,toft0Calib_st)
   ClassDef(St_toft0Calib,2) //C++ wrapper for <toft0Calib> StAF table
};
#endif
