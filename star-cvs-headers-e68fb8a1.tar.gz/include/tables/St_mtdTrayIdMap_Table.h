
#ifndef STAF_St_mtdTrayIdMap_Table
#define STAF_St_mtdTrayIdMap_Table

#include "TTable.h"

#include "mtdTrayIdMap.h"

/*!
 * \class  St_mtdTrayIdMap
 * \brief  C++ wrapper for <mtdTrayIdMap> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:17 2018
 *
 * This was generated for version 'DEV'
 */
class St_mtdTrayIdMap : public TTable
{
 public:
   ClassDefTable(St_mtdTrayIdMap,mtdTrayIdMap_st)
   ClassDef(St_mtdTrayIdMap,2) //C++ wrapper for <mtdTrayIdMap> StAF table
};
#endif
