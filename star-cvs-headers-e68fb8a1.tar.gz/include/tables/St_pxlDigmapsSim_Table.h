
#ifndef STAF_St_pxlDigmapsSim_Table
#define STAF_St_pxlDigmapsSim_Table

#include "TTable.h"

#include "pxlDigmapsSim.h"

/*!
 * \class  St_pxlDigmapsSim
 * \brief  C++ wrapper for <pxlDigmapsSim> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:20 2018
 *
 * This was generated for version 'DEV'
 */
class St_pxlDigmapsSim : public TTable
{
 public:
   ClassDefTable(St_pxlDigmapsSim,pxlDigmapsSim_st)
   ClassDef(St_pxlDigmapsSim,2) //C++ wrapper for <pxlDigmapsSim> StAF table
};
#endif
