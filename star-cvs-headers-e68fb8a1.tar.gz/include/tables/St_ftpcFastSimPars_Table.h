
#ifndef STAF_St_ftpcFastSimPars_Table
#define STAF_St_ftpcFastSimPars_Table

#include "TTable.h"

#include "ftpcFastSimPars.h"

/*!
 * \class  St_ftpcFastSimPars
 * \brief  C++ wrapper for <ftpcFastSimPars> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:12 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcFastSimPars : public TTable
{
 public:
   ClassDefTable(St_ftpcFastSimPars,ftpcFastSimPars_st)
   ClassDef(St_ftpcFastSimPars,2) //C++ wrapper for <ftpcFastSimPars> StAF table
};
#endif
