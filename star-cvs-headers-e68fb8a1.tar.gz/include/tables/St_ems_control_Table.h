
#ifndef STAF_St_ems_control_Table
#define STAF_St_ems_control_Table

#include "TTable.h"

#include "ems_control.h"

/*!
 * \class  St_ems_control
 * \brief  C++ wrapper for <ems_control> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:39 2018
 *
 * This was generated for version 'DEV'
 */
class St_ems_control : public TTable
{
 public:
   ClassDefTable(St_ems_control,ems_control_st)
   ClassDef(St_ems_control,2) //C++ wrapper for <ems_control> StAF table
};
#endif
