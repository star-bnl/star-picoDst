
#ifndef STAF_St_tofConfig_Table
#define STAF_St_tofConfig_Table

#include "TTable.h"

#include "tofConfig.h"

/*!
 * \class  St_tofConfig
 * \brief  C++ wrapper for <tofConfig> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:26 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofConfig : public TTable
{
 public:
   ClassDefTable(St_tofConfig,tofConfig_st)
   ClassDef(St_tofConfig,2) //C++ wrapper for <tofConfig> StAF table
};
#endif
