
#ifndef STAF_St_ftpcVoltageStatus_Table
#define STAF_St_ftpcVoltageStatus_Table

#include "TTable.h"

#include "ftpcVoltageStatus.h"

/*!
 * \class  St_ftpcVoltageStatus
 * \brief  C++ wrapper for <ftpcVoltageStatus> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:13 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcVoltageStatus : public TTable
{
 public:
   ClassDefTable(St_ftpcVoltageStatus,ftpcVoltageStatus_st)
   ClassDef(St_ftpcVoltageStatus,2) //C++ wrapper for <ftpcVoltageStatus> StAF table
};
#endif
