
#ifndef STAF_St_mtdGeant2BacklegIDMap_Table
#define STAF_St_mtdGeant2BacklegIDMap_Table

#include "TTable.h"

#include "mtdGeant2BacklegIDMap.h"

/*!
 * \class  St_mtdGeant2BacklegIDMap
 * \brief  C++ wrapper for <mtdGeant2BacklegIDMap> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:16 2018
 *
 * This was generated for version 'DEV'
 */
class St_mtdGeant2BacklegIDMap : public TTable
{
 public:
   ClassDefTable(St_mtdGeant2BacklegIDMap,mtdGeant2BacklegIDMap_st)
   ClassDef(St_mtdGeant2BacklegIDMap,2) //C++ wrapper for <mtdGeant2BacklegIDMap> StAF table
};
#endif
