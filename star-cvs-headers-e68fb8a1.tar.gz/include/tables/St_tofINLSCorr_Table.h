
#ifndef STAF_St_tofINLSCorr_Table
#define STAF_St_tofINLSCorr_Table

#include "TTable.h"

#include "tofINLSCorr.h"

/*!
 * \class  St_tofINLSCorr
 * \brief  C++ wrapper for <tofINLSCorr> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:26 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofINLSCorr : public TTable
{
 public:
   ClassDefTable(St_tofINLSCorr,tofINLSCorr_st)
   ClassDef(St_tofINLSCorr,2) //C++ wrapper for <tofINLSCorr> StAF table
};
#endif
