
#ifndef STAF_St_pxlRowColumnStatus_Table
#define STAF_St_pxlRowColumnStatus_Table

#include "TTable.h"

#include "pxlRowColumnStatus.h"

/*!
 * \class  St_pxlRowColumnStatus
 * \brief  C++ wrapper for <pxlRowColumnStatus> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:20 2018
 *
 * This was generated for version 'DEV'
 */
class St_pxlRowColumnStatus : public TTable
{
 public:
   ClassDefTable(St_pxlRowColumnStatus,pxlRowColumnStatus_st)
   ClassDef(St_pxlRowColumnStatus,2) //C++ wrapper for <pxlRowColumnStatus> StAF table
};
#endif
