
#ifndef STAF_St_emc_pedestal_Table
#define STAF_St_emc_pedestal_Table

#include "TTable.h"

#include "emc_pedestal.h"

/*!
 * \class  St_emc_pedestal
 * \brief  C++ wrapper for <emc_pedestal> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:39 2018
 *
 * This was generated for version 'DEV'
 */
class St_emc_pedestal : public TTable
{
 public:
   ClassDefTable(St_emc_pedestal,emc_pedestal_st)
   ClassDef(St_emc_pedestal,2) //C++ wrapper for <emc_pedestal> StAF table
};
#endif
