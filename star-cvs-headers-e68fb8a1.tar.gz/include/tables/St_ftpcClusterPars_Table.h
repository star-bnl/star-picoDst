
#ifndef STAF_St_ftpcClusterPars_Table
#define STAF_St_ftpcClusterPars_Table

#include "TTable.h"

#include "ftpcClusterPars.h"

/*!
 * \class  St_ftpcClusterPars
 * \brief  C++ wrapper for <ftpcClusterPars> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:11 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcClusterPars : public TTable
{
 public:
   ClassDefTable(St_ftpcClusterPars,ftpcClusterPars_st)
   ClassDef(St_ftpcClusterPars,2) //C++ wrapper for <ftpcClusterPars> StAF table
};
#endif
