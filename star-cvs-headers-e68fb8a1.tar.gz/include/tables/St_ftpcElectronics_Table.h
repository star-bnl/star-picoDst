
#ifndef STAF_St_ftpcElectronics_Table
#define STAF_St_ftpcElectronics_Table

#include "TTable.h"

#include "ftpcElectronics.h"

/*!
 * \class  St_ftpcElectronics
 * \brief  C++ wrapper for <ftpcElectronics> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:12 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcElectronics : public TTable
{
 public:
   ClassDefTable(St_ftpcElectronics,ftpcElectronics_st)
   ClassDef(St_ftpcElectronics,2) //C++ wrapper for <ftpcElectronics> StAF table
};
#endif
