
#ifndef STAF_St_StvHitErrs_Table
#define STAF_St_StvHitErrs_Table

#include "TTable.h"

#include "StvHitErrs.h"

/*!
 * \class  St_StvHitErrs
 * \brief  C++ wrapper for <StvHitErrs> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:29 2018
 *
 * This was generated for version 'DEV'
 */
class St_StvHitErrs : public TTable
{
 public:
   ClassDefTable(St_StvHitErrs,StvHitErrs_st)
   ClassDef(St_StvHitErrs,2) //C++ wrapper for <StvHitErrs> StAF table
};
#endif
