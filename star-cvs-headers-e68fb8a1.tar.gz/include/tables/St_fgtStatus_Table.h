
#ifndef STAF_St_fgtStatus_Table
#define STAF_St_fgtStatus_Table

#include "TTable.h"

#include "fgtStatus.h"

/*!
 * \class  St_fgtStatus
 * \brief  C++ wrapper for <fgtStatus> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:07 2018
 *
 * This was generated for version 'DEV'
 */
class St_fgtStatus : public TTable
{
 public:
   ClassDefTable(St_fgtStatus,fgtStatus_st)
   ClassDef(St_fgtStatus,2) //C++ wrapper for <fgtStatus> StAF table
};
#endif
