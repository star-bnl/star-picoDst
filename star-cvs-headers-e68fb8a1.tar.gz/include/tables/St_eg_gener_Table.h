
#ifndef STAF_St_eg_gener_Table
#define STAF_St_eg_gener_Table

#include "TTable.h"

#include "eg_gener.h"

/*!
 * \class  St_eg_gener
 * \brief  C++ wrapper for <eg_gener> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:12 2018
 *
 * This was generated for version 'DEV'
 */
class St_eg_gener : public TTable
{
 public:
   ClassDefTable(St_eg_gener,eg_gener_st)
   ClassDef(St_eg_gener,2) //C++ wrapper for <eg_gener> StAF table
};
#endif
