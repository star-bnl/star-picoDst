
#ifndef STAF_St_emcESmdAdc_Table
#define STAF_St_emcESmdAdc_Table

#include "TTable.h"

#include "emcESmdAdc.h"

/*!
 * \class  St_emcESmdAdc
 * \brief  C++ wrapper for <emcESmdAdc> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:04 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcESmdAdc : public TTable
{
 public:
   ClassDefTable(St_emcESmdAdc,emcESmdAdc_st)
   ClassDef(St_emcESmdAdc,2) //C++ wrapper for <emcESmdAdc> StAF table
};
#endif
