
#ifndef STAF_St_tofTACorr_Table
#define STAF_St_tofTACorr_Table

#include "TTable.h"

#include "tofTACorr.h"

/*!
 * \class  St_tofTACorr
 * \brief  C++ wrapper for <tofTACorr> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:28 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofTACorr : public TTable
{
 public:
   ClassDefTable(St_tofTACorr,tofTACorr_st)
   ClassDef(St_tofTACorr,2) //C++ wrapper for <tofTACorr> StAF table
};
#endif
