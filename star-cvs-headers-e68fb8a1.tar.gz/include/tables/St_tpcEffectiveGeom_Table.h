
#ifndef STAF_St_tpcEffectiveGeom_Table
#define STAF_St_tpcEffectiveGeom_Table

#include "TTable.h"

#include "tpcEffectiveGeom.h"

/*!
 * \class  St_tpcEffectiveGeom
 * \brief  C++ wrapper for <tpcEffectiveGeom> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:31 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcEffectiveGeom : public TTable
{
 public:
   ClassDefTable(St_tpcEffectiveGeom,tpcEffectiveGeom_st)
   ClassDef(St_tpcEffectiveGeom,2) //C++ wrapper for <tpcEffectiveGeom> StAF table
};
#endif
