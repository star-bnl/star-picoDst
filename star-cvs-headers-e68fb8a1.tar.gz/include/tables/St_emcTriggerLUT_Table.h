
#ifndef STAF_St_emcTriggerLUT_Table
#define STAF_St_emcTriggerLUT_Table

#include "TTable.h"

#include "emcTriggerLUT.h"

/*!
 * \class  St_emcTriggerLUT
 * \brief  C++ wrapper for <emcTriggerLUT> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:05 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcTriggerLUT : public TTable
{
 public:
   ClassDefTable(St_emcTriggerLUT,emcTriggerLUT_st)
   ClassDef(St_emcTriggerLUT,2) //C++ wrapper for <emcTriggerLUT> StAF table
};
#endif
