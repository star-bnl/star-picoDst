
#ifndef STAF_St_tofSimPars_Table
#define STAF_St_tofSimPars_Table

#include "TTable.h"

#include "tofSimPars.h"

/*!
 * \class  St_tofSimPars
 * \brief  C++ wrapper for <tofSimPars> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:27 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofSimPars : public TTable
{
 public:
   ClassDefTable(St_tofSimPars,tofSimPars_st)
   ClassDef(St_tofSimPars,2) //C++ wrapper for <tofSimPars> StAF table
};
#endif
