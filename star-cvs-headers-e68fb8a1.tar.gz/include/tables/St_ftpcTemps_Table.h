
#ifndef STAF_St_ftpcTemps_Table
#define STAF_St_ftpcTemps_Table

#include "TTable.h"

#include "ftpcTemps.h"

/*!
 * \class  St_ftpcTemps
 * \brief  C++ wrapper for <ftpcTemps> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:13 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcTemps : public TTable
{
 public:
   ClassDefTable(St_ftpcTemps,ftpcTemps_st)
   ClassDef(St_ftpcTemps,2) //C++ wrapper for <ftpcTemps> StAF table
};
#endif
