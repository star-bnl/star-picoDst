
#ifndef STAF_St_emcDimensions_Table
#define STAF_St_emcDimensions_Table

#include "TTable.h"

#include "emcDimensions.h"

/*!
 * \class  St_emcDimensions
 * \brief  C++ wrapper for <emcDimensions> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:04 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcDimensions : public TTable
{
 public:
   ClassDefTable(St_emcDimensions,emcDimensions_st)
   ClassDef(St_emcDimensions,2) //C++ wrapper for <emcDimensions> StAF table
};
#endif
