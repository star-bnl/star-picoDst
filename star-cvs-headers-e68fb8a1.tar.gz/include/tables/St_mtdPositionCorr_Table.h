
#ifndef STAF_St_mtdPositionCorr_Table
#define STAF_St_mtdPositionCorr_Table

#include "TTable.h"

#include "mtdPositionCorr.h"

/*!
 * \class  St_mtdPositionCorr
 * \brief  C++ wrapper for <mtdPositionCorr> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:16 2018
 *
 * This was generated for version 'DEV'
 */
class St_mtdPositionCorr : public TTable
{
 public:
   ClassDefTable(St_mtdPositionCorr,mtdPositionCorr_st)
   ClassDef(St_mtdPositionCorr,2) //C++ wrapper for <mtdPositionCorr> StAF table
};
#endif
