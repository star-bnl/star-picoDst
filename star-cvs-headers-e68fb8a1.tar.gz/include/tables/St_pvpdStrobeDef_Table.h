
#ifndef STAF_St_pvpdStrobeDef_Table
#define STAF_St_pvpdStrobeDef_Table

#include "TTable.h"

#include "pvpdStrobeDef.h"

/*!
 * \class  St_pvpdStrobeDef
 * \brief  C++ wrapper for <pvpdStrobeDef> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:20 2018
 *
 * This was generated for version 'DEV'
 */
class St_pvpdStrobeDef : public TTable
{
 public:
   ClassDefTable(St_pvpdStrobeDef,pvpdStrobeDef_st)
   ClassDef(St_pvpdStrobeDef,2) //C++ wrapper for <pvpdStrobeDef> StAF table
};
#endif
