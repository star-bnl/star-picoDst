
#ifndef STAF_St_tofTrayConfig_Table
#define STAF_St_tofTrayConfig_Table

#include "TTable.h"

#include "tofTrayConfig.h"

/*!
 * \class  St_tofTrayConfig
 * \brief  C++ wrapper for <tofTrayConfig> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:28 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofTrayConfig : public TTable
{
 public:
   ClassDefTable(St_tofTrayConfig,tofTrayConfig_st)
   ClassDef(St_tofTrayConfig,2) //C++ wrapper for <tofTrayConfig> StAF table
};
#endif
