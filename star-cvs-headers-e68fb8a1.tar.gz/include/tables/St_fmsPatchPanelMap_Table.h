
#ifndef STAF_St_fmsPatchPanelMap_Table
#define STAF_St_fmsPatchPanelMap_Table

#include "TTable.h"

#include "fmsPatchPanelMap.h"

/*!
 * \class  St_fmsPatchPanelMap
 * \brief  C++ wrapper for <fmsPatchPanelMap> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:09 2018
 *
 * This was generated for version 'DEV'
 */
class St_fmsPatchPanelMap : public TTable
{
 public:
   ClassDefTable(St_fmsPatchPanelMap,fmsPatchPanelMap_st)
   ClassDef(St_fmsPatchPanelMap,2) //C++ wrapper for <fmsPatchPanelMap> StAF table
};
#endif
