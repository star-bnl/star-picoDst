
#ifndef STAF_St_emcCalSettings_Table
#define STAF_St_emcCalSettings_Table

#include "TTable.h"

#include "emcCalSettings.h"

/*!
 * \class  St_emcCalSettings
 * \brief  C++ wrapper for <emcCalSettings> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:04 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcCalSettings : public TTable
{
 public:
   ClassDefTable(St_emcCalSettings,emcCalSettings_st)
   ClassDef(St_emcCalSettings,2) //C++ wrapper for <emcCalSettings> StAF table
};
#endif
