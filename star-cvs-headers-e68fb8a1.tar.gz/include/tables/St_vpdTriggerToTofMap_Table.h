
#ifndef STAF_St_vpdTriggerToTofMap_Table
#define STAF_St_vpdTriggerToTofMap_Table

#include "TTable.h"

#include "vpdTriggerToTofMap.h"

/*!
 * \class  St_vpdTriggerToTofMap
 * \brief  C++ wrapper for <vpdTriggerToTofMap> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:36 2018
 *
 * This was generated for version 'DEV'
 */
class St_vpdTriggerToTofMap : public TTable
{
 public:
   ClassDefTable(St_vpdTriggerToTofMap,vpdTriggerToTofMap_st)
   ClassDef(St_vpdTriggerToTofMap,2) //C++ wrapper for <vpdTriggerToTofMap> StAF table
};
#endif
