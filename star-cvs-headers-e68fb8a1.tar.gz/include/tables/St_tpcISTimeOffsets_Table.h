
#ifndef STAF_St_tpcISTimeOffsets_Table
#define STAF_St_tpcISTimeOffsets_Table

#include "TTable.h"

#include "tpcISTimeOffsets.h"

/*!
 * \class  St_tpcISTimeOffsets
 * \brief  C++ wrapper for <tpcISTimeOffsets> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:32 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcISTimeOffsets : public TTable
{
 public:
   ClassDefTable(St_tpcISTimeOffsets,tpcISTimeOffsets_st)
   ClassDef(St_tpcISTimeOffsets,2) //C++ wrapper for <tpcISTimeOffsets> StAF table
};
#endif
