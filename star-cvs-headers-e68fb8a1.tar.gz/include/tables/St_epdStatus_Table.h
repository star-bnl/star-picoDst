
#ifndef STAF_St_epdStatus_Table
#define STAF_St_epdStatus_Table

#include "TTable.h"

#include "epdStatus.h"

/*!
 * \class  St_epdStatus
 * \brief  C++ wrapper for <epdStatus> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:06 2018
 *
 * This was generated for version 'DEV'
 */
class St_epdStatus : public TTable
{
 public:
   ClassDefTable(St_epdStatus,epdStatus_st)
   ClassDef(St_epdStatus,2) //C++ wrapper for <epdStatus> StAF table
};
#endif
