
#ifndef STAF_St_fpostStatus_Table
#define STAF_St_fpostStatus_Table

#include "TTable.h"

#include "fpostStatus.h"

/*!
 * \class  St_fpostStatus
 * \brief  C++ wrapper for <fpostStatus> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:10 2018
 *
 * This was generated for version 'DEV'
 */
class St_fpostStatus : public TTable
{
 public:
   ClassDefTable(St_fpostStatus,fpostStatus_st)
   ClassDef(St_fpostStatus,2) //C++ wrapper for <fpostStatus> StAF table
};
#endif
