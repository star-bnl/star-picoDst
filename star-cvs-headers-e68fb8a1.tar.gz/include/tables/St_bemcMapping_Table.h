
#ifndef STAF_St_bemcMapping_Table
#define STAF_St_bemcMapping_Table

#include "TTable.h"

#include "bemcMapping.h"

/*!
 * \class  St_bemcMapping
 * \brief  C++ wrapper for <bemcMapping> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:00 2018
 *
 * This was generated for version 'DEV'
 */
class St_bemcMapping : public TTable
{
 public:
   ClassDefTable(St_bemcMapping,bemcMapping_st)
   ClassDef(St_bemcMapping,2) //C++ wrapper for <bemcMapping> StAF table
};
#endif
