
#ifndef STAF_St_bprsMap_Table
#define STAF_St_bprsMap_Table

#include "TTable.h"

#include "bprsMap.h"

/*!
 * \class  St_bprsMap
 * \brief  C++ wrapper for <bprsMap> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:01 2018
 *
 * This was generated for version 'DEV'
 */
class St_bprsMap : public TTable
{
 public:
   ClassDefTable(St_bprsMap,bprsMap_st)
   ClassDef(St_bprsMap,2) //C++ wrapper for <bprsMap> StAF table
};
#endif
