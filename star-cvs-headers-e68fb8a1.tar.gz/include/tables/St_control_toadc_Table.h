
#ifndef STAF_St_control_toadc_Table
#define STAF_St_control_toadc_Table

#include "TTable.h"

#include "control_toadc.h"

/*!
 * \class  St_control_toadc
 * \brief  C++ wrapper for <control_toadc> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:37 2018
 *
 * This was generated for version 'DEV'
 */
class St_control_toadc : public TTable
{
 public:
   ClassDefTable(St_control_toadc,control_toadc_st)
   ClassDef(St_control_toadc,2) //C++ wrapper for <control_toadc> StAF table
};
#endif
