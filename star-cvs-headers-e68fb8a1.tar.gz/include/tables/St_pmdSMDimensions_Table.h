
#ifndef STAF_St_pmdSMDimensions_Table
#define STAF_St_pmdSMDimensions_Table

#include "TTable.h"

#include "pmdSMDimensions.h"

/*!
 * \class  St_pmdSMDimensions
 * \brief  C++ wrapper for <pmdSMDimensions> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:18 2018
 *
 * This was generated for version 'DEV'
 */
class St_pmdSMDimensions : public TTable
{
 public:
   ClassDefTable(St_pmdSMDimensions,pmdSMDimensions_st)
   ClassDef(St_pmdSMDimensions,2) //C++ wrapper for <pmdSMDimensions> StAF table
};
#endif
