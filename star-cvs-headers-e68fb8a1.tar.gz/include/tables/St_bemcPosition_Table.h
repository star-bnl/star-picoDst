
#ifndef STAF_St_bemcPosition_Table
#define STAF_St_bemcPosition_Table

#include "TTable.h"

#include "bemcPosition.h"

/*!
 * \class  St_bemcPosition
 * \brief  C++ wrapper for <bemcPosition> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:00 2018
 *
 * This was generated for version 'DEV'
 */
class St_bemcPosition : public TTable
{
 public:
   ClassDefTable(St_bemcPosition,bemcPosition_st)
   ClassDef(St_bemcPosition,2) //C++ wrapper for <bemcPosition> StAF table
};
#endif
