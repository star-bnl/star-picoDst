
#ifndef STAF_St_fpsPed_Table
#define STAF_St_fpsPed_Table

#include "TTable.h"

#include "fpsPed.h"

/*!
 * \class  St_fpsPed
 * \brief  C++ wrapper for <fpsPed> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:10 2018
 *
 * This was generated for version 'DEV'
 */
class St_fpsPed : public TTable
{
 public:
   ClassDefTable(St_fpsPed,fpsPed_st)
   ClassDef(St_fpsPed,2) //C++ wrapper for <fpsPed> StAF table
};
#endif
