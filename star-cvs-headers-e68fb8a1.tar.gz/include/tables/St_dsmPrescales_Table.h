
#ifndef STAF_St_dsmPrescales_Table
#define STAF_St_dsmPrescales_Table

#include "TTable.h"

#include "dsmPrescales.h"

/*!
 * \class  St_dsmPrescales
 * \brief  C++ wrapper for <dsmPrescales> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:02 2018
 *
 * This was generated for version 'DEV'
 */
class St_dsmPrescales : public TTable
{
 public:
   ClassDefTable(St_dsmPrescales,dsmPrescales_st)
   ClassDef(St_dsmPrescales,2) //C++ wrapper for <dsmPrescales> StAF table
};
#endif
