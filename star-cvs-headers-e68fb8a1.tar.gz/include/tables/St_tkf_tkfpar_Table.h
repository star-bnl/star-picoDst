
#ifndef STAF_St_tkf_tkfpar_Table
#define STAF_St_tkf_tkfpar_Table

#include "TTable.h"

#include "tkf_tkfpar.h"

/*!
 * \class  St_tkf_tkfpar
 * \brief  C++ wrapper for <tkf_tkfpar> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:18:33 2018
 *
 * This was generated for version 'DEV'
 */
class St_tkf_tkfpar : public TTable
{
 public:
   ClassDefTable(St_tkf_tkfpar,tkf_tkfpar_st)
   ClassDef(St_tkf_tkfpar,2) //C++ wrapper for <tkf_tkfpar> StAF table
};
#endif
