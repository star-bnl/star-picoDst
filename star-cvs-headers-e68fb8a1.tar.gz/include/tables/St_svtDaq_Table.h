
#ifndef STAF_St_svtDaq_Table
#define STAF_St_svtDaq_Table

#include "TTable.h"

#include "svtDaq.h"

/*!
 * \class  St_svtDaq
 * \brief  C++ wrapper for <svtDaq> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:24 2018
 *
 * This was generated for version 'DEV'
 */
class St_svtDaq : public TTable
{
 public:
   ClassDefTable(St_svtDaq,svtDaq_st)
   ClassDef(St_svtDaq,2) //C++ wrapper for <svtDaq> StAF table
};
#endif
