
#ifndef STAF_St_pmdSMCalib_Table
#define STAF_St_pmdSMCalib_Table

#include "TTable.h"

#include "pmdSMCalib.h"

/*!
 * \class  St_pmdSMCalib
 * \brief  C++ wrapper for <pmdSMCalib> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:18 2018
 *
 * This was generated for version 'DEV'
 */
class St_pmdSMCalib : public TTable
{
 public:
   ClassDefTable(St_pmdSMCalib,pmdSMCalib_st)
   ClassDef(St_pmdSMCalib,2) //C++ wrapper for <pmdSMCalib> StAF table
};
#endif
