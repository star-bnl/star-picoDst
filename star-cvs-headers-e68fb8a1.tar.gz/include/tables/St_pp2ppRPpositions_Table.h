
#ifndef STAF_St_pp2ppRPpositions_Table
#define STAF_St_pp2ppRPpositions_Table

#include "TTable.h"

#include "pp2ppRPpositions.h"

/*!
 * \class  St_pp2ppRPpositions
 * \brief  C++ wrapper for <pp2ppRPpositions> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:19 2018
 *
 * This was generated for version 'DEV'
 */
class St_pp2ppRPpositions : public TTable
{
 public:
   ClassDefTable(St_pp2ppRPpositions,pp2ppRPpositions_st)
   ClassDef(St_pp2ppRPpositions,2) //C++ wrapper for <pp2ppRPpositions> StAF table
};
#endif
