
#ifndef STAF_St_tpcOmegaTau_Table
#define STAF_St_tpcOmegaTau_Table

#include "TTable.h"

#include "tpcOmegaTau.h"

/*!
 * \class  St_tpcOmegaTau
 * \brief  C++ wrapper for <tpcOmegaTau> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:32 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcOmegaTau : public TTable
{
 public:
   ClassDefTable(St_tpcOmegaTau,tpcOmegaTau_st)
   ClassDef(St_tpcOmegaTau,2) //C++ wrapper for <tpcOmegaTau> StAF table
};
#endif
