
#ifndef STAF_St_ems_hits_bemc_Table
#define STAF_St_ems_hits_bemc_Table

#include "TTable.h"

#include "ems_hits_bemc.h"

/*!
 * \class  St_ems_hits_bemc
 * \brief  C++ wrapper for <ems_hits_bemc> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:39 2018
 *
 * This was generated for version 'DEV'
 */
class St_ems_hits_bemc : public TTable
{
 public:
   ClassDefTable(St_ems_hits_bemc,ems_hits_bemc_st)
   ClassDef(St_ems_hits_bemc,2) //C++ wrapper for <ems_hits_bemc> StAF table
};
#endif
