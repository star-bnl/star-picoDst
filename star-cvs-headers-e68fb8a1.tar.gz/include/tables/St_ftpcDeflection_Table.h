
#ifndef STAF_St_ftpcDeflection_Table
#define STAF_St_ftpcDeflection_Table

#include "TTable.h"

#include "ftpcDeflection.h"

/*!
 * \class  St_ftpcDeflection
 * \brief  C++ wrapper for <ftpcDeflection> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:11 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcDeflection : public TTable
{
 public:
   ClassDefTable(St_ftpcDeflection,ftpcDeflection_st)
   ClassDef(St_ftpcDeflection,2) //C++ wrapper for <ftpcDeflection> StAF table
};
#endif
