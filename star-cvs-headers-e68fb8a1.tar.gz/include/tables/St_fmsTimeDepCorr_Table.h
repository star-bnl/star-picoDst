
#ifndef STAF_St_fmsTimeDepCorr_Table
#define STAF_St_fmsTimeDepCorr_Table

#include "TTable.h"

#include "fmsTimeDepCorr.h"

/*!
 * \class  St_fmsTimeDepCorr
 * \brief  C++ wrapper for <fmsTimeDepCorr> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:09 2018
 *
 * This was generated for version 'DEV'
 */
class St_fmsTimeDepCorr : public TTable
{
 public:
   ClassDefTable(St_fmsTimeDepCorr,fmsTimeDepCorr_st)
   ClassDef(St_fmsTimeDepCorr,2) //C++ wrapper for <fmsTimeDepCorr> StAF table
};
#endif
