
#ifndef STAF_St_eemcDbPMTname_Table
#define STAF_St_eemcDbPMTname_Table

#include "TTable.h"

#include "eemcDbPMTname.h"

/*!
 * \class  St_eemcDbPMTname
 * \brief  C++ wrapper for <eemcDbPMTname> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:03 2018
 *
 * This was generated for version 'DEV'
 */
class St_eemcDbPMTname : public TTable
{
 public:
   ClassDefTable(St_eemcDbPMTname,eemcDbPMTname_st)
   ClassDef(St_eemcDbPMTname,2) //C++ wrapper for <eemcDbPMTname> StAF table
};
#endif
