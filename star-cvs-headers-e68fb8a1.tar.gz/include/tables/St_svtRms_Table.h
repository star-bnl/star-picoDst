
#ifndef STAF_St_svtRms_Table
#define STAF_St_svtRms_Table

#include "TTable.h"

#include "svtRms.h"

/*!
 * \class  St_svtRms
 * \brief  C++ wrapper for <svtRms> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:25 2018
 *
 * This was generated for version 'DEV'
 */
class St_svtRms : public TTable
{
 public:
   ClassDefTable(St_svtRms,svtRms_st)
   ClassDef(St_svtRms,2) //C++ wrapper for <svtRms> StAF table
};
#endif
