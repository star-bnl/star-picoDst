
#ifndef STAF_St_fgtGain_Table
#define STAF_St_fgtGain_Table

#include "TTable.h"

#include "fgtGain.h"

/*!
 * \class  St_fgtGain
 * \brief  C++ wrapper for <fgtGain> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:06 2018
 *
 * This was generated for version 'DEV'
 */
class St_fgtGain : public TTable
{
 public:
   ClassDefTable(St_fgtGain,fgtGain_st)
   ClassDef(St_fgtGain,2) //C++ wrapper for <fgtGain> StAF table
};
#endif
