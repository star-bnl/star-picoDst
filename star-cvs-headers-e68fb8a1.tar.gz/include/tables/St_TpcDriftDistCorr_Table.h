
#ifndef STAF_St_TpcDriftDistCorr_Table
#define STAF_St_TpcDriftDistCorr_Table

#include "TTable.h"

#include "TpcDriftDistCorr.h"

/*!
 * \class  St_TpcDriftDistCorr
 * \brief  C++ wrapper for <TpcDriftDistCorr> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:30 2018
 *
 * This was generated for version 'DEV'
 */
class St_TpcDriftDistCorr : public TTable
{
 public:
   ClassDefTable(St_TpcDriftDistCorr,TpcDriftDistCorr_st)
   ClassDef(St_TpcDriftDistCorr,2) //C++ wrapper for <TpcDriftDistCorr> StAF table
};
#endif
