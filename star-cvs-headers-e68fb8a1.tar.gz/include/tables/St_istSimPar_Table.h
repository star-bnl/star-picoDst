
#ifndef STAF_St_istSimPar_Table
#define STAF_St_istSimPar_Table

#include "TTable.h"

#include "istSimPar.h"

/*!
 * \class  St_istSimPar
 * \brief  C++ wrapper for <istSimPar> StAF table
 * \author Automatic Generation
 * \date   Fri Apr 13 15:10:23 2018
 *
 * This was generated for version 'DEV'
 */
class St_istSimPar : public TTable
{
 public:
   ClassDefTable(St_istSimPar,istSimPar_st)
   ClassDef(St_istSimPar,2) //C++ wrapper for <istSimPar> StAF table
};
#endif
