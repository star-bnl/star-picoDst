
#ifndef STAF_St_fmsPositionModel_Table
#define STAF_St_fmsPositionModel_Table

#include "TTable.h"

#include "fmsPositionModel.h"

/*!
 * \class  St_fmsPositionModel
 * \brief  C++ wrapper for <fmsPositionModel> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:09 2018
 *
 * This was generated for version 'DEV'
 */
class St_fmsPositionModel : public TTable
{
 public:
   ClassDefTable(St_fmsPositionModel,fmsPositionModel_st)
   ClassDef(St_fmsPositionModel,2) //C++ wrapper for <fmsPositionModel> StAF table
};
#endif
