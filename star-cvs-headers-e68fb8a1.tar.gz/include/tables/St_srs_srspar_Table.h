
#ifndef STAF_St_srs_srspar_Table
#define STAF_St_srs_srspar_Table

#include "TTable.h"

#include "srs_srspar.h"

/*!
 * \class  St_srs_srspar
 * \brief  C++ wrapper for <srs_srspar> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:27 2018
 *
 * This was generated for version 'DEV'
 */
class St_srs_srspar : public TTable
{
 public:
   ClassDefTable(St_srs_srspar,srs_srspar_st)
   ClassDef(St_srs_srspar,2) //C++ wrapper for <srs_srspar> StAF table
};
#endif
