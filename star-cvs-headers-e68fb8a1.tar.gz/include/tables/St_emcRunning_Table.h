
#ifndef STAF_St_emcRunning_Table
#define STAF_St_emcRunning_Table

#include "TTable.h"

#include "emcRunning.h"

/*!
 * \class  St_emcRunning
 * \brief  C++ wrapper for <emcRunning> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:05 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcRunning : public TTable
{
 public:
   ClassDefTable(St_emcRunning,emcRunning_st)
   ClassDef(St_emcRunning,2) //C++ wrapper for <emcRunning> StAF table
};
#endif
