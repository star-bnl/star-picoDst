
#ifndef STAF_St_sstDimensions_Table
#define STAF_St_sstDimensions_Table

#include "TTable.h"

#include "sstDimensions.h"

/*!
 * \class  St_sstDimensions
 * \brief  C++ wrapper for <sstDimensions> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:23 2018
 *
 * This was generated for version 'DEV'
 */
class St_sstDimensions : public TTable
{
 public:
   ClassDefTable(St_sstDimensions,sstDimensions_st)
   ClassDef(St_sstDimensions,2) //C++ wrapper for <sstDimensions> StAF table
};
#endif
