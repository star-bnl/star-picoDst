
#ifndef STAF_St_TrackingParameters_Table
#define STAF_St_TrackingParameters_Table

#include "TTable.h"

#include "TrackingParameters.h"

/*!
 * \class  St_TrackingParameters
 * \brief  C++ wrapper for <TrackingParameters> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:59 2018
 *
 * This was generated for version 'DEV'
 */
class St_TrackingParameters : public TTable
{
 public:
   ClassDefTable(St_TrackingParameters,TrackingParameters_st)
   ClassDef(St_TrackingParameters,2) //C++ wrapper for <TrackingParameters> StAF table
};
#endif
