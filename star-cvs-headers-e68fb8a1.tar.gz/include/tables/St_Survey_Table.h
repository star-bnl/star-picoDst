
#ifndef STAF_St_Survey_Table
#define STAF_St_Survey_Table

#include "TTable.h"

#include "Survey.h"

/*!
 * \class  St_Survey
 * \brief  C++ wrapper for <Survey> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:29 2018
 *
 * This was generated for version 'DEV'
 */
class St_Survey : public TTable
{
 public:
   ClassDefTable(St_Survey,Survey_st)
   ClassDef(St_Survey,2) //C++ wrapper for <Survey> StAF table
};
#endif
