
#ifndef STAF_St_bsmdeMap_Table
#define STAF_St_bsmdeMap_Table

#include "TTable.h"

#include "bsmdeMap.h"

/*!
 * \class  St_bsmdeMap
 * \brief  C++ wrapper for <bsmdeMap> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:01 2018
 *
 * This was generated for version 'DEV'
 */
class St_bsmdeMap : public TTable
{
 public:
   ClassDefTable(St_bsmdeMap,bsmdeMap_st)
   ClassDef(St_bsmdeMap,2) //C++ wrapper for <bsmdeMap> StAF table
};
#endif
