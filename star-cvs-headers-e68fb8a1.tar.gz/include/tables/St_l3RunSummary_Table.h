
#ifndef STAF_St_l3RunSummary_Table
#define STAF_St_l3RunSummary_Table

#include "TTable.h"

#include "l3RunSummary.h"

/*!
 * \class  St_l3RunSummary
 * \brief  C++ wrapper for <l3RunSummary> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:15 2018
 *
 * This was generated for version 'DEV'
 */
class St_l3RunSummary : public TTable
{
 public:
   ClassDefTable(St_l3RunSummary,l3RunSummary_st)
   ClassDef(St_l3RunSummary,2) //C++ wrapper for <l3RunSummary> StAF table
};
#endif
