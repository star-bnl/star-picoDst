
#ifndef STAF_St_tofDaqMap_Table
#define STAF_St_tofDaqMap_Table

#include "TTable.h"

#include "tofDaqMap.h"

/*!
 * \class  St_tofDaqMap
 * \brief  C++ wrapper for <tofDaqMap> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:26 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofDaqMap : public TTable
{
 public:
   ClassDefTable(St_tofDaqMap,tofDaqMap_st)
   ClassDef(St_tofDaqMap,2) //C++ wrapper for <tofDaqMap> StAF table
};
#endif
