
#ifndef STAF_St_bemcKill_Table
#define STAF_St_bemcKill_Table

#include "TTable.h"

#include "bemcKill.h"

/*!
 * \class  St_bemcKill
 * \brief  C++ wrapper for <bemcKill> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:00 2018
 *
 * This was generated for version 'DEV'
 */
class St_bemcKill : public TTable
{
 public:
   ClassDefTable(St_bemcKill,bemcKill_st)
   ClassDef(St_bemcKill,2) //C++ wrapper for <bemcKill> StAF table
};
#endif
