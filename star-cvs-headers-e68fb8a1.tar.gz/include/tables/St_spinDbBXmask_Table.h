
#ifndef STAF_St_spinDbBXmask_Table
#define STAF_St_spinDbBXmask_Table

#include "TTable.h"

#include "spinDbBXmask.h"

/*!
 * \class  St_spinDbBXmask
 * \brief  C++ wrapper for <spinDbBXmask> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:21 2018
 *
 * This was generated for version 'DEV'
 */
class St_spinDbBXmask : public TTable
{
 public:
   ClassDefTable(St_spinDbBXmask,spinDbBXmask_st)
   ClassDef(St_spinDbBXmask,2) //C++ wrapper for <spinDbBXmask> StAF table
};
#endif
