
#ifndef STAF_St_StrangeTag_Table
#define STAF_St_StrangeTag_Table

#include "TTable.h"

#include "StrangeTag.h"

/*!
 * \class  St_StrangeTag
 * \brief  C++ wrapper for <StrangeTag> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:18:32 2018
 *
 * This was generated for version 'DEV'
 */
class St_StrangeTag : public TTable
{
 public:
   ClassDefTable(St_StrangeTag,StrangeTag_st)
   ClassDef(St_StrangeTag,2) //C++ wrapper for <StrangeTag> StAF table
};
#endif
