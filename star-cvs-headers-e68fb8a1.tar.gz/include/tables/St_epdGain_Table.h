
#ifndef STAF_St_epdGain_Table
#define STAF_St_epdGain_Table

#include "TTable.h"

#include "epdGain.h"

/*!
 * \class  St_epdGain
 * \brief  C++ wrapper for <epdGain> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:05 2018
 *
 * This was generated for version 'DEV'
 */
class St_epdGain : public TTable
{
 public:
   ClassDefTable(St_epdGain,epdGain_st)
   ClassDef(St_epdGain,2) //C++ wrapper for <epdGain> StAF table
};
#endif
