
#ifndef STAF_St_bemcHwpedestal_Table
#define STAF_St_bemcHwpedestal_Table

#include "TTable.h"

#include "bemcHwpedestal.h"

/*!
 * \class  St_bemcHwpedestal
 * \brief  C++ wrapper for <bemcHwpedestal> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:00 2018
 *
 * This was generated for version 'DEV'
 */
class St_bemcHwpedestal : public TTable
{
 public:
   ClassDefTable(St_bemcHwpedestal,bemcHwpedestal_st)
   ClassDef(St_bemcHwpedestal,2) //C++ wrapper for <bemcHwpedestal> StAF table
};
#endif
