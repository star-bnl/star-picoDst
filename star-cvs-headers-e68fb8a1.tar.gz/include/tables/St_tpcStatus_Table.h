
#ifndef STAF_St_tpcStatus_Table
#define STAF_St_tpcStatus_Table

#include "TTable.h"

#include "tpcStatus.h"

/*!
 * \class  St_tpcStatus
 * \brief  C++ wrapper for <tpcStatus> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:34 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcStatus : public TTable
{
 public:
   ClassDefTable(St_tpcStatus,tpcStatus_st)
   ClassDef(St_tpcStatus,2) //C++ wrapper for <tpcStatus> StAF table
};
#endif
