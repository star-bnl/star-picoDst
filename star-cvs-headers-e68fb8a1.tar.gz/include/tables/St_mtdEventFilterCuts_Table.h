
#ifndef STAF_St_mtdEventFilterCuts_Table
#define STAF_St_mtdEventFilterCuts_Table

#include "TTable.h"

#include "mtdEventFilterCuts.h"

/*!
 * \class  St_mtdEventFilterCuts
 * \brief  C++ wrapper for <mtdEventFilterCuts> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:15 2018
 *
 * This was generated for version 'DEV'
 */
class St_mtdEventFilterCuts : public TTable
{
 public:
   ClassDefTable(St_mtdEventFilterCuts,mtdEventFilterCuts_st)
   ClassDef(St_mtdEventFilterCuts,2) //C++ wrapper for <mtdEventFilterCuts> StAF table
};
#endif
