
#ifndef STAF_St_svtBadAnodes_Table
#define STAF_St_svtBadAnodes_Table

#include "TTable.h"

#include "svtBadAnodes.h"

/*!
 * \class  St_svtBadAnodes
 * \brief  C++ wrapper for <svtBadAnodes> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:24 2018
 *
 * This was generated for version 'DEV'
 */
class St_svtBadAnodes : public TTable
{
 public:
   ClassDefTable(St_svtBadAnodes,svtBadAnodes_st)
   ClassDef(St_svtBadAnodes,2) //C++ wrapper for <svtBadAnodes> StAF table
};
#endif
