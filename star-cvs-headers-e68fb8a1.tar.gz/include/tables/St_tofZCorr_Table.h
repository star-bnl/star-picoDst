
#ifndef STAF_St_tofZCorr_Table
#define STAF_St_tofZCorr_Table

#include "TTable.h"

#include "tofZCorr.h"

/*!
 * \class  St_tofZCorr
 * \brief  C++ wrapper for <tofZCorr> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:29 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofZCorr : public TTable
{
 public:
   ClassDefTable(St_tofZCorr,tofZCorr_st)
   ClassDef(St_tofZCorr,2) //C++ wrapper for <tofZCorr> StAF table
};
#endif
