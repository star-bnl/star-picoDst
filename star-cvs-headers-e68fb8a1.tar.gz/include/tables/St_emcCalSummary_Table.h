
#ifndef STAF_St_emcCalSummary_Table
#define STAF_St_emcCalSummary_Table

#include "TTable.h"

#include "emcCalSummary.h"

/*!
 * \class  St_emcCalSummary
 * \brief  C++ wrapper for <emcCalSummary> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:04 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcCalSummary : public TTable
{
 public:
   ClassDefTable(St_emcCalSummary,emcCalSummary_st)
   ClassDef(St_emcCalSummary,2) //C++ wrapper for <emcCalSummary> StAF table
};
#endif
