
#ifndef STAF_St_MagFactor_Table
#define STAF_St_MagFactor_Table

#include "TTable.h"

#include "MagFactor.h"

/*!
 * \class  St_MagFactor
 * \brief  C++ wrapper for <MagFactor> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:28 2018
 *
 * This was generated for version 'DEV'
 */
class St_MagFactor : public TTable
{
 public:
   ClassDefTable(St_MagFactor,MagFactor_st)
   ClassDef(St_MagFactor,2) //C++ wrapper for <MagFactor> StAF table
};
#endif
