
#ifndef STAF_St_MDFCorrection_Table
#define STAF_St_MDFCorrection_Table

#include "TTable.h"

#include "MDFCorrection.h"

/*!
 * \class  St_MDFCorrection
 * \brief  C++ wrapper for <MDFCorrection> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:28 2018
 *
 * This was generated for version 'DEV'
 */
class St_MDFCorrection : public TTable
{
 public:
   ClassDefTable(St_MDFCorrection,MDFCorrection_st)
   ClassDef(St_MDFCorrection,2) //C++ wrapper for <MDFCorrection> StAF table
};
#endif
