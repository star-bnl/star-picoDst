
#ifndef STAF_St_ftpcTrackingPars_Table
#define STAF_St_ftpcTrackingPars_Table

#include "TTable.h"

#include "ftpcTrackingPars.h"

/*!
 * \class  St_ftpcTrackingPars
 * \brief  C++ wrapper for <ftpcTrackingPars> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:13 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcTrackingPars : public TTable
{
 public:
   ClassDefTable(St_ftpcTrackingPars,ftpcTrackingPars_st)
   ClassDef(St_ftpcTrackingPars,2) //C++ wrapper for <ftpcTrackingPars> StAF table
};
#endif
