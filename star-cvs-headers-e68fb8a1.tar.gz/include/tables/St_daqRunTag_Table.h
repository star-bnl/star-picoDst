
#ifndef STAF_St_daqRunTag_Table
#define STAF_St_daqRunTag_Table

#include "TTable.h"

#include "daqRunTag.h"

/*!
 * \class  St_daqRunTag
 * \brief  C++ wrapper for <daqRunTag> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:02 2018
 *
 * This was generated for version 'DEV'
 */
class St_daqRunTag : public TTable
{
 public:
   ClassDefTable(St_daqRunTag,daqRunTag_st)
   ClassDef(St_daqRunTag,2) //C++ wrapper for <daqRunTag> StAF table
};
#endif
