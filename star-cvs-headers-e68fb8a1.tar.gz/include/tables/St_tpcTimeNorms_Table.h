
#ifndef STAF_St_tpcTimeNorms_Table
#define STAF_St_tpcTimeNorms_Table

#include "TTable.h"

#include "tpcTimeNorms.h"

/*!
 * \class  St_tpcTimeNorms
 * \brief  C++ wrapper for <tpcTimeNorms> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:34 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcTimeNorms : public TTable
{
 public:
   ClassDefTable(St_tpcTimeNorms,tpcTimeNorms_st)
   ClassDef(St_tpcTimeNorms,2) //C++ wrapper for <tpcTimeNorms> StAF table
};
#endif
