
#ifndef STAF_St_smdPed_Table
#define STAF_St_smdPed_Table

#include "TTable.h"

#include "smdPed.h"

/*!
 * \class  St_smdPed
 * \brief  C++ wrapper for <smdPed> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:21 2018
 *
 * This was generated for version 'DEV'
 */
class St_smdPed : public TTable
{
 public:
   ClassDefTable(St_smdPed,smdPed_st)
   ClassDef(St_smdPed,2) //C++ wrapper for <smdPed> StAF table
};
#endif
