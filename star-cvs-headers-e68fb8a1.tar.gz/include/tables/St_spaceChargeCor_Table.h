
#ifndef STAF_St_spaceChargeCor_Table
#define STAF_St_spaceChargeCor_Table

#include "TTable.h"

#include "spaceChargeCor.h"

/*!
 * \class  St_spaceChargeCor
 * \brief  C++ wrapper for <spaceChargeCor> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:21 2018
 *
 * This was generated for version 'DEV'
 */
class St_spaceChargeCor : public TTable
{
 public:
   ClassDefTable(St_spaceChargeCor,spaceChargeCor_st)
   ClassDef(St_spaceChargeCor,2) //C++ wrapper for <spaceChargeCor> StAF table
};
#endif
