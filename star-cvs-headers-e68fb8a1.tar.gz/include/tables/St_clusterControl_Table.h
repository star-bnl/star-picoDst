
#ifndef STAF_St_clusterControl_Table
#define STAF_St_clusterControl_Table

#include "TTable.h"

#include "clusterControl.h"

/*!
 * \class  St_clusterControl
 * \brief  C++ wrapper for <clusterControl> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:02 2018
 *
 * This was generated for version 'DEV'
 */
class St_clusterControl : public TTable
{
 public:
   ClassDefTable(St_clusterControl,clusterControl_st)
   ClassDef(St_clusterControl,2) //C++ wrapper for <clusterControl> StAF table
};
#endif
