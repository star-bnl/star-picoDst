
#ifndef STAF_St_emcBModuleEle_Table
#define STAF_St_emcBModuleEle_Table

#include "TTable.h"

#include "emcBModuleEle.h"

/*!
 * \class  St_emcBModuleEle
 * \brief  C++ wrapper for <emcBModuleEle> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:03 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcBModuleEle : public TTable
{
 public:
   ClassDefTable(St_emcBModuleEle,emcBModuleEle_st)
   ClassDef(St_emcBModuleEle,2) //C++ wrapper for <emcBModuleEle> StAF table
};
#endif
