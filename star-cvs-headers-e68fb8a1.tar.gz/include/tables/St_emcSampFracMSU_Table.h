
#ifndef STAF_St_emcSampFracMSU_Table
#define STAF_St_emcSampFracMSU_Table

#include "TTable.h"

#include "emcSampFracMSU.h"

/*!
 * \class  St_emcSampFracMSU
 * \brief  C++ wrapper for <emcSampFracMSU> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:05 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcSampFracMSU : public TTable
{
 public:
   ClassDefTable(St_emcSampFracMSU,emcSampFracMSU_st)
   ClassDef(St_emcSampFracMSU,2) //C++ wrapper for <emcSampFracMSU> StAF table
};
#endif
