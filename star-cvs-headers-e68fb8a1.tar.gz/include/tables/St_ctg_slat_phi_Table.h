
#ifndef STAF_St_ctg_slat_phi_Table
#define STAF_St_ctg_slat_phi_Table

#include "TTable.h"

#include "ctg_slat_phi.h"

/*!
 * \class  St_ctg_slat_phi
 * \brief  C++ wrapper for <ctg_slat_phi> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:44 2018
 *
 * This was generated for version 'DEV'
 */
class St_ctg_slat_phi : public TTable
{
 public:
   ClassDefTable(St_ctg_slat_phi,ctg_slat_phi_st)
   ClassDef(St_ctg_slat_phi,2) //C++ wrapper for <ctg_slat_phi> StAF table
};
#endif
