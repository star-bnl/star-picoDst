
#ifndef STAF_St_particle_dst_param_Table
#define STAF_St_particle_dst_param_Table

#include "TTable.h"

#include "particle_dst_param.h"

/*!
 * \class  St_particle_dst_param
 * \brief  C++ wrapper for <particle_dst_param> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:18:33 2018
 *
 * This was generated for version 'DEV'
 */
class St_particle_dst_param : public TTable
{
 public:
   ClassDefTable(St_particle_dst_param,particle_dst_param_st)
   ClassDef(St_particle_dst_param,2) //C++ wrapper for <particle_dst_param> StAF table
};
#endif
