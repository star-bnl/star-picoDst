
#ifndef STAF_St_svtConfiguration_Table
#define STAF_St_svtConfiguration_Table

#include "TTable.h"

#include "svtConfiguration.h"

/*!
 * \class  St_svtConfiguration
 * \brief  C++ wrapper for <svtConfiguration> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:24 2018
 *
 * This was generated for version 'DEV'
 */
class St_svtConfiguration : public TTable
{
 public:
   ClassDefTable(St_svtConfiguration,svtConfiguration_st)
   ClassDef(St_svtConfiguration,2) //C++ wrapper for <svtConfiguration> StAF table
};
#endif
