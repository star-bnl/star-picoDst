
#ifndef STAF_St_pvpdConfig_Table
#define STAF_St_pvpdConfig_Table

#include "TTable.h"

#include "pvpdConfig.h"

/*!
 * \class  St_pvpdConfig
 * \brief  C++ wrapper for <pvpdConfig> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:20 2018
 *
 * This was generated for version 'DEV'
 */
class St_pvpdConfig : public TTable
{
 public:
   ClassDefTable(St_pvpdConfig,pvpdConfig_st)
   ClassDef(St_pvpdConfig,2) //C++ wrapper for <pvpdConfig> StAF table
};
#endif
