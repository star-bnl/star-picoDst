
#ifndef STAF_St_tpcDedxPidCalib_Table
#define STAF_St_tpcDedxPidCalib_Table

#include "TTable.h"

#include "tpcDedxPidCalib.h"

/*!
 * \class  St_tpcDedxPidCalib
 * \brief  C++ wrapper for <tpcDedxPidCalib> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:30 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcDedxPidCalib : public TTable
{
 public:
   ClassDefTable(St_tpcDedxPidCalib,tpcDedxPidCalib_st)
   ClassDef(St_tpcDedxPidCalib,2) //C++ wrapper for <tpcDedxPidCalib> StAF table
};
#endif
