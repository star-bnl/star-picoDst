
#ifndef STAF_St_StvKonst_Table
#define STAF_St_StvKonst_Table

#include "TTable.h"

#include "StvKonst.h"

/*!
 * \class  St_StvKonst
 * \brief  C++ wrapper for <StvKonst> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:29 2018
 *
 * This was generated for version 'DEV'
 */
class St_StvKonst : public TTable
{
 public:
   ClassDefTable(St_StvKonst,StvKonst_st)
   ClassDef(St_StvKonst,2) //C++ wrapper for <StvKonst> StAF table
};
#endif
