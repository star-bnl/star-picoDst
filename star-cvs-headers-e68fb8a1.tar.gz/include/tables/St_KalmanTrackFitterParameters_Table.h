
#ifndef STAF_St_KalmanTrackFitterParameters_Table
#define STAF_St_KalmanTrackFitterParameters_Table

#include "TTable.h"

#include "KalmanTrackFitterParameters.h"

/*!
 * \class  St_KalmanTrackFitterParameters
 * \brief  C++ wrapper for <KalmanTrackFitterParameters> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:28 2018
 *
 * This was generated for version 'DEV'
 */
class St_KalmanTrackFitterParameters : public TTable
{
 public:
   ClassDefTable(St_KalmanTrackFitterParameters,KalmanTrackFitterParameters_st)
   ClassDef(St_KalmanTrackFitterParameters,2) //C++ wrapper for <KalmanTrackFitterParameters> StAF table
};
#endif
