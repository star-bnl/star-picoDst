
#ifndef STAF_St_fmsLedRef_Table
#define STAF_St_fmsLedRef_Table

#include "TTable.h"

#include "fmsLedRef.h"

/*!
 * \class  St_fmsLedRef
 * \brief  C++ wrapper for <fmsLedRef> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:08 2018
 *
 * This was generated for version 'DEV'
 */
class St_fmsLedRef : public TTable
{
 public:
   ClassDefTable(St_fmsLedRef,fmsLedRef_st)
   ClassDef(St_fmsLedRef,2) //C++ wrapper for <fmsLedRef> StAF table
};
#endif
