
#ifndef STAF_St_ftpcGas_Table
#define STAF_St_ftpcGas_Table

#include "TTable.h"

#include "ftpcGas.h"

/*!
 * \class  St_ftpcGas
 * \brief  C++ wrapper for <ftpcGas> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:12 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcGas : public TTable
{
 public:
   ClassDefTable(St_ftpcGas,ftpcGas_st)
   ClassDef(St_ftpcGas,2) //C++ wrapper for <ftpcGas> StAF table
};
#endif
