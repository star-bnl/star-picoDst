
#ifndef STAF_St_triggerID_Table
#define STAF_St_triggerID_Table

#include "TTable.h"

#include "triggerID.h"

/*!
 * \class  St_triggerID
 * \brief  C++ wrapper for <triggerID> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:35 2018
 *
 * This was generated for version 'DEV'
 */
class St_triggerID : public TTable
{
 public:
   ClassDefTable(St_triggerID,triggerID_st)
   ClassDef(St_triggerID,2) //C++ wrapper for <triggerID> StAF table
};
#endif
