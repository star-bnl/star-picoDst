
#ifndef STAF_St_trgDsmReg_Table
#define STAF_St_trgDsmReg_Table

#include "TTable.h"

#include "trgDsmReg.h"

/*!
 * \class  St_trgDsmReg
 * \brief  C++ wrapper for <trgDsmReg> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:34 2018
 *
 * This was generated for version 'DEV'
 */
class St_trgDsmReg : public TTable
{
 public:
   ClassDefTable(St_trgDsmReg,trgDsmReg_st)
   ClassDef(St_trgDsmReg,2) //C++ wrapper for <trgDsmReg> StAF table
};
#endif
