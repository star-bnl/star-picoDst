#ifndef STAF_St_ctg_Module
#define STAF_St_ctg_Module

#include "St_Module.h"

#ifdef __CINT__
 class table_head_st;
 class ctg_geo_st;
 class ctg_slat_phi_st;
 class ctg_slat_eta_st;
 class ctg_slat_st;
 class St_ctg_geo;
 class St_ctg_slat_phi;
 class St_ctg_slat_eta;
 class St_ctg_slat;
#else
#include "tables/St_ctg_geo_Table.h"
#include "tables/St_ctg_slat_phi_Table.h"
#include "tables/St_ctg_slat_eta_Table.h"
#include "tables/St_ctg_slat_Table.h"
#endif


class St_ctg : public St_Module
{
public:
  St_ctg() : St_Module(){}

// Passing the "simple" structures

 typedef enum { 
    kCtg_geo0,
    kCtg_slat_phi1,
    kCtg_slat_eta2,
    kCtg_slat3
 } Ectg;

// Passing the C++ objects

  St_ctg(
     St_ctg_geo *o0,
     St_ctg_slat_phi *o1,
     St_ctg_slat_eta *o2,
     St_ctg_slat *o3
  );
  Int_t operator()(
     St_ctg_geo *o0,
     St_ctg_slat_phi *o1,
     St_ctg_slat_eta *o2,
     St_ctg_slat *o3
  );

// Calling the wrapped STAF module

 Int_t ExecuteModule();

  const Char_t *GetName(){return "ctg";}
 ClassDef(St_ctg,0) // class-wrapper to cal ctg module 
};


R__EXTERN St_ctg &ctg; 

#endif
