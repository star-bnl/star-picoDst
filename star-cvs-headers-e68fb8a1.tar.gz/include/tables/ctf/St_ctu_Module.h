#ifndef STAF_St_ctu_Module
#define STAF_St_ctu_Module

#include "St_Module.h"

#ifdef __CINT__
 class table_head_st;
 class ctg_geo_st;
 class ctg_slat_st;
 class ctu_raw_st;
 class ctu_cor_st;
 class St_ctg_geo;
 class St_ctg_slat;
 class St_ctu_raw;
 class St_ctu_cor;
#else
#include "tables/St_ctg_geo_Table.h"
#include "tables/St_ctg_slat_Table.h"
#include "tables/St_ctu_raw_Table.h"
#include "tables/St_ctu_cor_Table.h"
#endif


class St_ctu : public St_Module
{
public:
  St_ctu() : St_Module(){}

// Passing the "simple" structures

 typedef enum { 
    kCtg_geo0,
    kCtg_slat1,
    kCtu_raw2,
    kCtu_cor3
 } Ectu;

// Passing the C++ objects

  St_ctu(
     St_ctg_geo *o0,
     St_ctg_slat *o1,
     St_ctu_raw *o2,
     St_ctu_cor *o3
  );
  Int_t operator()(
     St_ctg_geo *o0,
     St_ctg_slat *o1,
     St_ctu_raw *o2,
     St_ctu_cor *o3
  );

// Calling the wrapped STAF module

 Int_t ExecuteModule();

  const Char_t *GetName(){return "ctu";}
 ClassDef(St_ctu,0) // class-wrapper to cal ctu module 
};


R__EXTERN St_ctu &ctu; 

#endif
