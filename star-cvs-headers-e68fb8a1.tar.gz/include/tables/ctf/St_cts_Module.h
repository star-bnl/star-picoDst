#ifndef STAF_St_cts_Module
#define STAF_St_cts_Module

#include "St_Module.h"

#ifdef __CINT__
 class table_head_st;
 class g2t_ctf_hit_st;
 class g2t_track_st;
 class ctg_geo_st;
 class ctg_slat_st;
 class ctg_slat_phi_st;
 class ctg_slat_eta_st;
 class cts_mpara_st;
 class cts_event_st;
 class cts_mslat_st;
 class ctu_raw_st;
 class St_g2t_ctf_hit;
 class St_g2t_track;
 class St_ctg_geo;
 class St_ctg_slat;
 class St_ctg_slat_phi;
 class St_ctg_slat_eta;
 class St_cts_mpara;
 class St_cts_event;
 class St_cts_mslat;
 class St_ctu_raw;
#else
#include "tables/St_g2t_ctf_hit_Table.h"
#include "tables/St_g2t_track_Table.h"
#include "tables/St_ctg_geo_Table.h"
#include "tables/St_ctg_slat_Table.h"
#include "tables/St_ctg_slat_phi_Table.h"
#include "tables/St_ctg_slat_eta_Table.h"
#include "tables/St_cts_mpara_Table.h"
#include "tables/St_cts_event_Table.h"
#include "tables/St_cts_mslat_Table.h"
#include "tables/St_ctu_raw_Table.h"
#endif


class St_cts : public St_Module
{
public:
  St_cts() : St_Module(){}

// Passing the "simple" structures

 typedef enum { 
    kG2t_ctf_hit0,
    kG2t_track1,
    kCtg_geo2,
    kCtg_slat3,
    kCtg_slat_phi4,
    kCtg_slat_eta5,
    kCts_mpara6,
    kCts_event7,
    kCts_mslat8,
    kCtu_raw9
 } Ects;

// Passing the C++ objects

  St_cts(
     St_g2t_ctf_hit *o0,
     St_g2t_track *o1,
     St_ctg_geo *o2,
     St_ctg_slat *o3,
     St_ctg_slat_phi *o4,
     St_ctg_slat_eta *o5,
     St_cts_mpara *o6,
     St_cts_event *o7,
     St_cts_mslat *o8,
     St_ctu_raw *o9
  );
  Int_t operator()(
     St_g2t_ctf_hit *o0,
     St_g2t_track *o1,
     St_ctg_geo *o2,
     St_ctg_slat *o3,
     St_ctg_slat_phi *o4,
     St_ctg_slat_eta *o5,
     St_cts_mpara *o6,
     St_cts_event *o7,
     St_cts_mslat *o8,
     St_ctu_raw *o9
  );

// Calling the wrapped STAF module

 Int_t ExecuteModule();

  const Char_t *GetName(){return "cts";}
 ClassDef(St_cts,0) // class-wrapper to cal cts module 
};


R__EXTERN St_cts &cts; 

#endif
