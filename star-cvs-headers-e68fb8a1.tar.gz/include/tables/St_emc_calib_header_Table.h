
#ifndef STAF_St_emc_calib_header_Table
#define STAF_St_emc_calib_header_Table

#include "TTable.h"

#include "emc_calib_header.h"

/*!
 * \class  St_emc_calib_header
 * \brief  C++ wrapper for <emc_calib_header> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:37 2018
 *
 * This was generated for version 'DEV'
 */
class St_emc_calib_header : public TTable
{
 public:
   ClassDefTable(St_emc_calib_header,emc_calib_header_st)
   ClassDef(St_emc_calib_header,2) //C++ wrapper for <emc_calib_header> StAF table
};
#endif
