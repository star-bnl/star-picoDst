
#ifndef STAF_St_pxlHotPixels_Table
#define STAF_St_pxlHotPixels_Table

#include "TTable.h"

#include "pxlHotPixels.h"

/*!
 * \class  St_pxlHotPixels
 * \brief  C++ wrapper for <pxlHotPixels> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:20 2018
 *
 * This was generated for version 'DEV'
 */
class St_pxlHotPixels : public TTable
{
 public:
   ClassDefTable(St_pxlHotPixels,pxlHotPixels_st)
   ClassDef(St_pxlHotPixels,2) //C++ wrapper for <pxlHotPixels> StAF table
};
#endif
