
#ifndef STAF_St_tofr5Maptable_Table
#define STAF_St_tofr5Maptable_Table

#include "TTable.h"

#include "tofr5Maptable.h"

/*!
 * \class  St_tofr5Maptable
 * \brief  C++ wrapper for <tofr5Maptable> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:29 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofr5Maptable : public TTable
{
 public:
   ClassDefTable(St_tofr5Maptable,tofr5Maptable_st)
   ClassDef(St_tofr5Maptable,2) //C++ wrapper for <tofr5Maptable> StAF table
};
#endif
