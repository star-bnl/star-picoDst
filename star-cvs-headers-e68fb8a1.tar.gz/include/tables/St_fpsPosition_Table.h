
#ifndef STAF_St_fpsPosition_Table
#define STAF_St_fpsPosition_Table

#include "TTable.h"

#include "fpsPosition.h"

/*!
 * \class  St_fpsPosition
 * \brief  C++ wrapper for <fpsPosition> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:11 2018
 *
 * This was generated for version 'DEV'
 */
class St_fpsPosition : public TTable
{
 public:
   ClassDefTable(St_fpsPosition,fpsPosition_st)
   ClassDef(St_fpsPosition,2) //C++ wrapper for <fpsPosition> StAF table
};
#endif
