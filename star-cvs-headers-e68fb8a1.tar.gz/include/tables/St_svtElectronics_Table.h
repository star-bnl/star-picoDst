
#ifndef STAF_St_svtElectronics_Table
#define STAF_St_svtElectronics_Table

#include "TTable.h"

#include "svtElectronics.h"

/*!
 * \class  St_svtElectronics
 * \brief  C++ wrapper for <svtElectronics> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:25 2018
 *
 * This was generated for version 'DEV'
 */
class St_svtElectronics : public TTable
{
 public:
   ClassDefTable(St_svtElectronics,svtElectronics_st)
   ClassDef(St_svtElectronics,2) //C++ wrapper for <svtElectronics> StAF table
};
#endif
