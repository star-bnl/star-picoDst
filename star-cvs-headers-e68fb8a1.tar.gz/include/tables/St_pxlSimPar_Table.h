
#ifndef STAF_St_pxlSimPar_Table
#define STAF_St_pxlSimPar_Table

#include "TTable.h"

#include "pxlSimPar.h"

/*!
 * \class  St_pxlSimPar
 * \brief  C++ wrapper for <pxlSimPar> StAF table
 * \author Automatic Generation
 * \date   Fri Apr 13 15:10:23 2018
 *
 * This was generated for version 'DEV'
 */
class St_pxlSimPar : public TTable
{
 public:
   ClassDefTable(St_pxlSimPar,pxlSimPar_st)
   ClassDef(St_pxlSimPar,2) //C++ wrapper for <pxlSimPar> StAF table
};
#endif
