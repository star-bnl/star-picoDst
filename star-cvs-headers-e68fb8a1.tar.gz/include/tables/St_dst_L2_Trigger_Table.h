
#ifndef STAF_St_dst_L2_Trigger_Table
#define STAF_St_dst_L2_Trigger_Table

#include "TTable.h"

#include "dst_L2_Trigger.h"

/*!
 * \class  St_dst_L2_Trigger
 * \brief  C++ wrapper for <dst_L2_Trigger> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:18:32 2018
 *
 * This was generated for version 'DEV'
 */
class St_dst_L2_Trigger : public TTable
{
 public:
   ClassDefTable(St_dst_L2_Trigger,dst_L2_Trigger_st)
   ClassDef(St_dst_L2_Trigger,2) //C++ wrapper for <dst_L2_Trigger> StAF table
};
#endif
