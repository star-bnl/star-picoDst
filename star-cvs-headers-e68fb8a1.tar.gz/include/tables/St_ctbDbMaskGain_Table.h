
#ifndef STAF_St_ctbDbMaskGain_Table
#define STAF_St_ctbDbMaskGain_Table

#include "TTable.h"

#include "ctbDbMaskGain.h"

/*!
 * \class  St_ctbDbMaskGain
 * \brief  C++ wrapper for <ctbDbMaskGain> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:02 2018
 *
 * This was generated for version 'DEV'
 */
class St_ctbDbMaskGain : public TTable
{
 public:
   ClassDefTable(St_ctbDbMaskGain,ctbDbMaskGain_st)
   ClassDef(St_ctbDbMaskGain,2) //C++ wrapper for <ctbDbMaskGain> StAF table
};
#endif
