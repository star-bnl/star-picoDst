
#ifndef STAF_St_tpcGridLeak_Table
#define STAF_St_tpcGridLeak_Table

#include "TTable.h"

#include "tpcGridLeak.h"

/*!
 * \class  St_tpcGridLeak
 * \brief  C++ wrapper for <tpcGridLeak> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:32 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcGridLeak : public TTable
{
 public:
   ClassDefTable(St_tpcGridLeak,tpcGridLeak_st)
   ClassDef(St_tpcGridLeak,2) //C++ wrapper for <tpcGridLeak> StAF table
};
#endif
