
#ifndef STAF_St_ftpcdEdxPars_Table
#define STAF_St_ftpcdEdxPars_Table

#include "TTable.h"

#include "ftpcdEdxPars.h"

/*!
 * \class  St_ftpcdEdxPars
 * \brief  C++ wrapper for <ftpcdEdxPars> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:13 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcdEdxPars : public TTable
{
 public:
   ClassDefTable(St_ftpcdEdxPars,ftpcdEdxPars_st)
   ClassDef(St_ftpcdEdxPars,2) //C++ wrapper for <ftpcdEdxPars> StAF table
};
#endif
