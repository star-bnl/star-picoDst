
#ifndef STAF_St_cts_event_Table
#define STAF_St_cts_event_Table

#include "TTable.h"

#include "cts_event.h"

/*!
 * \class  St_cts_event
 * \brief  C++ wrapper for <cts_event> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:44 2018
 *
 * This was generated for version 'DEV'
 */
class St_cts_event : public TTable
{
 public:
   ClassDefTable(St_cts_event,cts_event_st)
   ClassDef(St_cts_event,2) //C++ wrapper for <cts_event> StAF table
};
#endif
