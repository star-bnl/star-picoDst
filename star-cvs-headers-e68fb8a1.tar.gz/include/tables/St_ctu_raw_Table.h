
#ifndef STAF_St_ctu_raw_Table
#define STAF_St_ctu_raw_Table

#include "TTable.h"

#include "ctu_raw.h"

/*!
 * \class  St_ctu_raw
 * \brief  C++ wrapper for <ctu_raw> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:45 2018
 *
 * This was generated for version 'DEV'
 */
class St_ctu_raw : public TTable
{
 public:
   ClassDefTable(St_ctu_raw,ctu_raw_st)
   ClassDef(St_ctu_raw,2) //C++ wrapper for <ctu_raw> StAF table
};
#endif
