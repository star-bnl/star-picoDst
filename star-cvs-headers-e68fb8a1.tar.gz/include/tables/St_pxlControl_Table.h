
#ifndef STAF_St_pxlControl_Table
#define STAF_St_pxlControl_Table

#include "TTable.h"

#include "pxlControl.h"

/*!
 * \class  St_pxlControl
 * \brief  C++ wrapper for <pxlControl> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:20 2018
 *
 * This was generated for version 'DEV'
 */
class St_pxlControl : public TTable
{
 public:
   ClassDefTable(St_pxlControl,pxlControl_st)
   ClassDef(St_pxlControl,2) //C++ wrapper for <pxlControl> StAF table
};
#endif
