
#ifndef STAF_St_pmdUMDimensions_Table
#define STAF_St_pmdUMDimensions_Table

#include "TTable.h"

#include "pmdUMDimensions.h"

/*!
 * \class  St_pmdUMDimensions
 * \brief  C++ wrapper for <pmdUMDimensions> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:18 2018
 *
 * This was generated for version 'DEV'
 */
class St_pmdUMDimensions : public TTable
{
 public:
   ClassDefTable(St_pmdUMDimensions,pmdUMDimensions_st)
   ClassDef(St_pmdUMDimensions,2) //C++ wrapper for <pmdUMDimensions> StAF table
};
#endif
