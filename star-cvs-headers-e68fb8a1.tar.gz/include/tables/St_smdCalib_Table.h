
#ifndef STAF_St_smdCalib_Table
#define STAF_St_smdCalib_Table

#include "TTable.h"

#include "smdCalib.h"

/*!
 * \class  St_smdCalib
 * \brief  C++ wrapper for <smdCalib> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:21 2018
 *
 * This was generated for version 'DEV'
 */
class St_smdCalib : public TTable
{
 public:
   ClassDefTable(St_smdCalib,smdCalib_st)
   ClassDef(St_smdCalib,2) //C++ wrapper for <smdCalib> StAF table
};
#endif
