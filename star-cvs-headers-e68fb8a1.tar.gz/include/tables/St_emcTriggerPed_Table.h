
#ifndef STAF_St_emcTriggerPed_Table
#define STAF_St_emcTriggerPed_Table

#include "TTable.h"

#include "emcTriggerPed.h"

/*!
 * \class  St_emcTriggerPed
 * \brief  C++ wrapper for <emcTriggerPed> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:05 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcTriggerPed : public TTable
{
 public:
   ClassDefTable(St_emcTriggerPed,emcTriggerPed_st)
   ClassDef(St_emcTriggerPed,2) //C++ wrapper for <emcTriggerPed> StAF table
};
#endif
