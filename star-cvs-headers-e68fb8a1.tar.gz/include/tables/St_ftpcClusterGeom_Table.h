
#ifndef STAF_St_ftpcClusterGeom_Table
#define STAF_St_ftpcClusterGeom_Table

#include "TTable.h"

#include "ftpcClusterGeom.h"

/*!
 * \class  St_ftpcClusterGeom
 * \brief  C++ wrapper for <ftpcClusterGeom> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:11 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcClusterGeom : public TTable
{
 public:
   ClassDefTable(St_ftpcClusterGeom,ftpcClusterGeom_st)
   ClassDef(St_ftpcClusterGeom,2) //C++ wrapper for <ftpcClusterGeom> StAF table
};
#endif
