
#ifndef STAF_St_cts_mpara_Table
#define STAF_St_cts_mpara_Table

#include "TTable.h"

#include "cts_mpara.h"

/*!
 * \class  St_cts_mpara
 * \brief  C++ wrapper for <cts_mpara> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:45 2018
 *
 * This was generated for version 'DEV'
 */
class St_cts_mpara : public TTable
{
 public:
   ClassDefTable(St_cts_mpara,cts_mpara_st)
   ClassDef(St_cts_mpara,2) //C++ wrapper for <cts_mpara> StAF table
};
#endif
