
#ifndef STAF_St_istPedNoise_Table
#define STAF_St_istPedNoise_Table

#include "TTable.h"

#include "istPedNoise.h"

/*!
 * \class  St_istPedNoise
 * \brief  C++ wrapper for <istPedNoise> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:14 2018
 *
 * This was generated for version 'DEV'
 */
class St_istPedNoise : public TTable
{
 public:
   ClassDefTable(St_istPedNoise,istPedNoise_st)
   ClassDef(St_istPedNoise,2) //C++ wrapper for <istPedNoise> StAF table
};
#endif
