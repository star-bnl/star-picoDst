
#ifndef STAF_St_bemcModules_Table
#define STAF_St_bemcModules_Table

#include "TTable.h"

#include "bemcModules.h"

/*!
 * \class  St_bemcModules
 * \brief  C++ wrapper for <bemcModules> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:00 2018
 *
 * This was generated for version 'DEV'
 */
class St_bemcModules : public TTable
{
 public:
   ClassDefTable(St_bemcModules,bemcModules_st)
   ClassDef(St_bemcModules,2) //C++ wrapper for <bemcModules> StAF table
};
#endif
