
#ifndef STAF_St_fmsLed_Table
#define STAF_St_fmsLed_Table

#include "TTable.h"

#include "fmsLed.h"

/*!
 * \class  St_fmsLed
 * \brief  C++ wrapper for <fmsLed> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:08 2018
 *
 * This was generated for version 'DEV'
 */
class St_fmsLed : public TTable
{
 public:
   ClassDefTable(St_fmsLed,fmsLed_st)
   ClassDef(St_fmsLed,2) //C++ wrapper for <fmsLed> StAF table
};
#endif
