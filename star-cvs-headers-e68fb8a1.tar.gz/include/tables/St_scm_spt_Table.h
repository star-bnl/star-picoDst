
#ifndef STAF_St_scm_spt_Table
#define STAF_St_scm_spt_Table

#include "TTable.h"

#include "scm_spt.h"

/*!
 * \class  St_scm_spt
 * \brief  C++ wrapper for <scm_spt> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:26 2018
 *
 * This was generated for version 'DEV'
 */
class St_scm_spt : public TTable
{
 public:
   ClassDefTable(St_scm_spt,scm_spt_st)
   ClassDef(St_scm_spt,2) //C++ wrapper for <scm_spt> StAF table
};
#endif
