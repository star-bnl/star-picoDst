
#ifndef STAF_St_emcClusterParam_Table
#define STAF_St_emcClusterParam_Table

#include "TTable.h"

#include "emcClusterParam.h"

/*!
 * \class  St_emcClusterParam
 * \brief  C++ wrapper for <emcClusterParam> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:31:42 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcClusterParam : public TTable
{
 public:
   ClassDefTable(St_emcClusterParam,emcClusterParam_st)
   ClassDef(St_emcClusterParam,2) //C++ wrapper for <emcClusterParam> StAF table
};
#endif
