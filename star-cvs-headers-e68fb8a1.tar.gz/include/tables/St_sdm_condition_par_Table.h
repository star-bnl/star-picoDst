
#ifndef STAF_St_sdm_condition_par_Table
#define STAF_St_sdm_condition_par_Table

#include "TTable.h"

#include "sdm_condition_par.h"

/*!
 * \class  St_sdm_condition_par
 * \brief  C++ wrapper for <sdm_condition_par> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:27 2018
 *
 * This was generated for version 'DEV'
 */
class St_sdm_condition_par : public TTable
{
 public:
   ClassDefTable(St_sdm_condition_par,sdm_condition_par_st)
   ClassDef(St_sdm_condition_par,2) //C++ wrapper for <sdm_condition_par> StAF table
};
#endif
