
#ifndef STAF_St_additionalTriggerID_Table
#define STAF_St_additionalTriggerID_Table

#include "TTable.h"

#include "additionalTriggerID.h"

/*!
 * \class  St_additionalTriggerID
 * \brief  C++ wrapper for <additionalTriggerID> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:00 2018
 *
 * This was generated for version 'DEV'
 */
class St_additionalTriggerID : public TTable
{
 public:
   ClassDefTable(St_additionalTriggerID,additionalTriggerID_st)
   ClassDef(St_additionalTriggerID,2) //C++ wrapper for <additionalTriggerID> StAF table
};
#endif
