
#ifndef STAF_St_smdStatus_Table
#define STAF_St_smdStatus_Table

#include "TTable.h"

#include "smdStatus.h"

/*!
 * \class  St_smdStatus
 * \brief  C++ wrapper for <smdStatus> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:21 2018
 *
 * This was generated for version 'DEV'
 */
class St_smdStatus : public TTable
{
 public:
   ClassDefTable(St_smdStatus,smdStatus_st)
   ClassDef(St_smdStatus,2) //C++ wrapper for <smdStatus> StAF table
};
#endif
