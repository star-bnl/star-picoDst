
#ifndef STAF_St_mtdTrayToTdigMap_Table
#define STAF_St_mtdTrayToTdigMap_Table

#include "TTable.h"

#include "mtdTrayToTdigMap.h"

/*!
 * \class  St_mtdTrayToTdigMap
 * \brief  C++ wrapper for <mtdTrayToTdigMap> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:17 2018
 *
 * This was generated for version 'DEV'
 */
class St_mtdTrayToTdigMap : public TTable
{
 public:
   ClassDefTable(St_mtdTrayToTdigMap,mtdTrayToTdigMap_st)
   ClassDef(St_mtdTrayToTdigMap,2) //C++ wrapper for <mtdTrayToTdigMap> StAF table
};
#endif
