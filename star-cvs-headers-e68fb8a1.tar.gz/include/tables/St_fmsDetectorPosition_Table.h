
#ifndef STAF_St_fmsDetectorPosition_Table
#define STAF_St_fmsDetectorPosition_Table

#include "TTable.h"

#include "fmsDetectorPosition.h"

/*!
 * \class  St_fmsDetectorPosition
 * \brief  C++ wrapper for <fmsDetectorPosition> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:07 2018
 *
 * This was generated for version 'DEV'
 */
class St_fmsDetectorPosition : public TTable
{
 public:
   ClassDefTable(St_fmsDetectorPosition,fmsDetectorPosition_st)
   ClassDef(St_fmsDetectorPosition,2) //C++ wrapper for <fmsDetectorPosition> StAF table
};
#endif
