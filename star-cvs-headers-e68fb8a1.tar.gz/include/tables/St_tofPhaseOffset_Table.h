
#ifndef STAF_St_tofPhaseOffset_Table
#define STAF_St_tofPhaseOffset_Table

#include "TTable.h"

#include "tofPhaseOffset.h"

/*!
 * \class  St_tofPhaseOffset
 * \brief  C++ wrapper for <tofPhaseOffset> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:27 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofPhaseOffset : public TTable
{
 public:
   ClassDefTable(St_tofPhaseOffset,tofPhaseOffset_st)
   ClassDef(St_tofPhaseOffset,2) //C++ wrapper for <tofPhaseOffset> StAF table
};
#endif
