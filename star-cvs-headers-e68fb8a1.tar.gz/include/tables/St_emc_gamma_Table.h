
#ifndef STAF_St_emc_gamma_Table
#define STAF_St_emc_gamma_Table

#include "TTable.h"

#include "emc_gamma.h"

/*!
 * \class  St_emc_gamma
 * \brief  C++ wrapper for <emc_gamma> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:38 2018
 *
 * This was generated for version 'DEV'
 */
class St_emc_gamma : public TTable
{
 public:
   ClassDefTable(St_emc_gamma,emc_gamma_st)
   ClassDef(St_emc_gamma,2) //C++ wrapper for <emc_gamma> StAF table
};
#endif
