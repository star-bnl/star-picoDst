
#ifndef STAF_St_ssdGainCalibWafer_Table
#define STAF_St_ssdGainCalibWafer_Table

#include "TTable.h"

#include "ssdGainCalibWafer.h"

/*!
 * \class  St_ssdGainCalibWafer
 * \brief  C++ wrapper for <ssdGainCalibWafer> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:22 2018
 *
 * This was generated for version 'DEV'
 */
class St_ssdGainCalibWafer : public TTable
{
 public:
   ClassDefTable(St_ssdGainCalibWafer,ssdGainCalibWafer_st)
   ClassDef(St_ssdGainCalibWafer,2) //C++ wrapper for <ssdGainCalibWafer> StAF table
};
#endif
