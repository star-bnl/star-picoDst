
#ifndef STAF_St_vertexSeed_Table
#define STAF_St_vertexSeed_Table

#include "TTable.h"

#include "vertexSeed.h"

/*!
 * \class  St_vertexSeed
 * \brief  C++ wrapper for <vertexSeed> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:35 2018
 *
 * This was generated for version 'DEV'
 */
class St_vertexSeed : public TTable
{
 public:
   ClassDefTable(St_vertexSeed,vertexSeed_st)
   ClassDef(St_vertexSeed,2) //C++ wrapper for <vertexSeed> StAF table
};
#endif
