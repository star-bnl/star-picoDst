
#ifndef STAF_St_tpcAvCurrent_Table
#define STAF_St_tpcAvCurrent_Table

#include "TTable.h"

#include "tpcAvCurrent.h"

/*!
 * \class  St_tpcAvCurrent
 * \brief  C++ wrapper for <tpcAvCurrent> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:30 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcAvCurrent : public TTable
{
 public:
   ClassDefTable(St_tpcAvCurrent,tpcAvCurrent_st)
   ClassDef(St_tpcAvCurrent,2) //C++ wrapper for <tpcAvCurrent> StAF table
};
#endif
