
#ifndef STAF_St_triggerInfo_Table
#define STAF_St_triggerInfo_Table

#include "TTable.h"

#include "triggerInfo.h"

/*!
 * \class  St_triggerInfo
 * \brief  C++ wrapper for <triggerInfo> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:35 2018
 *
 * This was generated for version 'DEV'
 */
class St_triggerInfo : public TTable
{
 public:
   ClassDefTable(St_triggerInfo,triggerInfo_st)
   ClassDef(St_triggerInfo,2) //C++ wrapper for <triggerInfo> StAF table
};
#endif
