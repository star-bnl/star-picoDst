
#ifndef STAF_St_sectorPosition_Table
#define STAF_St_sectorPosition_Table

#include "TTable.h"

#include "sectorPosition.h"

/*!
 * \class  St_sectorPosition
 * \brief  C++ wrapper for <sectorPosition> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:21 2018
 *
 * This was generated for version 'DEV'
 */
class St_sectorPosition : public TTable
{
 public:
   ClassDefTable(St_sectorPosition,sectorPosition_st)
   ClassDef(St_sectorPosition,2) //C++ wrapper for <sectorPosition> StAF table
};
#endif
