
#ifndef STAF_St_TpcAdcCorrection_Table
#define STAF_St_TpcAdcCorrection_Table

#include "TTable.h"

#include "TpcAdcCorrection.h"

/*!
 * \class  St_TpcAdcCorrection
 * \brief  C++ wrapper for <TpcAdcCorrection> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:29 2018
 *
 * This was generated for version 'DEV'
 */
class St_TpcAdcCorrection : public TTable
{
 public:
   ClassDefTable(St_TpcAdcCorrection,TpcAdcCorrection_st)
   ClassDef(St_TpcAdcCorrection,2) //C++ wrapper for <TpcAdcCorrection> StAF table
};
#endif
