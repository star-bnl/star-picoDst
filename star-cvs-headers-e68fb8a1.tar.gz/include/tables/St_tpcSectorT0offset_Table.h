
#ifndef STAF_St_tpcSectorT0offset_Table
#define STAF_St_tpcSectorT0offset_Table

#include "TTable.h"

#include "tpcSectorT0offset.h"

/*!
 * \class  St_tpcSectorT0offset
 * \brief  C++ wrapper for <tpcSectorT0offset> StAF table
 * \author Automatic Generation
 * \date   Fri Apr 27 17:36:03 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcSectorT0offset : public TTable
{
 public:
   ClassDefTable(St_tpcSectorT0offset,tpcSectorT0offset_st)
   ClassDef(St_tpcSectorT0offset,2) //C++ wrapper for <tpcSectorT0offset> StAF table
};
#endif
