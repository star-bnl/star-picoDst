
#ifndef STAF_St_emcStatus_Table
#define STAF_St_emcStatus_Table

#include "TTable.h"

#include "emcStatus.h"

/*!
 * \class  St_emcStatus
 * \brief  C++ wrapper for <emcStatus> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:05 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcStatus : public TTable
{
 public:
   ClassDefTable(St_emcStatus,emcStatus_st)
   ClassDef(St_emcStatus,2) //C++ wrapper for <emcStatus> StAF table
};
#endif
