
#ifndef STAF_St_smdst_v0_Table
#define STAF_St_smdst_v0_Table

#include "TTable.h"

#include "smdst_v0.h"

/*!
 * \class  St_smdst_v0
 * \brief  C++ wrapper for <smdst_v0> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:18:33 2018
 *
 * This was generated for version 'DEV'
 */
class St_smdst_v0 : public TTable
{
 public:
   ClassDefTable(St_smdst_v0,smdst_v0_st)
   ClassDef(St_smdst_v0,2) //C++ wrapper for <smdst_v0> StAF table
};
#endif
