
#ifndef STAF_St_emc_jet_eval_Table
#define STAF_St_emc_jet_eval_Table

#include "TTable.h"

#include "emc_jet_eval.h"

/*!
 * \class  St_emc_jet_eval
 * \brief  C++ wrapper for <emc_jet_eval> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:38 2018
 *
 * This was generated for version 'DEV'
 */
class St_emc_jet_eval : public TTable
{
 public:
   ClassDefTable(St_emc_jet_eval,emc_jet_eval_st)
   ClassDef(St_emc_jet_eval,2) //C++ wrapper for <emc_jet_eval> StAF table
};
#endif
