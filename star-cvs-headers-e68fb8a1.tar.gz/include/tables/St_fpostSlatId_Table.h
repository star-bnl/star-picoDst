
#ifndef STAF_St_fpostSlatId_Table
#define STAF_St_fpostSlatId_Table

#include "TTable.h"

#include "fpostSlatId.h"

/*!
 * \class  St_fpostSlatId
 * \brief  C++ wrapper for <fpostSlatId> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:10 2018
 *
 * This was generated for version 'DEV'
 */
class St_fpostSlatId : public TTable
{
 public:
   ClassDefTable(St_fpostSlatId,fpostSlatId_st)
   ClassDef(St_fpostSlatId,2) //C++ wrapper for <fpostSlatId> StAF table
};
#endif
