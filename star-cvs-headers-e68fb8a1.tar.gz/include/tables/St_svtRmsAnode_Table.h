
#ifndef STAF_St_svtRmsAnode_Table
#define STAF_St_svtRmsAnode_Table

#include "TTable.h"

#include "svtRmsAnode.h"

/*!
 * \class  St_svtRmsAnode
 * \brief  C++ wrapper for <svtRmsAnode> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:25 2018
 *
 * This was generated for version 'DEV'
 */
class St_svtRmsAnode : public TTable
{
 public:
   ClassDefTable(St_svtRmsAnode,svtRmsAnode_st)
   ClassDef(St_svtRmsAnode,2) //C++ wrapper for <svtRmsAnode> StAF table
};
#endif
