
#ifndef STAF_St_tofCorrection_Table
#define STAF_St_tofCorrection_Table

#include "TTable.h"

#include "tofCorrection.h"

/*!
 * \class  St_tofCorrection
 * \brief  C++ wrapper for <tofCorrection> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:26 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofCorrection : public TTable
{
 public:
   ClassDefTable(St_tofCorrection,tofCorrection_st)
   ClassDef(St_tofCorrection,2) //C++ wrapper for <tofCorrection> StAF table
};
#endif
