
#ifndef STAF_St_tofINLCorr_Table
#define STAF_St_tofINLCorr_Table

#include "TTable.h"

#include "tofINLCorr.h"

/*!
 * \class  St_tofINLCorr
 * \brief  C++ wrapper for <tofINLCorr> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:26 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofINLCorr : public TTable
{
 public:
   ClassDefTable(St_tofINLCorr,tofINLCorr_st)
   ClassDef(St_tofINLCorr,2) //C++ wrapper for <tofINLCorr> StAF table
};
#endif
