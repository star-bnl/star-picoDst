
#ifndef STAF_St_pmdCalSummary_Table
#define STAF_St_pmdCalSummary_Table

#include "TTable.h"

#include "pmdCalSummary.h"

/*!
 * \class  St_pmdCalSummary
 * \brief  C++ wrapper for <pmdCalSummary> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:17 2018
 *
 * This was generated for version 'DEV'
 */
class St_pmdCalSummary : public TTable
{
 public:
   ClassDefTable(St_pmdCalSummary,pmdCalSummary_st)
   ClassDef(St_pmdCalSummary,2) //C++ wrapper for <pmdCalSummary> StAF table
};
#endif
