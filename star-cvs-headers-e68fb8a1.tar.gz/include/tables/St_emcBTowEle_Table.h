
#ifndef STAF_St_emcBTowEle_Table
#define STAF_St_emcBTowEle_Table

#include "TTable.h"

#include "emcBTowEle.h"

/*!
 * \class  St_emcBTowEle
 * \brief  C++ wrapper for <emcBTowEle> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:04 2018
 *
 * This was generated for version 'DEV'
 */
class St_emcBTowEle : public TTable
{
 public:
   ClassDefTable(St_emcBTowEle,emcBTowEle_st)
   ClassDef(St_emcBTowEle,2) //C++ wrapper for <emcBTowEle> StAF table
};
#endif
