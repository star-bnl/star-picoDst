
#ifndef STAF_St_tpcElectronics_Table
#define STAF_St_tpcElectronics_Table

#include "TTable.h"

#include "tpcElectronics.h"

/*!
 * \class  St_tpcElectronics
 * \brief  C++ wrapper for <tpcElectronics> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:31 2018
 *
 * This was generated for version 'DEV'
 */
class St_tpcElectronics : public TTable
{
 public:
   ClassDefTable(St_tpcElectronics,tpcElectronics_st)
   ClassDef(St_tpcElectronics,2) //C++ wrapper for <tpcElectronics> StAF table
};
#endif
