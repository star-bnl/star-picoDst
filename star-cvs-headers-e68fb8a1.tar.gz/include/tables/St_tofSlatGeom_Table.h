
#ifndef STAF_St_tofSlatGeom_Table
#define STAF_St_tofSlatGeom_Table

#include "TTable.h"

#include "tofSlatGeom.h"

/*!
 * \class  St_tofSlatGeom
 * \brief  C++ wrapper for <tofSlatGeom> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:27 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofSlatGeom : public TTable
{
 public:
   ClassDefTable(St_tofSlatGeom,tofSlatGeom_st)
   ClassDef(St_tofSlatGeom,2) //C++ wrapper for <tofSlatGeom> StAF table
};
#endif
