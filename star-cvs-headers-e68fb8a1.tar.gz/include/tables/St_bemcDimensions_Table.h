
#ifndef STAF_St_bemcDimensions_Table
#define STAF_St_bemcDimensions_Table

#include "TTable.h"

#include "bemcDimensions.h"

/*!
 * \class  St_bemcDimensions
 * \brief  C++ wrapper for <bemcDimensions> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:00 2018
 *
 * This was generated for version 'DEV'
 */
class St_bemcDimensions : public TTable
{
 public:
   ClassDefTable(St_bemcDimensions,bemcDimensions_st)
   ClassDef(St_bemcDimensions,2) //C++ wrapper for <bemcDimensions> StAF table
};
#endif
