
#ifndef STAF_St_tofTrgWindow_Table
#define STAF_St_tofTrgWindow_Table

#include "TTable.h"

#include "tofTrgWindow.h"

/*!
 * \class  St_tofTrgWindow
 * \brief  C++ wrapper for <tofTrgWindow> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:28 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofTrgWindow : public TTable
{
 public:
   ClassDefTable(St_tofTrgWindow,tofTrgWindow_st)
   ClassDef(St_tofTrgWindow,2) //C++ wrapper for <tofTrgWindow> StAF table
};
#endif
