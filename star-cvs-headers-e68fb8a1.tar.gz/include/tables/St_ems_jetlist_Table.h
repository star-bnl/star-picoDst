
#ifndef STAF_St_ems_jetlist_Table
#define STAF_St_ems_jetlist_Table

#include "TTable.h"

#include "ems_jetlist.h"

/*!
 * \class  St_ems_jetlist
 * \brief  C++ wrapper for <ems_jetlist> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:40 2018
 *
 * This was generated for version 'DEV'
 */
class St_ems_jetlist : public TTable
{
 public:
   ClassDefTable(St_ems_jetlist,ems_jetlist_st)
   ClassDef(St_ems_jetlist,2) //C++ wrapper for <ems_jetlist> StAF table
};
#endif
