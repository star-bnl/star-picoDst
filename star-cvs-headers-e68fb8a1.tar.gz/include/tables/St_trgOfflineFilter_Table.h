
#ifndef STAF_St_trgOfflineFilter_Table
#define STAF_St_trgOfflineFilter_Table

#include "TTable.h"

#include "trgOfflineFilter.h"

/*!
 * \class  St_trgOfflineFilter
 * \brief  C++ wrapper for <trgOfflineFilter> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:34 2018
 *
 * This was generated for version 'DEV'
 */
class St_trgOfflineFilter : public TTable
{
 public:
   ClassDefTable(St_trgOfflineFilter,trgOfflineFilter_st)
   ClassDef(St_trgOfflineFilter,2) //C++ wrapper for <trgOfflineFilter> StAF table
};
#endif
