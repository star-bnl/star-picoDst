
#ifndef STAF_St_ems_emecor_Table
#define STAF_St_ems_emecor_Table

#include "TTable.h"

#include "ems_emecor.h"

/*!
 * \class  St_ems_emecor
 * \brief  C++ wrapper for <ems_emecor> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:39 2018
 *
 * This was generated for version 'DEV'
 */
class St_ems_emecor : public TTable
{
 public:
   ClassDefTable(St_ems_emecor,ems_emecor_st)
   ClassDef(St_ems_emecor,2) //C++ wrapper for <ems_emecor> StAF table
};
#endif
