
#ifndef STAF_St_svg_geom_Table
#define STAF_St_svg_geom_Table

#include "TTable.h"

#include "svg_geom.h"

/*!
 * \class  St_svg_geom
 * \brief  C++ wrapper for <svg_geom> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:27 2018
 *
 * This was generated for version 'DEV'
 */
class St_svg_geom : public TTable
{
 public:
   ClassDefTable(St_svg_geom,svg_geom_st)
   ClassDef(St_svg_geom,2) //C++ wrapper for <svg_geom> StAF table
};
#endif
