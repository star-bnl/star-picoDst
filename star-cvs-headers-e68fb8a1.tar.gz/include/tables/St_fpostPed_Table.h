
#ifndef STAF_St_fpostPed_Table
#define STAF_St_fpostPed_Table

#include "TTable.h"

#include "fpostPed.h"

/*!
 * \class  St_fpostPed
 * \brief  C++ wrapper for <fpostPed> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:10 2018
 *
 * This was generated for version 'DEV'
 */
class St_fpostPed : public TTable
{
 public:
   ClassDefTable(St_fpostPed,fpostPed_st)
   ClassDef(St_fpostPed,2) //C++ wrapper for <fpostPed> StAF table
};
#endif
