
#ifndef STAF_St_hepe_gent_Table
#define STAF_St_hepe_gent_Table

#include "TTable.h"

#include "hepe_gent.h"

/*!
 * \class  St_hepe_gent
 * \brief  C++ wrapper for <hepe_gent> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:11 2018
 *
 * This was generated for version 'DEV'
 */
class St_hepe_gent : public TTable
{
 public:
   ClassDefTable(St_hepe_gent,hepe_gent_st)
   ClassDef(St_hepe_gent,2) //C++ wrapper for <hepe_gent> StAF table
};
#endif
