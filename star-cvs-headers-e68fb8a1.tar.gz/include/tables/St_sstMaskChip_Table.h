
#ifndef STAF_St_sstMaskChip_Table
#define STAF_St_sstMaskChip_Table

#include "TTable.h"

#include "sstMaskChip.h"

/*!
 * \class  St_sstMaskChip
 * \brief  C++ wrapper for <sstMaskChip> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:23 2018
 *
 * This was generated for version 'DEV'
 */
class St_sstMaskChip : public TTable
{
 public:
   ClassDefTable(St_sstMaskChip,sstMaskChip_st)
   ClassDef(St_sstMaskChip,2) //C++ wrapper for <sstMaskChip> StAF table
};
#endif
