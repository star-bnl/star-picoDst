
#ifndef STAF_St_sstWaferConfiguration_Table
#define STAF_St_sstWaferConfiguration_Table

#include "TTable.h"

#include "sstWaferConfiguration.h"

/*!
 * \class  St_sstWaferConfiguration
 * \brief  C++ wrapper for <sstWaferConfiguration> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:24 2018
 *
 * This was generated for version 'DEV'
 */
class St_sstWaferConfiguration : public TTable
{
 public:
   ClassDefTable(St_sstWaferConfiguration,sstWaferConfiguration_st)
   ClassDef(St_sstWaferConfiguration,2) //C++ wrapper for <sstWaferConfiguration> StAF table
};
#endif
