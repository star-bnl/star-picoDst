
#ifndef STAF_St_vpdTotCorr_Table
#define STAF_St_vpdTotCorr_Table

#include "TTable.h"

#include "vpdTotCorr.h"

/*!
 * \class  St_vpdTotCorr
 * \brief  C++ wrapper for <vpdTotCorr> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:36 2018
 *
 * This was generated for version 'DEV'
 */
class St_vpdTotCorr : public TTable
{
 public:
   ClassDefTable(St_vpdTotCorr,vpdTotCorr_st)
   ClassDef(St_vpdTotCorr,2) //C++ wrapper for <vpdTotCorr> StAF table
};
#endif
