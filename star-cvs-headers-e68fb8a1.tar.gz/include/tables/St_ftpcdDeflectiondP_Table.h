
#ifndef STAF_St_ftpcdDeflectiondP_Table
#define STAF_St_ftpcdDeflectiondP_Table

#include "TTable.h"

#include "ftpcdDeflectiondP.h"

/*!
 * \class  St_ftpcdDeflectiondP
 * \brief  C++ wrapper for <ftpcdDeflectiondP> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:13 2018
 *
 * This was generated for version 'DEV'
 */
class St_ftpcdDeflectiondP : public TTable
{
 public:
   ClassDefTable(St_ftpcdDeflectiondP,ftpcdDeflectiondP_st)
   ClassDef(St_ftpcdDeflectiondP,2) //C++ wrapper for <ftpcdDeflectiondP> StAF table
};
#endif
