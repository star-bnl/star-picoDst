
#ifndef STAF_St_fmsBitShiftGainB_Table
#define STAF_St_fmsBitShiftGainB_Table

#include "TTable.h"

#include "fmsBitShiftGainB.h"

/*!
 * \class  St_fmsBitShiftGainB
 * \brief  C++ wrapper for <fmsBitShiftGainB> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:07 2018
 *
 * This was generated for version 'DEV'
 */
class St_fmsBitShiftGainB : public TTable
{
 public:
   ClassDefTable(St_fmsBitShiftGainB,fmsBitShiftGainB_st)
   ClassDef(St_fmsBitShiftGainB,2) //C++ wrapper for <fmsBitShiftGainB> StAF table
};
#endif
