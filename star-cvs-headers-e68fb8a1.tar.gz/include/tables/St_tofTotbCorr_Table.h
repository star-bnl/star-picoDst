
#ifndef STAF_St_tofTotbCorr_Table
#define STAF_St_tofTotbCorr_Table

#include "TTable.h"

#include "tofTotbCorr.h"

/*!
 * \class  St_tofTotbCorr
 * \brief  C++ wrapper for <tofTotbCorr> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:17:28 2018
 *
 * This was generated for version 'DEV'
 */
class St_tofTotbCorr : public TTable
{
 public:
   ClassDefTable(St_tofTotbCorr,tofTotbCorr_st)
   ClassDef(St_tofTotbCorr,2) //C++ wrapper for <tofTotbCorr> StAF table
};
#endif
