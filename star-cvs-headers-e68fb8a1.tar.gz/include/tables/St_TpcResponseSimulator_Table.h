
#ifndef STAF_St_TpcResponseSimulator_Table
#define STAF_St_TpcResponseSimulator_Table

#include "TTable.h"

#include "TpcResponseSimulator.h"

/*!
 * \class  St_TpcResponseSimulator
 * \brief  C++ wrapper for <TpcResponseSimulator> StAF table
 * \author Automatic Generation
 * \date   Fri Apr  6 16:16:59 2018
 *
 * This was generated for version 'DEV'
 */
class St_TpcResponseSimulator : public TTable
{
 public:
   ClassDefTable(St_TpcResponseSimulator,TpcResponseSimulator_st)
   ClassDef(St_TpcResponseSimulator,2) //C++ wrapper for <TpcResponseSimulator> StAF table
};
#endif
